/**
 * Niche Scout Pro — Background Service Worker (Manifest V3)
 * Handles Side Panel lifecycle, local storage sync across Etsy tabs, and quick-launch navigation.
 * 100% Client-Side Execution (Zero External Server Transmission).
 */

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["scout_telemetry_logs"], (res) => {
    if (!res.scout_telemetry_logs) {
      chrome.storage.local.set({
        scout_telemetry_logs: [
          {
            type: "system_init",
            payload: { message: "Extension installed and local storage initialized." },
            recordedAt: new Date().toISOString()
          }
        ]
      });
    }
  });
});

// Configure Side Panel behavior
if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }).catch(() => {});
}

async function handleAgentAction(msg) {
  const { action, query, url, tabId } = msg;

  if (action === "search" && query) {
    const targetUrl = `https://www.etsy.com/search?q=${encodeURIComponent(query)}`;
    const tab = await chrome.tabs.create({ url: targetUrl, active: true });
    return { success: true, action: "search", tabId: tab.id, url: targetUrl };
  }

  if (action === "visit" && url) {
    const tab = await chrome.tabs.create({ url, active: true });
    return { success: true, action: "visit", tabId: tab.id, url };
  }

  if (action === "extract") {
    let targetTabId = tabId;
    if (!targetTabId) {
      const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
      targetTabId = activeTab ? activeTab.id : null;
    }

    if (!targetTabId) return { success: false, error: "No active tab found" };

    return new Promise((resolve) => {
      chrome.tabs.sendMessage(targetTabId, { type: "ENS_AGENT_EXTRACT" }, (res) => {
        if (chrome.runtime.lastError) {
          resolve({ success: false, error: chrome.runtime.lastError.message });
        } else {
          resolve({ success: true, data: res });
        }
      });
    });
  }

  if (action === "export_csv") {
    const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (activeTab && activeTab.id) {
      chrome.tabs.sendMessage(activeTab.id, { type: "ENS_TRIGGER_EXPORT_CSV" });
      return { success: true, action: "export_csv", tabId: activeTab.id };
    }
    return { success: false, error: "No active Etsy tab to export from" };
  }

  if (action === "reload_extension") {
    setTimeout(() => {
      chrome.runtime.reload();
    }, 100);
    return { success: true, action: "reload_extension" };
  }

  return { success: false, error: `Unknown action: ${action}` };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message) {
    sendResponse({ success: false, error: "Empty message payload" });
    return false;
  }

  if (message.type === "ENS_AGENT_COMMAND") {
    handleAgentAction(message.payload)
      .then((res) => sendResponse(res))
      .catch((err) => sendResponse({ success: false, error: err.message || String(err) }));
    return true;
  }

  sendResponse({ success: true, handled: false, message: "Acknowledged" });
  return false;
});

// Broadcast storage changes to all active Etsy tabs for real-time reactivity
if (chrome.storage && chrome.storage.onChanged) {
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === "local" || areaName === "sync") {
      chrome.tabs.query({ url: "*://*.etsy.com/*" }, (tabs) => {
        if (chrome.runtime.lastError || !tabs) return;
        tabs.forEach((tab) => {
          if (tab.id) {
            chrome.tabs.sendMessage(tab.id, { type: "ENS_STORAGE_UPDATED", changes }, () => {
              const _ = chrome.runtime.lastError;
            });
          }
        });
      });
    }
  });
}
