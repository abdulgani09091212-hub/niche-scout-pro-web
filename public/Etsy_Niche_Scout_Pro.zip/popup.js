const DEFAULT_SETTINGS = {
  showGridBadges: true,
  showFocusKeywords: false,
  showOrganicAdRank: false,
  showInCartUrgency: true,
  showRatingsReviews: false,
  showNetProfit: true,
  showPriceSentiment: false,
  showUrlBadges: true,
  showDeliveryFormat: true,
  showVelocityBadge: true,
  showFloatingHud: true,
  filterDigitalOnly: false
};

const PRESET_HUNTER = {
  showGridBadges: true,
  showNetProfit: true,
  showInCartUrgency: true,
  showVelocityBadge: true,
  showDeliveryFormat: true,
  showFocusKeywords: false,
  showRatingsReviews: false,
  showOrganicAdRank: false,
  showPriceSentiment: false,
  showFloatingHud: true
};

const PRESET_FORENSIC = {
  showGridBadges: true,
  showNetProfit: true,
  showInCartUrgency: true,
  showVelocityBadge: true,
  showDeliveryFormat: true,
  showFocusKeywords: true,
  showRatingsReviews: true,
  showOrganicAdRank: true,
  showPriceSentiment: true,
  showFloatingHud: true
};

const PRESET_STEALTH = {
  showGridBadges: false,
  showFloatingHud: false
};

const toggleMap = {
  'toggle-grid-badges': 'showGridBadges',
  'toggle-keywords': 'showFocusKeywords',
  'toggle-incart': 'showInCartUrgency',
  'toggle-ratings': 'showRatingsReviews',
  'toggle-netprofit': 'showNetProfit',
  'toggle-delivery': 'showDeliveryFormat',
  'toggle-velocity': 'showVelocityBadge',
  'toggle-digital-only': 'filterDigitalOnly',
  'toggle-hud': 'showFloatingHud'
};

document.addEventListener('DOMContentLoaded', () => {
  let currentSettings = Object.assign({}, DEFAULT_SETTINGS);

  // 1. Tab Switching
  const tabBtnDemo = document.getElementById('tab-btn-demo');
  const tabBtnSettings = document.getElementById('tab-btn-settings');
  const tabDemoContent = document.getElementById('tab-demo-content');
  const tabSettingsContent = document.getElementById('tab-settings-content');

  function switchTab(target) {
    if (target === 'demo') {
      tabBtnDemo?.classList.add('active');
      tabBtnSettings?.classList.remove('active');
      tabDemoContent?.classList.add('active');
      tabSettingsContent?.classList.remove('active');
    } else {
      tabBtnSettings?.classList.add('active');
      tabBtnDemo?.classList.remove('active');
      tabSettingsContent?.classList.add('active');
      tabDemoContent?.classList.remove('active');
    }
  }

  tabBtnDemo?.addEventListener('click', () => switchTab('demo'));
  tabBtnSettings?.addEventListener('click', () => switchTab('settings'));

  // 2. Demo Tag Copy
  document.getElementById('copy-demo-tags-btn')?.addEventListener('click', () => {
    const demoTags = [
      'dispatch spreadsheet', 'courier template', 'fleet tracker', 'freight broker',
      'excel template', 'google sheets', 'delivery log', 'transport log',
      'trucking business', 'logistics tracker', 'digital download', 'owner operator', 'daily mileage'
    ].join(', ');
    navigator.clipboard?.writeText(demoTags).then(() => {
      const btn = document.getElementById('copy-demo-tags-btn');
      if (btn) {
        btn.textContent = '✓ Copied!';
        setTimeout(() => {
          btn.innerHTML = `
            <svg class="svg-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>
            Copy Tags
          `;
        }, 1800);
      }
    });
  });

  // 3. Quick Launch Buttons
  document.getElementById('launch-etsy-courier')?.addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://www.etsy.com/search?q=courier+dispatch+spreadsheet' });
    window.close();
  });

  document.querySelectorAll('.launch-pill-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const q = btn.getAttribute('data-query');
      if (q) {
        chrome.tabs.create({ url: `https://www.etsy.com/search?q=${encodeURIComponent(q)}` });
        window.close();
      }
    });
  });

  // 4. Load Settings & Bind Toggles
  chrome.storage?.local?.get('ens_settings', (res) => {
    currentSettings = Object.assign({}, DEFAULT_SETTINGS, res?.ens_settings || {});
    updateUiFromSettings(currentSettings);
  });

  function updateUiFromSettings(settings) {
    for (const [elemId, key] of Object.entries(toggleMap)) {
      const el = document.getElementById(elemId);
      if (el) {
        el.checked = !!settings[key];
      }
    }
  }

  for (const [elemId, key] of Object.entries(toggleMap)) {
    const el = document.getElementById(elemId);
    if (el) {
      el.addEventListener('change', () => {
        currentSettings[key] = el.checked;
        saveAndBroadcast(currentSettings);
      });
    }
  }

  // 5. Presets
  const hunterBtn = document.getElementById('preset-hunter');
  const forensicBtn = document.getElementById('preset-forensic');
  const stealthBtn = document.getElementById('preset-stealth');

  function setPresetActive(btn) {
    [hunterBtn, forensicBtn, stealthBtn].forEach(b => b?.classList.remove('active'));
    btn?.classList.add('active');
  }

  hunterBtn?.addEventListener('click', () => {
    currentSettings = Object.assign({}, currentSettings, PRESET_HUNTER);
    updateUiFromSettings(currentSettings);
    saveAndBroadcast(currentSettings);
    setPresetActive(hunterBtn);
  });

  forensicBtn?.addEventListener('click', () => {
    currentSettings = Object.assign({}, currentSettings, PRESET_FORENSIC);
    updateUiFromSettings(currentSettings);
    saveAndBroadcast(currentSettings);
    setPresetActive(forensicBtn);
  });

  stealthBtn?.addEventListener('click', () => {
    currentSettings = Object.assign({}, currentSettings, PRESET_STEALTH);
    updateUiFromSettings(currentSettings);
    saveAndBroadcast(currentSettings);
    setPresetActive(stealthBtn);
  });

  function saveAndBroadcast(settings) {
    chrome.storage?.local?.set({ ens_settings: settings }, () => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]?.id) {
          chrome.tabs.sendMessage(tabs[0].id, { action: 'updateSettings', settings });
        }
      });
    });
  }

  // 6. Action Buttons
  document.getElementById('open-sidepanel-btn')?.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.id) {
      if (chrome.sidePanel && chrome.sidePanel.open) {
        chrome.sidePanel.open({ tabId: tab.id });
        window.close();
      }
    }
  });

  document.getElementById('scan-now-btn')?.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.url && tab.url.includes('etsy.com')) {
      chrome.tabs.sendMessage(tab.id, { action: 'rescan' });
      window.close();
    } else {
      chrome.tabs.create({ url: 'https://www.etsy.com/search?q=courier+dispatch+spreadsheet' });
      window.close();
    }
  });

  document.getElementById('open-matrix-btn')?.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.url && tab.url.includes('etsy.com')) {
      chrome.tabs.sendMessage(tab.id, { action: 'openMatrix' });
      window.close();
    } else {
      chrome.tabs.create({ url: 'https://www.etsy.com/search?q=courier+dispatch+spreadsheet' });
      window.close();
    }
  });
});
