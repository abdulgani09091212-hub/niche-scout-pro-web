@echo off
setlocal
title Launching Etsy Niche Scout Pro
echo ===================================================================
echo   Starting Google Chrome with Etsy Niche Scout Pro Extension Loaded
echo ===================================================================
echo.
set "EXT_DIR=%~dp0"
if "%EXT_DIR:~-1%"=="\" set "EXT_DIR=%EXT_DIR:~0,-1%"

echo Extension Folder: "%EXT_DIR%"
echo.

set "CHROME_EXE="

if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" (
    set "CHROME_EXE=C:\Program Files\Google\Chrome\Application\chrome.exe"
) else if exist "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" (
    set "CHROME_EXE=C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
) else if exist "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" (
    set "CHROME_EXE=%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"
)

if not "%CHROME_EXE%"=="" (
    echo [OK] Chrome found at: "%CHROME_EXE%"
    echo [OK] Launching Chrome with Niche Scout Pro...
    start "" "%CHROME_EXE%" --load-extension="%EXT_DIR%" --no-first-run "https://www.etsy.com"
    echo.
    echo Done! Chrome is running with Etsy Niche Scout Pro.
) else (
    echo [!] Google Chrome was not found in standard installation paths.
    echo.
    echo Alternative 30-Second Setup:
    echo 1. Open your browser and navigate to: chrome://extensions
    echo 2. Enable 'Developer mode' in the top right corner.
    echo 3. Click 'Load unpacked' and select this exact folder:
    echo    %EXT_DIR%
    echo.
    pause
)
