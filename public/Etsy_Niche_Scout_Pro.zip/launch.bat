@echo off
setlocal
echo ========================================================
echo  Launching Chrome with Etsy Niche Scout Pro
echo ========================================================
set "EXT_DIR=%~dp0"
if "%EXT_DIR:~-1%"=="\" set "EXT_DIR=%EXT_DIR:~0,-1%"

if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" (
    start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" --load-extension="%EXT_DIR%" --no-first-run "https://www.etsy.com"
) else if exist "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" (
    start "" "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" --load-extension="%EXT_DIR%" --no-first-run "https://www.etsy.com"
) else if exist "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" (
    start "" "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" --load-extension="%EXT_DIR%" --no-first-run "https://www.etsy.com"
) else (
    echo Chrome was not found in standard paths.
    echo Please open chrome://extensions in your browser and click 'Load unpacked'.
    pause
)
