import os
import subprocess
import sys

def main():
    chrome_path = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
    ext_path = r"d:\Schduler\tools\etsy-extension"
    target_url = sys.argv[1] if len(sys.argv) > 1 and not sys.argv[1].startswith("--") else "https://www.etsy.com/search?q=courier+dispatch+spreadsheet"
    debug_port = 9222

    if not os.path.exists(chrome_path):
        print(f"ERROR: Chrome not found at {chrome_path}", flush=True)
        sys.exit(1)

    DETACHED_PROCESS = 0x00000008
    CREATE_NEW_PROCESS_GROUP = 0x00000200

    args = [
        chrome_path,
        f"--load-extension={ext_path}",
        f"--disable-extensions-except={ext_path}",
        f"--remote-debugging-port={debug_port}",
        "--no-first-run",
        "--no-default-browser-check",
        target_url
    ]

    try:
        proc = subprocess.Popen(
            args,
            creationflags=DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP,
            close_fds=True
        )
        print(f"[SUCCESS] Chrome launched with PID {proc.pid}", flush=True)
        print(f"[DEBUG] Remote debugging listening on http://127.0.0.1:{debug_port}", flush=True)
        print(f"[BRIDGE] Agent connection endpoint: http://127.0.0.1:{debug_port}/json", flush=True)
        print(f"[INFO] Navigating to: {target_url}", flush=True)
    except Exception as e:
        print(f"[ERROR] Failed to start Chrome: {e}", flush=True)
        sys.exit(1)

if __name__ == "__main__":
    main()
