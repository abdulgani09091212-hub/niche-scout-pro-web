const DEFAULT_SETTINGS = {
  showGridBadges: true,
  showFocusKeywords: false,
  showOrganicAdRank: false,
  showInCartUrgency: true,
  showRatingsReviews: false,
  showNetProfit: true,
  showPriceSentiment: false,
  showUrlBadges: true,
  showDeliveryFormat: true,
  showVelocityBadge: true,
  showFloatingHud: true,
  filterDigitalOnly: false
};

const PRESET_HUNTER = {
  showGridBadges: true,
  showNetProfit: true,
  showInCartUrgency: true,
  showVelocityBadge: true,
  showDeliveryFormat: true,
  showFocusKeywords: false,
  showRatingsReviews: false,
  showOrganicAdRank: false,
  showPriceSentiment: false,
  showFloatingHud: true
};

const PRESET_FORENSIC = {
  showGridBadges: true,
  showNetProfit: true,
  showInCartUrgency: true,
  showVelocityBadge: true,
  showDeliveryFormat: true,
  showFocusKeywords: true,
  showRatingsReviews: true,
  showOrganicAdRank: true,
  showPriceSentiment: true,
  showFloatingHud: true
};

const PRESET_STEALTH = {
  showGridBadges: false,
  showFloatingHud: false
};

const toggleMap = {
  'toggle-grid-badges': 'showGridBadges',
  'toggle-keywords': 'showFocusKeywords',
  'toggle-incart': 'showInCartUrgency',
  'toggle-ratings': 'showRatingsReviews',
  'toggle-netprofit': 'showNetProfit',
  'toggle-delivery': 'showDeliveryFormat',
  'toggle-velocity': 'showVelocityBadge',
  'toggle-digital-only': 'filterDigitalOnly',
  'toggle-hud': 'showFloatingHud'
};

document.addEventListener('DOMContentLoaded', () => {
  let currentSettings = Object.assign({}, DEFAULT_SETTINGS);

  chrome.storage?.local?.get('ens_settings', (res) => {
    currentSettings = Object.assign({}, DEFAULT_SETTINGS, res?.ens_settings || {});
    updateUiFromSettings(currentSettings);
  });

  function updateUiFromSettings(settings) {
    for (const [elemId, key] of Object.entries(toggleMap)) {
      const el = document.getElementById(elemId);
      if (el) {
        el.checked = !!settings[key];
      }
    }
  }

  // Bind individual switches
  for (const [elemId, key] of Object.entries(toggleMap)) {
    const el = document.getElementById(elemId);
    if (el) {
      el.addEventListener('change', () => {
        currentSettings[key] = el.checked;
        saveAndBroadcast(currentSettings);
      });
    }
  }

  // Presets
  const hunterBtn = document.getElementById('preset-hunter');
  const forensicBtn = document.getElementById('preset-forensic');
  const stealthBtn = document.getElementById('preset-stealth');

  function setPresetActive(btn) {
    [hunterBtn, forensicBtn, stealthBtn].forEach(b => b?.classList.remove('active'));
    btn?.classList.add('active');
  }

  hunterBtn?.addEventListener('click', () => {
    currentSettings = Object.assign({}, currentSettings, PRESET_HUNTER);
    updateUiFromSettings(currentSettings);
    saveAndBroadcast(currentSettings);
    setPresetActive(hunterBtn);
  });

  forensicBtn?.addEventListener('click', () => {
    currentSettings = Object.assign({}, currentSettings, PRESET_FORENSIC);
    updateUiFromSettings(currentSettings);
    saveAndBroadcast(currentSettings);
    setPresetActive(forensicBtn);
  });

  stealthBtn?.addEventListener('click', () => {
    currentSettings = Object.assign({}, currentSettings, PRESET_STEALTH);
    updateUiFromSettings(currentSettings);
    saveAndBroadcast(currentSettings);
    setPresetActive(stealthBtn);
  });

  function saveAndBroadcast(settings) {
    chrome.storage?.local?.set({ ens_settings: settings }, () => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]?.id) {
          chrome.tabs.sendMessage(tabs[0].id, { action: 'updateSettings', settings });
        }
      });
    });
  }

  // Quick action buttons
  document.getElementById('open-sidepanel-btn')?.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.id) {
      if (chrome.sidePanel && chrome.sidePanel.open) {
        chrome.sidePanel.open({ tabId: tab.id });
        window.close();
      }
    }
  });

  document.getElementById('scan-now-btn')?.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.url && tab.url.includes('etsy.com')) {
      chrome.tabs.sendMessage(tab.id, { action: 'rescan' });
      window.close();
    } else {
      chrome.tabs.create({ url: 'https://www.etsy.com/search?q=courier+dispatch+spreadsheet' });
      window.close();
    }
  });

  document.getElementById('open-matrix-btn')?.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.url && tab.url.includes('etsy.com')) {
      chrome.tabs.sendMessage(tab.id, { action: 'openMatrix' });
      window.close();
    } else {
      chrome.tabs.create({ url: 'https://www.etsy.com/search?q=courier+dispatch+spreadsheet' });
      window.close();
    }
  });

  document.getElementById('open-settings-btn')?.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.url && tab.url.includes('etsy.com')) {
      chrome.tabs.sendMessage(tab.id, { action: 'openSettings' });
      window.close();
    } else {
      chrome.tabs.create({ url: 'https://www.etsy.com/search?q=courier+dispatch+spreadsheet' });
      window.close();
    }
  });
});
