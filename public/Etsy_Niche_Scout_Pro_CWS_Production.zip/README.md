# Etsy Niche Scout Pro — Chrome Extension (Manifest V3 · 2026 Edition)

Lightning-fast, zero-latency micro-niche validation and competitive intelligence directly inside your genuine desktop browser session.

---

## What Makes the 2026 Architecture Superior:
* **Zero Bot Detection:** Runs natively in your real, logged-in browser where Etsy already trusts you. No DataDome blocks, no Cloudflare challenges, no CAPTCHAs.
* **Anti-Lag Zero-Reflow Batching:** Implements `requestAnimationFrame` batched DOM injections, `WeakSet<Element>` tracking, and `contain: layout paint style;` CSS containment. Prevents the scroll stutter and browser lag common in legacy tools like EverBee and Alura.
* **Anti-Mirage Non-Guesstimate Intelligence:** Never multiplies shop lifetime sales to fabricate fake revenue. Directly extracts real-time DOM buyer intent: active `In X Carts` count, 24-hour view volume, listing age from JSON-LD, and 30-day review velocity.
* **Data Horizon Comparison Matrix (Alt + M):** Instant high-density modal view comparing 50–100+ listings with live title search, quick filter chips (Digital Only, 🔥 3+ In Cart, 🚀 New Shops <50, ⭐ Bestsellers), column sorting, and 1-click CSV export.
* **Dynamic Profit Fee Engine & Settings Drawer:** Interactive drawer with real-time fee sliders (Transaction Fee %, Payment Processing %, Offsite Ads 0/12/15%, Listing fee) and live profit margin simulation on any item price.
* **16 Crisp Dual-Tone SVG Vector Icons:** Replaces legacy emojis with sharp, scalable SVGs designed for Retina screens.

---

## 3-Click Installation in Google Chrome / Brave / Edge:

1. Open your browser and go to:
   ```text
   chrome://extensions/
   ```
2. In the top-right corner, toggle **"Developer mode"** to **ON**.
3. Click the **"Load unpacked"** button in the top-left corner.
4. Select the extension directory:
   ```text
   d:\Schduler\tools\etsy-extension
   ```
   *(Or unzip `d:\Schduler\tools\Etsy_Niche_Scout_Pro_Extension.zip` on another computer and select that folder)*.

---

## 4 Operational Operating Modes:

### 1. Search Niche Scout (`/search?q=...`)
- **In-Grid Product Card Strips (Under-Product Intelligence):** Injects a sleek, tactile data badge directly beneath every listing card on Etsy with:
  - `🔥 In-Cart Urgency Badge`: High urgency indicator (`12 in cart`) vs muted indicator.
  - `⭐ Review Count & Rating`: E.g. `⭐ 248 rev` or `New Shop`.
  - `⚡ Delivery Format Pill`: `⚡ Digital (Instant)` vs `📦 Physical`.
  - `🛡️ Net Take-Home Profit`: Post-fee net seller profit (`$14.15 net (86% margin)`).
  - `🚀 Velocity Tag`: `🔥 Viral Demand`, `⚡ Active Demand`, or `🚀 Breakout Inroad`.
  - `🏷️ 1-Click Copy Tags`: Copies primary keyword tokens to clipboard without leaving the page.
  - `📋 1-Click Audit`: Copies structured listing JSON to clipboard.
- **Active Competition:** Extracts exact results count and benchmarks against the 1,500 ceiling.
- **Digital Product Filter:** 1-click filter toggle between all listings and digital downloads.
- **Top Ranking Tags:** Extracts the most recurring high-volume keyword tokens from Page 1.
- **Opportunity Score:** 0–100 composite ranking based on competition volume, new shop inroad percentage, and in-cart demand.
- **1-Click CSV Export:** Downloads full Page 1 audit with URLs, prices, and review counts.

### 2. Data Horizon Comparison Matrix (`Alt + M` or 📊 Table Icon)
- **High-Density Spreadsheet View:** Opens an expandable dark modal table comparing all Page 1 listings.
- **Live Search Filter:** Instant title searching as you type.
- **Quick Filter Chips:**
  - `All (N)`: Full captured catalog.
  - `Digital Only`: Template, instant download, and spreadsheet products.
  - `🔥 3+ In Cart`: Proven buyer conversion rockets.
  - `🚀 New Shops (<50)`: Vulnerable low-review breakout listings.
  - `⭐ Bestsellers`: Incumbents holding official badges.
- **Sortable Columns:** Sort by price, in-cart count, reviews, or velocity score.
- **1-Click CSV Export:** One click exports the current filtered view to CSV.

### 3. Settings Drawer & Profit Simulator (⚙️ Sliders Icon)
- **Customizable Fee Sliders:**
  - Transaction Fee (0% to 15%, default 6.5%).
  - Payment Processing Fee (0% to 10%, default 3% + $0.25).
  - Offsite Ads Selection (0% Standard Organic, 12% High-Volume, 15% Under $10k).
  - Listing Fee ($0.20 per item).
- **Live Simulation Box:** Displays real-time seller take-home and margin % for a test item price.
- **In-Grid Badge Controls:** Toggle badges ON/OFF and adjust position (bottom/top).
- **Minimum Cart Filter:** Set threshold (0 to 10) to only show badges on products with active buyer carts.
- **Currency Override:** Choose between Auto-detect, USD ($), GBP (£), EUR (€), CAD (CA$), AUD (AU$).

### 4. Listing Forensics Pro (`/listing/...`)
- **All 13 Backend Hidden Tags:** Extracts hidden tags from bottom chips and inline JSON scripts. Displays individual tag character lengths, alerts if a tag exceeds Etsy's 20-character ceiling, and provides 1-click **"Copy All 13 Tags"** (comma-separated, ready to paste into Etsy Listing Manager).
- **Listing Age & Days Active:** Directly parses JSON-LD metadata (`datePublished`) to calculate how many days the listing has been live.
- **Live Buyer Intent Signals:** Scrapes "In X Carts", "X views in last 24h", stock scarcity, and Bestseller/Star Seller status.
- **Title SEO & Mobile Truncation Meter:** 140-character progress bar plus preview of the first 40 characters visible on mobile screens.
- **Net Profit & Fee Calculator:** Computes net take-home based on your exact configured fee structure.
- **Competitor Review Friction Miner:** Analyzes customer review text for friction keywords (`hard`, `confusing`, `error`, `broken`, `mac`, `formula`) so you can engineer superior products.
- **Agent-Reach AI Bridge:** Generates pre-formatted `/agent-reach` research prompts for deep community sentiment mining on Reddit & Exa.

---

## Keyboard Shortcuts:

| Shortcut | Action |
|---|---|
| **Alt + S** | Toggle Floating HUD Visibility |
| **Alt + M** | Toggle Data Horizon Comparison Matrix |
| **Esc** | Close any open Modal or Drawer |
