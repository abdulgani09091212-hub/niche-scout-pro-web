const sharp = require('sharp');
const path = require('path');
const fs = require('fs');

const createSvg = (size) => `
<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <radialGradient id="grad" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#18181b"/>
      <stop offset="100%" stop-color="#09090b"/>
    </radialGradient>
  </defs>
  <!-- Background Squircle -->
  <rect x="0" y="0" width="${size}" height="${size}" rx="${size * 0.22}" fill="url(#grad)" stroke="#27272a" stroke-width="${Math.max(1, size * 0.03)}"/>
  
  <!-- Outer Radar Circle -->
  <circle cx="${size * 0.5}" cy="${size * 0.5}" r="${size * 0.32}" fill="none" stroke="#ea580c" stroke-width="${Math.max(1.5, size * 0.065)}" stroke-dasharray="${size * 0.15} ${size * 0.06}"/>
  
  <!-- Inner Crosshairs -->
  <line x1="${size * 0.5}" y1="${size * 0.25}" x2="${size * 0.5}" y2="${size * 0.75}" stroke="#ea580c" stroke-width="${Math.max(1, size * 0.05)}" stroke-linecap="round"/>
  <line x1="${size * 0.25}" y1="${size * 0.5}" x2="${size * 0.75}" y2="${size * 0.5}" stroke="#ea580c" stroke-width="${Math.max(1, size * 0.05)}" stroke-linecap="round"/>
  
  <!-- Center Core -->
  <circle cx="${size * 0.5}" cy="${size * 0.5}" r="${size * 0.1}" fill="#ea580c"/>
  
  <!-- Emerald Detection Pip -->
  <circle cx="${size * 0.72}" cy="${size * 0.28}" r="${size * 0.08}" fill="#10b981"/>
</svg>
`;

async function run() {
  const sizes = [16, 32, 48, 128];
  const outDir = path.join(__dirname, 'icons');
  if (!fs.existsSync(outDir)) {
    fs.mkdirSync(outDir, { recursive: true });
  }

  for (const s of sizes) {
    const svg = Buffer.from(createSvg(s));
    const outPath = path.join(outDir, `icon${s}.png`);
    await sharp(svg).png().toFile(outPath);
    console.log(`✓ Rendered 2026 ScoutPro Icon ${s}x${s} -> ${outPath}`);
  }
}

run().catch(err => {
  console.error(err);
  process.exit(1);
});
