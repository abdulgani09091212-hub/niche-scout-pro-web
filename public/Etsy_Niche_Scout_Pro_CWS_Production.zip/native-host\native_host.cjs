#!/usr/bin/env node
/**
 * Niche Scout Pro — Native Messaging Host & Autonomous Agent HTTP Bridge
 * Meets on Stdio length-prefixed protocol with Chrome/Brave/Edge and exposes a zero-config HTTP API on 127.0.0.1:9224
 */

const http = require('http');
const url = require('url');

const HTTP_PORT = 9224;
let pendingRequests = new Map();
let requestIdCounter = 1;
let extensionConnected = false;

// ---------------------------------------------------------------------------
// 1. Chrome Native Messaging Stdio Framing (4-byte length prefix)
// ---------------------------------------------------------------------------
let inputBuffer = Buffer.alloc(0);

process.stdin.on('data', (chunk) => {
  inputBuffer = Buffer.concat([inputBuffer, chunk]);

  while (inputBuffer.length >= 4) {
    const msgLen = inputBuffer.readUInt32LE(0);
    if (inputBuffer.length >= 4 + msgLen) {
      const msgBytes = inputBuffer.slice(4, 4 + msgLen);
      inputBuffer = inputBuffer.slice(4 + msgLen);
      try {
        const msg = JSON.parse(msgBytes.toString('utf8'));
        handleExtensionMessage(msg);
      } catch (err) {
        // ignore parse error
      }
    } else {
      break;
    }
  }
});

process.stdin.on('end', () => {
  extensionConnected = false;
});

function sendToExtension(payload) {
  const jsonStr = JSON.stringify(payload);
  const len = Buffer.byteLength(jsonStr, 'utf8');
  const header = Buffer.alloc(4);
  header.writeUInt32LE(len, 0);
  process.stdout.write(header);
  process.stdout.write(jsonStr, 'utf8');
}

function handleExtensionMessage(msg) {
  extensionConnected = true;
  if (msg && msg.id && pendingRequests.has(msg.id)) {
    const { resolve, timer } = pendingRequests.get(msg.id);
    clearTimeout(timer);
    pendingRequests.delete(msg.id);
    resolve(msg.result);
  }
}

function dispatchToExtension(action, params = {}) {
  return new Promise((resolve, reject) => {
    const id = ++requestIdCounter;
    const timer = setTimeout(() => {
      if (pendingRequests.has(id)) {
        pendingRequests.delete(id);
        reject(new Error('Extension response timed out'));
      }
    }, 15000);

    pendingRequests.set(id, { resolve, reject, timer });
    sendToExtension({ id, action, ...params });
  });
}

// ---------------------------------------------------------------------------
// 2. Zero-Config HTTP Agent API (127.0.0.1:9224)
// ---------------------------------------------------------------------------
const server = http.createServer(async (req, res) => {
  // Enable CORS for all local agent tools
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Content-Type', 'application/json');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;
  const query = parsedUrl.query;

  try {
    if (pathname === '/health') {
      res.writeHead(200);
      res.end(JSON.stringify({
        ok: true,
        version: '2026.1',
        agent: 'Niche Scout Pro Universal Bridge',
        extensionConnected
      }));
      return;
    }

    if (pathname === '/search') {
      const q = query.q || 'funeral program canva template';
      const result = await dispatchToExtension('search', { query: q });
      res.writeHead(200);
      res.end(JSON.stringify({ ok: true, result }));
      return;
    }

    if (pathname === '/visit') {
      const targetUrl = query.url;
      if (!targetUrl) {
        res.writeHead(400);
        res.end(JSON.stringify({ ok: false, error: 'Missing ?url= parameter' }));
        return;
      }
      const result = await dispatchToExtension('visit', { url: targetUrl });
      res.writeHead(200);
      res.end(JSON.stringify({ ok: true, result }));
      return;
    }

    if (pathname === '/extract') {
      const result = await dispatchToExtension('extract');
      res.writeHead(200);
      res.end(JSON.stringify({ ok: true, result }));
      return;
    }

    if (pathname === '/export_csv') {
      const result = await dispatchToExtension('export_csv');
      res.writeHead(200);
      res.end(JSON.stringify({ ok: true, result }));
      return;
    }

    res.writeHead(404);
    res.end(JSON.stringify({ ok: false, error: 'Endpoint not found. Available: /health, /search?q=..., /visit?url=..., /extract, /export_csv' }));
  } catch (err) {
    res.writeHead(500);
    res.end(JSON.stringify({ ok: false, error: err.message }));
  }
});

server.listen(HTTP_PORT, '127.0.0.1', () => {
  // Running in background
});
