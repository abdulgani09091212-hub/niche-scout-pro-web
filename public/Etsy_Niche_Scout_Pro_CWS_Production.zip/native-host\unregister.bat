@echo off
setlocal
echo Removing Niche Scout Pro Native Messaging Host Registry Keys...

reg delete "HKCU\Software\Google\Chrome\NativeMessagingHosts\com.etsy.niche_scout_pro" /f 2>nul
reg delete "HKCU\Software\Microsoft\Edge\NativeMessagingHosts\com.etsy.niche_scout_pro" /f 2>nul
reg delete "HKCU\Software\BraveSoftware\Brave-Browser\NativeMessagingHosts\com.etsy.niche_scout_pro" /f 2>nul

echo Done.
pause
