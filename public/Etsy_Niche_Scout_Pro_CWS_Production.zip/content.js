/**
 * Etsy Niche Scout Pro — Operational SaaS Research Extension
 * Aligned with: frontend-agent-skills (High density, 5-state resilience, tactile micro-interactions)
 * Executes natively in the user's authentic browser session. Zero external server calls.
 */

(function () {
  'use strict';

  if (typeof window !== 'undefined') {
    if (window.__etsyNicheScoutInjected) return;
    window.__etsyNicheScoutInjected = true;
  }

  console.log('[Etsy Niche Scout Pro] 2026 Operational SaaS Engine Active.');

  // ==========================================
  // CONFIGURATION & SETTINGS STATE (PERSISTENT)
  // ==========================================

  const DEFAULT_SETTINGS = {
    showGridBadges: true,       // Master in-grid toggle
    showFocusKeywords: true,    // Focus keyword chips row (Image 2 style)
    showOrganicAdRank: true,    // Organic #X vs Ad #Y rank badge (Alura method)
    showInCartUrgency: true,    // 🛒 In-cart urgency badge
    showRatingsReviews: true,   // ⭐ Ratings & reviews badge
    showNetProfit: true,        // 🛡️ Net profit & margin badge
    showPriceSentiment: true,   // 🟢 Value / 🟡 Premium vs Niche Median (Sale Samurai method)
    showUrlBadges: true,        // 🔥 Bestseller / ⭐ Star Seller / 💎 Etsy's Pick (eRank method)
    showDeliveryFormat: true,   // ⚡ Digital vs 📦 Physical badge
    showVelocityBadge: true,    // 🚀 Breakout / 🔥 Viral badge
    showFloatingHud: true,      // Floating Niche HUD (Alt+S)
    filterDigitalOnly: false,   // 1-Click Digital Products Only filter
    badgePosition: 'bottom',    // 'bottom' | 'top'
    badgeStyle: 'compact',      // 'compact' (1-line strip) | 'expanded' (Alura-style 2x3 grid box)
    txFeePct: 6.5,
    listingFee: 0.20,
    paymentProcessingFeePct: 3.0,
    paymentProcessingFixed: 0.25,
    offsiteAdsPct: 0.0,         // 0%, 12%, 15%
    currencyOverride: 'auto',   // 'auto' | '$' | '£' | '€' | 'CA$' | 'AU$'
    minCartThreshold: 0
  };

  let userSettings = Object.assign({}, DEFAULT_SETTINGS);

  function loadSettings(cb) {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get('ens_settings', (res) => {
        if (res && res.ens_settings) {
          userSettings = Object.assign({}, DEFAULT_SETTINGS, res.ens_settings);
        }
        if (cb) cb(userSettings);
      });
    } else {
      try {
        const stored = localStorage.getItem('ens_settings');
        if (stored) {
          userSettings = Object.assign({}, DEFAULT_SETTINGS, JSON.parse(stored));
        }
      } catch (e) {}
      if (cb) cb(userSettings);
    }
  }

  function saveSettings(newSettings, cb) {
    userSettings = Object.assign({}, userSettings, newSettings);
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.set({ ens_settings: userSettings }, () => {
        if (cb) cb(userSettings);
      });
    } else {
      try {
        localStorage.setItem('ens_settings', JSON.stringify(userSettings));
      } catch (e) {}
      if (cb) cb(userSettings);
    }
  }

  // ==========================================
  // 2026 CRISP DUAL-TONE SVG VECTOR ICONOGRAPHY
  // ==========================================

  function renderSvg(name, size = 14, className = 'ens-icon') {
    const icons = {
      radar: `<svg class="${className}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 2a10 10 0 0 1 10 10"/><path d="M12 12 19 5"/><circle cx="12" cy="12" r="2"/></svg>`,
      target: `<svg class="${className}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="6" r="6"/><circle cx="12" cy="12" r="2"/></svg>`,
      rocket: `<svg class="${className}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/><path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/></svg>`,
      flame: `<svg class="${className}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/></svg>`,
      tag: `<svg class="${className}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2H2v10l9.29 9.29c.94.94 2.48.94 3.42 0l6.58-6.58c.94-.94.94-2.48 0-3.42L12 2Z"/><circle cx="7" cy="7" r=".5" fill="currentColor"/></svg>`,
      shield: `<svg class="${className}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.5 3.8 17 5 19 5a1 1 0 0 1 1 1z"/></svg>`,
      sliders: `<svg class="${className}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" x2="4" y1="21" y2="14"/><line x1="4" x2="4" y1="10" y2="3"/><line x1="12" x2="12" y1="21" y2="12"/><line x1="12" x2="12" y1="8" y2="3"/><line x1="20" x2="20" y1="21" y2="16"/><line x1="20" x2="20" y1="12" y2="3"/><line x1="1" x2="7" y1="14" y2="14"/><line x1="9" x2="15" y1="8" y2="8"/><line x1="17" x2="23" y1="16" y2="16"/></svg>`,
      table: `<svg class="${className}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="18" x="3" y="3" rx="2"/><path d="M3 9h18"/><path d="M3 15h18"/><path d="M9 3v18"/><path d="M15 3v18"/></svg>`,
      sparkles: `<svg class="${className}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/><path d="M5 3v4"/><path d="M19 17v4"/><path d="M3 5h4"/><path d="M17 19h4"/></svg>`,
      download: `<svg class="${className}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>`,
      refresh: `<svg class="${className}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16"/><path d="M16 21h5v-5"/></svg>`,
      copy: `<svg class="${className}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>`,
      check: `<svg class="${className}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`,
      close: `<svg class="${className}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" x2="6" y1="6" y2="18"/><line x1="6" x2="18" y1="6" y2="18"/></svg>`,
      minus: `<svg class="${className}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" x2="19" y1="12" y2="12"/></svg>`,
      expand: `<svg class="${className}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" x2="14" y1="3" y2="10"/><line x1="3" x2="10" y1="21" y2="14"/></svg>`
    };
    return icons[name] || '';
  }

  // ==========================================
  // RUNTIME STATE & IN-MEMORY CACHE
  // ==========================================

  let currentAnalysis = null;
  let pageMode = 'none'; // 'search' | 'shop' | 'listing'
  let filterDigitalOnly = false;
  let isHudVisible = true;
  let isHudMinimized = false;

  // WeakSet ensures O(1) idempotent tracking without DOM mutation memory leaks
  const processedCards = new WeakSet();
  let gridInjectionScheduled = false;

  // ==========================================
  // DYNAMIC ECONOMIC & FEE ENGINE
  // ==========================================

  function calculateEconomics(price, settings = userSettings) {
    const p = Math.max(0, parseFloat(price) || 0);
    const txFee = p * ((settings.txFeePct || 6.5) / 100);
    const listFee = parseFloat(settings.listingFee) || 0.20;
    const procFee = (p * ((settings.paymentProcessingFeePct || 3.0) / 100)) + (parseFloat(settings.paymentProcessingFixed) || 0.25);
    const offsiteFee = p * ((settings.offsiteAdsPct || 0.0) / 100);
    const totalFees = txFee + listFee + procFee + offsiteFee;
    const netTakeHome = Math.max(0, p - totalFees);
    const marginPct = p > 0 ? Math.round((netTakeHome / p) * 100) : 0;

    return {
      txFee,
      listFee,
      procFee,
      offsiteFee,
      totalFees,
      netTakeHome,
      marginPct
    };
  }

  // ==========================================
  // UNIFIED 2026 SALES & REVENUE ESTIMATION ENGINE
  // (Sequential ID Age Normalization + Category Review Multipliers + 24-48h In-Cart Demand)
  // ==========================================

  function computeListingSalesEstimates(params) {
    const {
      price = 0,
      inCart = 0,
      sold24h = 0,
      reviewCount = 0,
      isBestseller = false,
      isDigital = false,
      listingId = ''
    } = params;

    // 1. Normalize age in months from sequential Etsy listing ID or fallback
    const numId = parseInt(listingId, 10);
    let ageInMonths = 24; // default ~2 years
    if (!isNaN(numId) && numId > 0) {
      if (numId > 1950000000) ageInMonths = 2;       // Brand new 2026 breakout
      else if (numId > 1850000000) ageInMonths = 6;  // Late 2025 (~6 mo)
      else if (numId > 1700000000) ageInMonths = 12; // 2024-2025 (~1 yr)
      else if (numId > 1500000000) ageInMonths = 24; // ~2 yrs
      else if (numId > 1300000000) ageInMonths = 36; // ~3 yrs
      else if (numId > 900000000) ageInMonths = 48;  // ~4 yrs
      else ageInMonths = 60;                         // 5+ yrs
    }

    // 2. Review velocity (reviews per month)
    const monthlyReviewVelocity = reviewCount / Math.max(0.5, ageInMonths);

    // 3. Review-to-Sale conversion multiplier
    // Digital goods: ~3.5% to 5% review rate -> 1 review per ~22-25 sales
    // Physical goods: ~8% to 11% review rate -> 1 review per ~10-12 sales
    const reviewMultiplier = isDigital ? 22 : 11;
    const salesFromReviews = Math.round(monthlyReviewVelocity * reviewMultiplier);

    // 4. In-cart 24-48h demand floor
    // Etsy "X in cart" represents rolling 24-48h active shopper carts.
    // E-commerce cart conversion rate is ~15-25%.
    // 20 in cart = ~4 purchases/day * 30 days = 120 sales/mo baseline floor.
    const inCartDailyBuys = inCart > 0 ? (inCart >= 20 ? inCart * 0.20 : inCart * 0.15) : 0;
    const salesFromInCart = Math.round(inCartDailyBuys * 30);

    // 4b. Direct 24h verified sales floor (highest empirical certainty)
    // If a listing sold X in the last 24h, floor monthly estimate at ~X * 28
    const salesFrom24h = sold24h > 0 ? Math.round(sold24h * 28) : 0;

    // 5. Bestseller / Rank baseline floor
    const bestsellerFloor = isBestseller ? 65 : 0;

    // 6. Integrated composite estimation
    let estMonthlySales = Math.max(isBestseller ? 50 : 5, salesFromReviews, salesFromInCart, salesFrom24h, bestsellerFloor);

    // For brand new listings (<6 months) with strong inCart or reviews, amplify breakout signal
    if (ageInMonths <= 6 && (inCart >= 5 || reviewCount >= 10 || sold24h >= 2)) {
      estMonthlySales = Math.max(estMonthlySales, Math.round(Math.max(salesFromInCart, salesFrom24h) * 1.25));
    }

    const estMonthlyRevenue = Math.round(estMonthlySales * price);

    return {
      ageInMonths,
      monthlyReviewVelocity: parseFloat(monthlyReviewVelocity.toFixed(1)),
      sold24h,
      estMonthlySales,
      estMonthlyRevenue
    };
  }

  // ==========================================
  // REVIEW 30-DAY CHRONOLOGICAL REVERSE PARSER
  // ==========================================

  function isWithinLast30Days(dateStr) {
    if (!dateStr || typeof dateStr !== 'string') return false;
    const s = dateStr.trim().toLowerCase();

    // 1. Relative times (always <= 30 days)
    if (s.includes('hour') || s.includes('minute') || s.includes('today') || s.includes('yesterday') || s.includes('just now')) {
      return true;
    }
    const daysMatch = s.match(/(\d+)\s+days?\s+ago/);
    if (daysMatch) {
      return parseInt(daysMatch[1], 10) <= 30;
    }
    const weeksMatch = s.match(/(\d+)\s+weeks?\s+ago/);
    if (weeksMatch) {
      return parseInt(weeksMatch[1], 10) <= 4;
    }
    const monthsMatch = s.match(/(\d+)\s+months?\s+ago/);
    if (monthsMatch) {
      return parseInt(monthsMatch[1], 10) <= 1;
    }

    // 2. Absolute Date parsing
    const parsed = Date.parse(dateStr);
    if (!isNaN(parsed)) {
      const diffMs = Date.now() - parsed;
      const diffDays = diffMs / (1000 * 60 * 60 * 24);
      return diffDays >= 0 && diffDays <= 30;
    }

    // 3. Regex for formats like "Oct 18, 2026" or "18 Oct 2026"
    const m = dateStr.match(/([A-Za-z]{3,9})\s+(\d{1,2}),?\s+(\d{4})/) ||
              dateStr.match(/(\d{1,2})\s+([A-Za-z]{3,9}),?\s+(\d{4})/);
    if (m) {
      const d = new Date(dateStr);
      if (!isNaN(d.getTime())) {
        const diffDays = (Date.now() - d.getTime()) / (1000 * 60 * 60 * 24);
        return diffDays >= 0 && diffDays <= 30;
      }
    }
    return false;
  }

  // ==========================================
  // ETSY 13-TAG SEMANTIC FORMATTER ENGINE
  // ==========================================

  function formatEtsy13Tags(rawPhrases) {
    if (!rawPhrases) return { tags: [], clipboardString: '', isComplete: false };
    const phrases = Array.isArray(rawPhrases) ? rawPhrases : String(rawPhrases).split(/[,|\n]/);
    const cleanTags = new Set();
    const stopWords = new Set(['and', 'the', 'for', 'with', 'a', 'an', 'in', 'of', 'by', 'on', 'to', 'at', 'item', 'listing']);

    for (const phrase of phrases) {
      if (!phrase || typeof phrase !== 'string') continue;
      const normalized = phrase.toLowerCase()
        .replace(/[^a-z0-9\s-]/g, '')
        .replace(/\s+/g, ' ')
        .trim();

      if (!normalized || stopWords.has(normalized)) continue;

      if (normalized.length <= 20) {
        cleanTags.add(normalized);
      } else {
        // Semantic word boundary splitting for tags exceeding Etsy's 20-character limit
        const words = normalized.split(' ');
        let currentChunk = '';
        for (const w of words) {
          if ((currentChunk + ' ' + w).trim().length <= 20) {
            currentChunk = (currentChunk + ' ' + w).trim();
          } else {
            if (currentChunk.length >= 3) cleanTags.add(currentChunk);
            currentChunk = w.slice(0, 20);
          }
        }
        if (currentChunk.length >= 3) cleanTags.add(currentChunk);
      }
      if (cleanTags.size >= 13) break;
    }

    const tagList = Array.from(cleanTags).slice(0, 13);
    return {
      tags: tagList,
      clipboardString: tagList.join(', '),
      isComplete: tagList.length === 13
    };
  }

  function detectPageCurrency() {
    if (userSettings.currencyOverride && userSettings.currencyOverride !== 'auto') {
      return userSettings.currencyOverride;
    }

    const curEl = document.querySelector('.currency-symbol, span.currency-symbol, .lc-price, .currency-value');
    const txt = curEl ? (curEl.parentElement?.innerText || curEl.innerText) : '';
    if (txt.includes('£')) return '£';
    if (txt.includes('€')) return '€';
    if (txt.includes('CA$')) return 'CA$';
    if (txt.includes('AU$') || txt.includes('A$')) return 'AU$';
    if (txt.includes('¥')) return '¥';
    if (txt.includes('₹')) return '₹';

    const bodySnippet = document.body ? document.body.innerText.slice(0, 3000) : '';
    if (bodySnippet.includes('£')) return '£';
    if (bodySnippet.includes('€')) return '€';
    if (bodySnippet.includes('CA$')) return 'CA$';
    if (bodySnippet.includes('AU$')) return 'AU$';
    if (bodySnippet.includes('¥')) return '¥';
    if (bodySnippet.includes('₹')) return '₹';

    return '$';
  }

  function formulateAiVerdict(totalListings, newShopPenetration, score, inCartListings) {
    if (totalListings <= 1500 && newShopPenetration >= 25) {
      return `Prime Inroad Window: Low competition (${totalListings.toLocaleString()} items) with ${newShopPenetration}% Page 1 penetration by new shops.`;
    } else if (totalListings <= 1500) {
      return `Low Competition Ceiling: ${totalListings.toLocaleString()} listings. High probability of ranking on Page 1 with targeted SEO.`;
    } else if (totalListings > 3000) {
      return `Saturated Market: ${totalListings.toLocaleString()} listings. High incumbent dominance. Target micro-niche long-tail tags.`;
    } else {
      return `Steady Market: Moderate velocity with ${inCartListings} active in-cart listings on Page 1.`;
    }
  }

  function makeDraggable(element, handle) {
    if (!element || !handle) return;
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.onmousedown = dragMouseDown;

    function dragMouseDown(e) {
      if (e.target.tagName === 'BUTTON' || e.target.closest('button') || e.target.closest('input') || e.target.closest('select')) return;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;
      document.onmouseup = closeDragElement;
      document.onmousemove = elementDrag;
    }

    function elementDrag(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;

      let newTop = element.offsetTop - pos2;
      let newLeft = element.offsetLeft - pos1;

      const maxLeft = window.innerWidth - element.offsetWidth - 10;
      const maxTop = window.innerHeight - element.offsetHeight - 10;

      newLeft = Math.max(10, Math.min(maxLeft, newLeft));
      newTop = Math.max(10, Math.min(maxTop, newTop));

      element.style.top = newTop + 'px';
      element.style.left = newLeft + 'px';
      element.style.bottom = 'auto';
      element.style.right = 'auto';
    }

    function closeDragElement() {
      document.onmouseup = null;
      document.onmousemove = null;
    }
  }

  function isListingPage() {
    return window.location.pathname.includes('/listing/') || !!window.location.pathname.match(/\/listing\/\d+/);
  }

  function isSoldPage() {
    return !isListingPage() && window.location.pathname.includes('/sold');
  }

  function isFavoritersPage() {
    return !isListingPage() && window.location.pathname.includes('/favoriters');
  }

  function isSearchPage() {
    return !isListingPage() && !isSoldPage() && !isFavoritersPage() && (window.location.pathname.includes('/search') || window.location.search.includes('q='));
  }

  function isShopPage() {
    return !isListingPage() && !isSoldPage() && !isFavoritersPage() && (window.location.pathname.startsWith('/shop/') || window.location.pathname.includes('/shop/'));
  }

  function getSearchQuery() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('q') || document.querySelector('input[name="search_query"]')?.value || 'Current Search';
  }

  function parseTotalListings() {
    // Priority 1: Check primary Etsy search results count elements
    const countSelectors = [
      '[data-search-results-count]',
      '.wt-text-caption[data-count]',
      'h1.wt-text-body-01',
      '[data-results-count]',
      '.wt-text-caption'
    ];

    for (const sel of countSelectors) {
      const el = document.querySelector(sel);
      if (el) {
        const clean = el.innerText.replace(/,/g, '');
        // Crucial: Handle "+" like "1,000+ results" or "10,000+ items"
        const m = clean.match(/([\d]+)\+?\s*(?:results|items|listings)/i);
        if (m && m[1]) {
          const num = parseInt(m[1], 10);
          if (num > 0) return num;
        }
      }
    }

    // Priority 2: Broad subheader scan, prioritizing headings containing "results"
    const subheaders = document.querySelectorAll('h1, h2, span.wt-text-caption, p.wt-text-caption, span');
    for (const el of subheaders) {
      const txt = el.innerText || '';
      if (txt.toLowerCase().includes('result') || txt.toLowerCase().includes('item')) {
        const clean = txt.replace(/,/g, '');
        const m = clean.match(/([\d]+)\+?\s*(?:results|items)/i);
        if (m && m[1]) {
          const num = parseInt(m[1], 10);
          // Ignore small carousel headers (e.g. 4 items or 18 items) if a larger search number exists
          if (num >= 50) return num;
        }
      }
    }

    // Priority 3: Fallback to any match containing results
    for (const el of subheaders) {
      const txt = el.innerText || '';
      if (txt.toLowerCase().includes('result')) {
        const clean = txt.replace(/,/g, '');
        const m = clean.match(/([\d]+)\+?\s*results/i);
        if (m && m[1]) return parseInt(m[1], 10);
      }
    }

    const cards = document.querySelectorAll('.v2-listing-card, [data-palette-listing-id]');
    return cards.length || 0;
  }

  function parseReviewCountString(str) {
    if (!str) return 0;
    const clean = String(str).trim();
    const m = clean.match(/([\d.,]+)\s*([kKmM])?/);
    if (!m) return 0;
    const num = parseFloat(m[1].replace(/,/g, '')) || 0;
    const unit = (m[2] || '').toLowerCase();
    const mult = unit === 'k' ? 1000 : (unit === 'm' ? 1000000 : 1);
    return Math.round(num * mult);
  }

  function extractCardReviewCount(card) {
    if (!card) return 0;

    // Strategy 1: Check aria-labels on rating elements
    const ratingAriaEls = card.querySelectorAll('[aria-label*="star"], [aria-label*="rating"], [aria-label*="out of 5"], [aria-label*="reviews"]');
    for (const el of ratingAriaEls) {
      const aria = el.getAttribute('aria-label') || '';
      const m = aria.match(/([\d.,]+\s*[kKmM]?)\s*(?:shop reviews?|reviews?|ratings?)/i) || aria.match(/\(\s*([\d.,]+\s*[kKmM]?)\s*\)/);
      if (m && m[1]) {
        const count = parseReviewCountString(m[1]);
        if (count > 0) return count;
      }
    }

    // Strategy 2: Check text on rating captions or star element siblings
    const captionEls = card.querySelectorAll('.wt-text-caption, span.wt-text-body-01, span[class*="rating"]');
    for (const el of captionEls) {
      const t = el.innerText.trim();
      if (t.includes('%') || t.toLowerCase().includes('off')) continue;
      const m = t.match(/\(\s*([\d.,]+\s*[kKmM]?)\s*\)/) || t.match(/^([\d.,]+\s*[kKmM]?)$/);
      if (m && m[1]) {
        const count = parseReviewCountString(m[1]);
        if (count > 0) return count;
      }
    }

    // Strategy 3: Global card text search, filtering out discount percentages
    const text = card.innerText || '';
    const parenMatches = text.matchAll(/\(\s*([\d.,]+\s*[kKmM]?)\s*\)/g);
    for (const pm of parenMatches) {
      const idx = pm.index;
      const snippet = text.slice(idx, idx + 25).toLowerCase();
      if (!snippet.includes('%') && !snippet.includes('off') && !snippet.includes('sale')) {
        const count = parseReviewCountString(pm[1]);
        if (count > 0) return count;
      }
    }

    // Fallback: Check anchor tags aria-labels
    const linkEl = card.querySelector('a.listing-link, a[href*="/listing/"]');
    if (linkEl) {
      const aria = linkEl.getAttribute('aria-label') || '';
      const m = aria.match(/([\d.,]+\s*[kKmM]?)\s*(?:reviews?|ratings?)/i) || aria.match(/\(\s*([\d.,]+\s*[kKmM]?)\s*\)/);
      if (m && m[1]) {
        const count = parseReviewCountString(m[1]);
        if (count > 0) return count;
      }
    }

    return 0;
  }

  function extractCardStarRating(card) {
    if (!card) return null;
    const text = card.innerText || '';
    const m = text.match(/\b([1-5]\.[0-9]|[1-5])\s*★/);
    if (m && m[1]) return m[1];

    const ariaEls = card.querySelectorAll('[aria-label*="out of 5"], [aria-label*="stars"]');
    for (const el of ariaEls) {
      const aria = el.getAttribute('aria-label') || '';
      const am = aria.match(/([1-5]\.[0-9]|[1-5])\s*out of 5/i);
      if (am && am[1]) return am[1];
    }
    return null;
  }

  function extractPageListings() {
    const items = [];
    const cardElements = document.querySelectorAll('.v2-listing-card, [data-palette-listing-id], div[data-search-results] ul li');

    cardElements.forEach((card, index) => {
      try {
        const titleEl = card.querySelector('h3, a.listing-link, [data-listing-card-title]');
        const title = titleEl ? titleEl.innerText.trim() : `Listing ${index + 1}`;

        const priceEl = card.querySelector('.currency-value, .wt-text-title-01, span.lc-price');
        let price = 0;
        if (priceEl) {
          const pText = priceEl.innerText.replace(/[^0-9.]/g, '');
          price = parseFloat(pText) || 0;
        }

        const badgeText = card.innerText || '';
        const inCartMatch = badgeText.match(/(\d+)\s*in\s*(?:cart|basket)/i) ||
                            badgeText.match(/in\s*(\d+)\s*(?:cart|basket)/i) ||
                            badgeText.match(/(\d+)\s*people\s+have\s+this\s+in\s+their\s+(?:cart|basket)/i);
        const inCart = inCartMatch ? parseInt(inCartMatch[1], 10) : 0;

        const sold24hMatch = badgeText.match(/(\d+)\s+(?:people\s+)?bought\s+this\s+in\s+the\s+last\s+24\s+hours/i) ||
                             badgeText.match(/(\d+)\s+sold\s+in\s+(?:the\s+last\s+)?24\s*h/i) ||
                             badgeText.match(/(\d+)\s+bought\s+in\s+(?:the\s+last\s+)?24\s*h/i);
        const sold24h = sold24hMatch ? parseInt(sold24hMatch[1], 10) : 0;

        const isBestseller = /bestseller/i.test(badgeText);
        const isStarSeller = /star seller/i.test(badgeText);
        const isFreeShipping = /free shipping/i.test(badgeText);
        const isDigital = /digital|instant download|download|printable|template|spreadsheet|svg|pdf/i.test(badgeText + ' ' + title);

        const reviewCount = extractCardReviewCount(card);
        const starRating = extractCardStarRating(card);

        const linkEl = card.querySelector('a.listing-link, a[href*="/listing/"]');
        const url = linkEl ? (linkEl.href || linkEl.getAttribute('href') || '') : '';
        const idMatch = url.match(/\/listing\/(\d+)/);
        const listingId = idMatch ? idMatch[1] : '';

        const imgEl = card.querySelector('img');
        const imageUrl = imgEl ? (imgEl.src || imgEl.getAttribute('data-src') || '') : '';

        const shopEl = card.querySelector('.v2-listing-card__shop, [data-shop-name], .wt-text-caption, a[href*="/shop/"]');
        const shopName = shopEl ? shopEl.innerText.trim().replace(/\s+/g, ' ') : '';

        const cardAge = getListingAgeString(listingId);
        const salesEst = computeListingSalesEstimates({
          price,
          inCart,
          sold24h,
          reviewCount,
          isBestseller,
          isDigital,
          listingId
        });
        const econ = calculateEconomics(price, userSettings);

        if (price > 0 || title.length > 5) {
          items.push({
            id: index + 1,
            listingId,
            title,
            shopName,
            imageUrl,
            price,
            netTakeHome: econ.netTakeHome,
            marginPct: econ.marginPct,
            inCart,
            sold24h,
            isBestseller,
            isStarSeller,
            isFreeShipping,
            isDigital,
            reviewCount,
            starRating,
            cardAge,
            estMonthlySales: salesEst.estMonthlySales,
            estMonthlyRevenue: salesEst.estMonthlyRevenue,
            monthlyReviewVelocity: salesEst.monthlyReviewVelocity,
            url
          });
        }
      } catch (e) {
        // Skip malformed card
      }
    });

    return items;
  }

  // ==========================================
  // ZERO-REFLOW BATCHED IN-GRID FORENSICS
  // ==========================================

  function extractUrlForensics(urlStr) {
    if (!urlStr) return { isAd: false, isStarSeller: false, isBestseller: false, isEtsysPick: false, freeShipping: false };
    try {
      const u = new URL(urlStr, typeof window !== 'undefined' && window.location ? window.location.origin : 'https://www.etsy.com');
      const params = u.searchParams;
      return {
        isAd: params.get('is_ad') === 'true' || params.has('is_ad') || params.get('ga_view_type') === 'ad',
        isStarSeller: params.get('is_star_seller') === 'true',
        isBestseller: params.get('is_bestseller') === 'true',
        isEtsysPick: params.get('is_etsys_pick') === 'true',
        freeShipping: params.get('shipping_costs') === '0'
      };
    } catch (e) {
      return { isAd: false, isStarSeller: false, isBestseller: false, isEtsysPick: false, freeShipping: false };
    }
  }

  function computeMedianPrice(cards) {
    if (!cards || cards.length === 0) return 0;
    const prices = [];
    cards.forEach(card => {
      if (typeof card === 'number') {
        if (!isNaN(card) && card > 0) prices.push(card);
      } else if (card && typeof card.price === 'number') {
        if (!isNaN(card.price) && card.price > 0) prices.push(card.price);
      } else if (card && card.querySelector) {
        const priceEl = card.querySelector('.currency-value, .wt-text-title-01, span.lc-price');
        if (priceEl) {
          const p = parseFloat((priceEl.innerText || '').replace(/[^0-9.]/g, ''));
          if (!isNaN(p) && p > 0) prices.push(p);
        }
      }
    });
    if (prices.length === 0) return 0;
    prices.sort((a, b) => a - b);
    const mid = Math.floor(prices.length / 2);
    return prices.length % 2 !== 0 ? prices[mid] : (prices[mid - 1] + prices[mid]) / 2;
  }

  function scheduleGridInjection() {
    if (gridInjectionScheduled) return;
    gridInjectionScheduled = true;
    requestAnimationFrame(() => {
      gridInjectionScheduled = false;
      injectInGridCardForensics();
    });
  }

  function getListingAgeString(listingId) {
    const numId = parseInt(listingId, 10);
    if (isNaN(numId) || numId <= 0) return 'Active';
    if (numId > 1950000000) return 'New (2026)';
    if (numId > 1700000000) return '~1-2y';
    if (numId > 1300000000) return '~3-4y';
    if (numId > 900000000) return '~4-5y';
    return '5y+';
  }

  function injectInGridCardForensics() {
    if (isListingPage()) return;

    if (!userSettings.showGridBadges) {
      document.querySelectorAll('.ens-card-strip').forEach(el => el.style.display = 'none');
      return;
    }

    const cards = document.querySelectorAll('.v2-listing-card, [data-palette-listing-id], div[data-search-results] ul li, .wt-grid__item-xs-6, div.js-merch-stash-check-listen');
    if (!cards || cards.length === 0) return;

    const cur = detectPageCurrency();
    const medianPrice = computeMedianPrice(cards);

    let organicRankCount = 0;
    let adRankCount = 0;

    const stopWords = new Set([
      'the', 'and', 'for', 'with', 'in', 'of', 'to', 'a', 'an', 'by', 'on', 'or', 'at',
      'printable', 'digital', 'download', 'template', 'instant', 'editable', 'bundle', 'kit',
      'etsy', 'listing', 'item'
    ]);

    cards.forEach((card, idx) => {
      try {
        if (processedCards.has(card)) {
          const existing = card.querySelector('.ens-card-strip');
          if (existing) {
            existing.style.display = userSettings.showGridBadges ? 'flex' : 'none';
          }
          return;
        }

        if (card.querySelector('.ens-card-strip')) {
          processedCards.add(card);
          return;
        }

        const linkEl = card.querySelector('a.listing-link, a[href*="/listing/"]');
        if (!linkEl) return;

        const urlForensics = extractUrlForensics(linkEl.href || linkEl.getAttribute('href') || '');

        const titleEl = card.querySelector('h3, a.listing-link, [data-listing-card-title]');
        const rawTitle = titleEl ? titleEl.innerText.trim() : `Listing ${idx + 1}`;
        const title = rawTitle.replace(/\s+/g, ' ');

        const priceEl = card.querySelector('.currency-value, .wt-text-title-01, span.lc-price');
        let price = 0;
        if (priceEl) {
          const pText = priceEl.innerText.replace(/[^0-9.]/g, '');
          price = parseFloat(pText) || 0;
        }

        const badgeText = card.innerText || '';
        const inCartMatch = badgeText.match(/(\d+)\s*in\s*cart/i) || badgeText.match(/in\s*(\d+)\s*cart/i);
        const inCart = inCartMatch ? parseInt(inCartMatch[1], 10) : 0;

        const sold24hMatch = badgeText.match(/(\d+)\s+(?:people\s+)?bought\s+this\s+in\s+the\s+last\s+24\s+hours/i) ||
                             badgeText.match(/(\d+)\s+sold\s+in\s+(?:the\s+last\s+)?24\s*h/i) ||
                             badgeText.match(/(\d+)\s+bought\s+in\s+(?:the\s+last\s+)?24\s*h/i);
        const sold24h = sold24hMatch ? parseInt(sold24hMatch[1], 10) : 0;

        if (userSettings.minCartThreshold > 0 && inCart < userSettings.minCartThreshold) {
          processedCards.add(card);
          return;
        }

        const reviewCount = extractCardReviewCount(card);
        const starRating = extractCardStarRating(card);

        // Detect sponsored / ads (Alura 8-selector method + url param)
        const isSponsored = urlForensics.isAd ||
          !!card.querySelector('[data-test-id="ad-badge"], [data-testid="ad-badge"], .ad-badge, .shop-icon-sponsored, [data-sponsored="true"], [data-listing-source="ads"]') ||
          /ad by etsy seller|sponsored/i.test(badgeText) ||
          (card.className && card.className.includes('sponsored'));

        if (isSponsored) {
          adRankCount++;
        } else {
          organicRankCount++;
        }

        const isBestseller = urlForensics.isBestseller || /bestseller/i.test(badgeText);
        const isStarSeller = urlForensics.isStarSeller || /star seller/i.test(badgeText);
        const isEtsysPick = urlForensics.isEtsysPick || /etsy'?s pick/i.test(badgeText);
        const freeShipping = urlForensics.freeShipping || /free shipping/i.test(badgeText);
        const isDigital = /digital|instant download|download|printable|template|spreadsheet|svg|pdf/i.test(badgeText + ' ' + title);

        // Digital Mode Filter Handling
        if (userSettings.filterDigitalOnly && !isDigital) {
          card.style.opacity = '0.35';
          card.style.transition = 'opacity 0.2s ease';
        } else {
          card.style.opacity = '1';
        }

        // Economic calculation with user customizable fees
        const econ = calculateEconomics(price, userSettings);

        let velocityLabel = '🌱 Established';
        let velocityClass = 'ens-velocity-established';
        if (sold24h > 0) {
          velocityLabel = `🔥 ${sold24h} Sold (24h)`;
          velocityClass = 'ens-velocity-viral';
        } else if (inCart >= 10) {
          velocityLabel = '🔥 Viral Demand';
          velocityClass = 'ens-velocity-viral';
        } else if (inCart >= 3) {
          velocityLabel = '⚡ Active Demand';
          velocityClass = 'ens-velocity-active';
        } else if (reviewCount < 50 && inCart > 0) {
          velocityLabel = '🚀 Breakout Inroad';
          velocityClass = 'ens-velocity-breakout';
        } else if (isBestseller) {
          velocityLabel = '⭐ Bestseller';
          velocityClass = 'ens-velocity-active';
        }

        const titleTokens = title.toLowerCase()
          .replace(/[^a-z0-9\s-]/g, ' ')
          .split(/\s+/)
          .filter(w => w.length >= 4 && !stopWords.has(w))
          .slice(0, 5);

        const strip = document.createElement('div');
        strip.className = 'ens-card-strip';
        strip.setAttribute('data-ens-injected', 'true');
        strip.style.display = userSettings.showGridBadges ? 'flex' : 'none';

        const listingIdMatch = (linkEl.href || linkEl.getAttribute('href') || '').match(/\/listing\/(\d+)/);
        const cardListingId = listingIdMatch ? listingIdMatch[1] : '';
        const cardAge = getListingAgeString(cardListingId);
        const primaryKeyword = titleTokens.slice(0, 2).join(' ') || (title.split(/[\s,-]+/)[0] || 'Item');
        const salesEst = computeListingSalesEstimates({
          price,
          inCart,
          sold24h,
          reviewCount,
          isBestseller,
          isDigital,
          listingId: cardListingId
        });
        const estMonthlySales = salesEst.estMonthlySales;

        // 1. The 5-Pillar Core Forensics Ribbon (Top Listing | Keyword | Age | Reviews | Sales)
        const fivePillarHtml = `
          <div class="ens-5pillar-bar" title="5-Pillar Forensics: Top Listing | Keyword | Age | Reviews | Sales">
            <span class="ens-pillar-item pillar-top ${sold24h > 0 || isBestseller ? 'gold' : ''}" title="${sold24h > 0 ? sold24h + ' sold in the last 24 hours' : (isBestseller ? 'Verified Bestseller' : (isSponsored ? 'Sponsored Ad' : 'Rank #' + organicRankCount))}">
              ${sold24h > 0 ? '🔥 ' + sold24h + ' sold/24h' : (isBestseller ? '🏆 Bestseller' : (isSponsored ? '📢 Ad #' + adRankCount : (inCart >= 5 ? '🛒 ' + inCart + ' in cart' : '#' + organicRankCount)))}
            </span>
            <span class="ens-pillar-item pillar-kw" title="Focus Keyword: ${primaryKeyword}">
              🔑 ${primaryKeyword}
            </span>
            <span class="ens-pillar-item pillar-age" title="Listing Age: ${cardAge}">
              📅 ${cardAge}
            </span>
            <span class="ens-pillar-item pillar-reviews" title="${reviewCount > 0 ? reviewCount.toLocaleString() + ' reviews' : 'New Shop (<50 reviews)'}">
              ⭐ ${reviewCount > 0 ? (reviewCount >= 1000 ? (reviewCount/1000).toFixed(1) + 'k' : reviewCount) : 'New'}${starRating ? ' (' + starRating + ')' : ''}
            </span>
            <span class="ens-pillar-item pillar-sales" title="Est. Sales ~${estMonthlySales}/mo · Net Take-Home ${cur}${econ.netTakeHome.toFixed(2)} (${econ.marginPct}%)">
              💰 ~${estMonthlySales}/mo · ${cur}${econ.netTakeHome.toFixed(2)}
            </span>
          </div>
        `;

        // Alura / EverBee Parity: Expanded 2x3 Diagnostic Box
        const expandedBoxHtml = `
          <div class="ens-expanded-box" title="ScoutPro Forensic Matrix (Expanded EverBee/Alura Parity)">
            <div class="ens-exp-header">
              <span class="ens-pillar-item pillar-top ${isBestseller ? 'gold' : ''}">
                ${isBestseller ? '🏆 Bestseller' : (isSponsored ? '📢 Ad #' + adRankCount : '#' + organicRankCount)}
              </span>
              <span class="ens-kw-chip" style="font-weight:600;">🔑 ${primaryKeyword}</span>
              <span class="ens-pillar-item" style="color:#10b981;font-weight:700;">${cur}${econ.netTakeHome.toFixed(2)} Net (${econ.marginPct}%)</span>
            </div>
            <div class="ens-exp-grid">
              <div class="ens-exp-cell">
                <span class="lbl">Mo. Sales</span>
                <span class="val font-green">~${estMonthlySales}/mo</span>
              </div>
              <div class="ens-exp-cell">
                <span class="lbl">Mo. Gross</span>
                <span class="val font-mono">${cur}${Math.round(estMonthlySales * price).toLocaleString()}</span>
              </div>
              <div class="ens-exp-cell">
                <span class="lbl">In-Cart</span>
                <span class="val font-orange">${inCart > 0 ? inCart + ' in cart' : '0'}</span>
              </div>
              <div class="ens-exp-cell">
                <span class="lbl">Listing Age</span>
                <span class="val font-mono">${cardAge}</span>
              </div>
              <div class="ens-exp-cell">
                <span class="lbl">Reviews</span>
                <span class="val">⭐ ${reviewCount > 0 ? (reviewCount >= 1000 ? (reviewCount/1000).toFixed(1) + 'k' : reviewCount) : 'New'}</span>
              </div>
              <div class="ens-exp-cell">
                <span class="lbl">Net Cash</span>
                <span class="val font-emerald">${cur}${econ.netTakeHome.toFixed(2)}</span>
              </div>
            </div>
          </div>
        `;

        // 2. Modular Secondary Row (Keywords & Quick Actions - Expandable/Toggleable)
        let secondaryHtml = '';
        if (userSettings.showFocusKeywords !== false && titleTokens.length > 0) {
          secondaryHtml = `
            <div class="ens-card-secondary">
              <div class="ens-kw-row">
                ${titleTokens.map(kw => `<span class="ens-kw-chip" data-kw="${kw}" title="Click to copy keyword">${kw}</span>`).join('')}
              </div>
              <div class="ens-action-btns">
                <button class="ens-btn-mini ens-btn-copy-tags" title="Copy all keywords">🏷️ Copy</button>
                <button class="ens-btn-mini ens-btn-quick-audit" title="Audit JSON">📋 Audit</button>
              </div>
            </div>
          `;
        }

        const badgeContentHtml = userSettings.badgeStyle === 'expanded' ? expandedBoxHtml : fivePillarHtml;
        strip.innerHTML = badgeContentHtml + secondaryHtml;

        // Keyword Click Copy
        strip.querySelectorAll('.ens-kw-chip').forEach(chip => {
          chip.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            const kw = chip.getAttribute('data-kw');
            navigator.clipboard.writeText(kw).then(() => {
              const orig = chip.innerText;
              chip.innerText = '✓ Copied';
              chip.classList.add('copied');
              setTimeout(() => {
                chip.innerText = orig;
                chip.classList.remove('copied');
              }, 1000);
            });
          });
        });

        // Copy All Tags Button (1-Click Etsy Listing Manager Format)
        const copyTagsBtn = strip.querySelector('.ens-btn-copy-tags');
        copyTagsBtn?.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          const formatted = formatEtsy13Tags(titleTokens.length > 0 ? titleTokens : title.split(' '));
          const tagsStr = formatted.clipboardString || title.slice(0, 30);
          navigator.clipboard.writeText(tagsStr).then(() => {
            copyTagsBtn.innerHTML = `✓ Copied ${formatted.tags.length} Tags!`;
            copyTagsBtn.classList.add('copied');
            setTimeout(() => {
              copyTagsBtn.innerHTML = '🏷️ Copy Tags';
              copyTagsBtn.classList.remove('copied');
            }, 1200);
          });
        });

        // Quick Audit Button
        const auditBtn = strip.querySelector('.ens-btn-quick-audit');
        auditBtn?.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          const cardData = {
            title,
            price: price.toFixed(2),
            netTakeHome: econ.netTakeHome.toFixed(2),
            marginPct: econ.marginPct,
            inCart,
            reviewCount,
            isBestseller,
            isStarSeller,
            isDigital,
            url: linkEl.href
          };
          navigator.clipboard.writeText(JSON.stringify(cardData, null, 2)).then(() => {
            auditBtn.innerHTML = '✓ Copied!';
            auditBtn.classList.add('copied');
            setTimeout(() => {
              auditBtn.innerHTML = '📋 Audit';
              auditBtn.classList.remove('copied');
            }, 1200);
          });
        });

        const cardTarget = card.querySelector('.v2-listing-card__info, .wt-card__body, [data-listing-card-body]') || card;
        if (userSettings.badgePosition === 'top') {
          cardTarget.insertBefore(strip, cardTarget.firstChild);
        } else {
          cardTarget.appendChild(strip);
        }

        processedCards.add(card);
      } catch (err) {
        // Skip malformed card
      }
    });
  }

  function extractTopTags(listings) {
    const stopWords = new Set([
      'the', 'and', 'for', 'with', 'in', 'of', 'to', 'a', 'an', 'by', 'on', 'or', 'at',
      'printable', 'digital', 'download', 'template', 'instant', 'editable', 'bundle', 'kit'
    ]);
    const wordCounts = {};

    listings.forEach(l => {
      const words = l.title.toLowerCase().replace(/[^a-z0-9\s-]/g, ' ').split(/\s+/);
      words.forEach(w => {
        if (w.length >= 4 && !stopWords.has(w)) {
          wordCounts[w] = (wordCounts[w] || 0) + 1;
        }
      });
    });

    return Object.entries(wordCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 6)
      .map(([word]) => word);
  }

  function analyzeNiche() {
    const query = getSearchQuery();
    const totalListings = parseTotalListings();
    let listings = extractPageListings();

    if (listings.length === 0) return null;

    if (filterDigitalOnly) {
      listings = listings.filter(l => l.isDigital);
    }

    const validPrices = listings.map(l => l.price).filter(p => p > 0);
    const avgPrice = validPrices.length ? (validPrices.reduce((a, b) => a + b, 0) / validPrices.length) : 0;
    const minPrice = validPrices.length ? Math.min(...validPrices) : 0;
    const maxPrice = validPrices.length ? Math.max(...validPrices) : 0;

    const inCartListings = listings.filter(l => l.inCart > 0).length;
    const bestsellerCount = listings.filter(l => l.isBestseller).length;
    const starSellerCount = listings.filter(l => l.isStarSeller).length;
    const newShopsCount = listings.filter(l => l.reviewCount < 50).length;
    const newShopPenetration = listings.length ? Math.round((newShopsCount / listings.length) * 100) : 0;

    // Monthly velocity estimation: in_cart items * avgPrice * 3.5 turnover multiplier
    const totalInCartUnits = listings.reduce((sum, l) => sum + (l.inCart || 0), 0);
    const estMonthlyRevenue = Math.round(totalInCartUnits * avgPrice * 3.5);

    const topTags = extractTopTags(listings);

    let score = 70;
    if (totalListings <= 1500) score += 20;
    else if (totalListings <= 3000) score += 5;
    else score -= 25;

    if (newShopPenetration >= 25) score += 10;
    if (inCartListings >= 3) score += 10;
    score = Math.min(Math.max(score, 20), 99);

    let status = 'MODERATE';
    let statusClass = 'status-yellow';
    if (totalListings <= 1500) {
      status = 'HIGH OPPORTUNITY (LOW COMPETITION)';
      statusClass = 'status-green';
    } else if (totalListings > 3000) {
      status = 'HIGH COMPETITION (SATURATED)';
      statusClass = 'status-red';
    }

    const currency = detectPageCurrency();
    const aiVerdict = formulateAiVerdict(totalListings, newShopPenetration, score, inCartListings);

    return {
      type: 'search',
      query,
      currency,
      aiVerdict,
      totalListings,
      listingsAudited: listings.length,
      avgPrice: avgPrice.toFixed(2),
      minPrice: minPrice.toFixed(2),
      maxPrice: maxPrice.toFixed(2),
      inCartListings,
      bestsellerCount,
      starSellerCount,
      newShopPenetration,
      estMonthlyRevenue,
      topTags,
      score,
      status,
      statusClass,
      listings
    };
  }

  function analyzeShop() {
    const match = window.location.pathname.match(/\/shop\/([^\/\?]+)/);
    const shopName = match ? decodeURIComponent(match[1]) : 'Unknown Shop';
    const bodyText = document.body ? document.body.innerText : '';

    let sales = 0;
    let salesVerified = false;
    const salesMatch = bodyText.match(/([\d,]+)\s+Sales/i) || bodyText.match(/([\d,]+)\s+sales/i);
    if (salesMatch) {
      sales = parseInt(salesMatch[1].replace(/,/g, ''), 10);
      salesVerified = true;
    }

    let reviewCount = 0;
    const reviewMatch = bodyText.match(/\(([\d,]+)\)\s*reviews?/i) || bodyText.match(/([\d,]+)\s+shop\s+reviews/i);
    if (reviewMatch) {
      reviewCount = parseInt(reviewMatch[1].replace(/,/g, ''), 10);
    }

    let shopYear = null;
    let shopAgeDesc = 'Unknown';
    const yearMatch = bodyText.match(/On Etsy since\s+(\d{4})/i) || bodyText.match(/Shop owner since\s+(\d{4})/i);
    if (yearMatch) {
      shopYear = parseInt(yearMatch[1], 10);
      const currentYear = new Date().getFullYear();
      const ageYears = currentYear - shopYear;
      shopAgeDesc = ageYears === 0 ? 'Launched this year' : `${ageYears} ${ageYears === 1 ? 'yr' : 'yrs'} old`;
    }

    const isYoung = shopYear !== null && (new Date().getFullYear() - shopYear) <= 1;
    const isBreakout = isYoung && sales >= 100;

    // 1. Capture Shop Listing Cards
    const cards = document.querySelectorAll(
      'div.v2-listing-card, div.responsive-listing-grid [data-listing-id], div.shop-home-wider-items [data-listing-id], div[data-component="shop-listing-card"], .listing-card'
    );

    let totalItems = cards.length;
    const itemsMatch = bodyText.match(/([\d,]+)\s+items?/i) || bodyText.match(/Items\s*\(([\d,]+)\)/i);
    if (itemsMatch) {
      totalItems = parseInt(itemsMatch[1].replace(/,/g, ''), 10);
    }

    // 2. Parse Chronological Reviews & Filter Last 30 Days
    const listingReviewFrequency = {};
    const listingReviewsLast30d = {};

    const reviewCards = document.querySelectorAll(
      '.wt-review-card, [data-review-card], div[data-component="shop-review-card"], .reviews__item, div[data-reviews-container] .wt-grid__item-xs-12'
    );

    reviewCards.forEach(card => {
      const link = card.querySelector('a[href*="/listing/"]');
      const href = link?.getAttribute('href') || link?.href || '';
      const idMatch = href.match(/\/listing\/(\d+)/);
      if (!idMatch) return;
      const id = idMatch[1];

      listingReviewFrequency[id] = (listingReviewFrequency[id] || 0) + 1;

      // Extract review date
      const dateEl = card.querySelector('.wt-text-caption, [data-review-date], time, .wt-text-body-01');
      const dateText = dateEl ? dateEl.innerText.trim() : card.innerText;
      if (isWithinLast30Days(dateText)) {
        listingReviewsLast30d[id] = (listingReviewsLast30d[id] || 0) + 1;
      }
    });

    // Fallback: If no reviewCards matched, scan all listing links
    if (Object.keys(listingReviewFrequency).length === 0) {
      const reviewLinks = document.querySelectorAll('a[href*="/listing/"]');
      reviewLinks.forEach(link => {
        const href = link.getAttribute('href') || link.href || '';
        const m = href.match(/\/listing\/(\d+)/);
        if (m && m[1]) {
          const parentText = link.closest('div')?.innerText || '';
          listingReviewFrequency[m[1]] = (listingReviewFrequency[m[1]] || 0) + 1;
          if (isWithinLast30Days(parentText)) {
            listingReviewsLast30d[m[1]] = (listingReviewsLast30d[m[1]] || 0) + 1;
          }
        }
      });
    }

    // 3. Score Shop Listings for Top 5 Selling SKUs & Expected Sales
    const scoredListings = [];
    cards.forEach(card => {
      const link = card.querySelector('a[href*="/listing/"]');
      const url = link?.href || link?.getAttribute('href') || '';
      const idMatch = url.match(/\/listing\/(\d+)/);
      if (!idMatch) return;
      const id = idMatch[1];

      const titleEl = card.querySelector('.v2-listing-card__title, h3, .wt-text-title-01, [data-listing-title]');
      const title = titleEl ? titleEl.innerText.trim() : 'Listing ' + id;

      const priceEl = card.querySelector('.currency-value, .wt-text-title-01, span.lc-price');
      const price = priceEl ? parseFloat(priceEl.innerText.replace(/[^0-9.]/g, '')) || 0 : 0;

      const urlForensics = extractUrlForensics(url);
      const inCart = extractInCartUrgency(card);
      const cardText = card.innerText || '';

      let sold24h = 0;
      const soldMatch = cardText.match(/(\d+)\s+(?:sold\s+in|bought\s+in)\s+(?:the\s+last\s+)?24\s*(?:h|hours)/i) ||
                        cardText.match(/(\d+)\s+bought\s+this\s+in\s+the\s+last\s+24\s+hours/i) ||
                        cardText.match(/popular\s+now!\s*(\d+)\s+bought/i);
      if (soldMatch) sold24h = parseInt(soldMatch[1], 10);

      const reviewFreq = listingReviewFrequency[id] || 0;
      const reviews30d = listingReviewsLast30d[id] || 0;

      // Reverse-Engineered Expected 30-Day Sales Velocity:
      // - 24h sold floor: sold24h * 28
      // - 30d review multiplier: reviews30d * 22
      // - In-cart demand floor: inCart * 6
      // - Bestseller baseline floor: 35
      const salesFrom24h = sold24h > 0 ? sold24h * 28 : 0;
      const salesFromReviews = reviews30d > 0 ? reviews30d * 22 : (reviewFreq > 0 ? reviewFreq * 8 : 0);
      const salesFromInCart = inCart > 0 ? inCart * 6 : 0;
      const bestsellerFloor = urlForensics.isBestseller ? 35 : 0;

      const estSales30d = Math.max(salesFrom24h, salesFromReviews, salesFromInCart, bestsellerFloor, 5);
      const estRev30d = Math.round(estSales30d * price);

      let velocityScore = (reviews30d * 40) + (reviewFreq * 15) + (inCart * 15) + (sold24h * 35) + (urlForensics.isBestseller ? 100 : 0);

      scoredListings.push({
        id,
        title,
        price,
        url,
        isBestseller: urlForensics.isBestseller,
        inCart,
        sold24h,
        reviewFreq,
        reviews30d,
        estSales30d,
        estRev30d,
        velocityScore
      });
    });

    scoredListings.sort((a, b) => b.velocityScore - a.velocityScore);
    const topBestsellers = scoredListings.slice(0, 5);
    const topReviewed30d = scoredListings.filter(l => l.reviews30d > 0).sort((a, b) => b.reviews30d - a.reviews30d);

    let verdict = 'ESTABLISHED STORE';
    let statusClass = 'status-yellow';
    if (isBreakout) {
      verdict = 'VIRAL BREAKOUT SHOP (NEW & HIGH SALES)';
      statusClass = 'status-green';
    } else if (sales > 1000) {
      verdict = 'HIGH AUTHORITY VETERAN SHOP';
      statusClass = 'status-green';
    } else if (sales < 50 && !isYoung) {
      verdict = 'LOW VELOCITY / STAGNANT SHOP';
      statusClass = 'status-red';
    }

    return {
      type: 'shop',
      currency: detectPageCurrency(),
      shopName,
      sales,
      salesVerified,
      reviewCount,
      shopYear,
      shopAgeDesc,
      isYoung,
      totalItems,
      isBreakout,
      verdict,
      statusClass,
      topBestsellers,
      topReviewed30d
    };
  }

  function analyzeSoldListings() {
    const match = window.location.pathname.match(/\/shop\/([^\/\?]+)/);
    const shopName = match ? decodeURIComponent(match[1]) : 'Unknown Shop';
    const cards = document.querySelectorAll('div.v2-listing-card, div.responsive-listing-grid [data-listing-id], div.shop-home-wider-items [data-listing-id]');
    
    const soldFrequency = {};
    let estGrossSold = 0;

    cards.forEach(card => {
      const link = card.querySelector('a[href*="/listing/"]');
      const href = link?.href || link?.getAttribute('href') || '';
      const idMatch = href.match(/\/listing\/(\d+)/);
      if (!idMatch) return;
      const id = idMatch[1];

      const titleEl = card.querySelector('.v2-listing-card__title, h3, .wt-text-title-01');
      const title = titleEl ? titleEl.innerText.trim() : 'Sold Listing ' + id;

      const priceEl = card.querySelector('.currency-value, .wt-text-title-01, span.lc-price');
      const price = priceEl ? parseFloat(priceEl.innerText.replace(/[^0-9.]/g, '')) || 0 : 0;

      soldFrequency[id] = soldFrequency[id] || { count: 0, title, price, url: href };
      soldFrequency[id].count += 1;
      estGrossSold += price;
    });

    const leaderboard = Object.values(soldFrequency).sort((a, b) => b.count - a.count);

    return {
      type: 'sold',
      shopName,
      currency: detectPageCurrency(),
      totalSoldAudited: cards.length,
      uniqueSoldProducts: leaderboard.length,
      estGrossSold: estGrossSold.toFixed(2),
      leaderboard: leaderboard.slice(0, 10),
      listings: leaderboard.map((l, i) => ({
        id: String(i + 1),
        title: l.title,
        price: l.price,
        inCart: l.count,
        reviewCount: 0,
        isBestseller: i === 0,
        isStarSeller: false,
        isDigital: false,
        url: l.url
      }))
    };
  }

  function analyzeFavoriters() {
    const match = window.location.pathname.match(/\/shop\/([^\/\?]+)/);
    const shopName = match ? decodeURIComponent(match[1]) : 'Unknown Shop';
    const bodyText = document.body ? document.body.innerText : '';
    
    let admirersCount = 0;
    const matchAdm = bodyText.match(/([\d,]+)\s+admirers/i) || bodyText.match(/([\d,]+)\s+favorited/i);
    if (matchAdm) admirersCount = parseInt(matchAdm[1].replace(/,/g, ''), 10);

    const buyerAvatars = document.querySelectorAll('a[href*="/people/"], .wt-grid__item-xs [data-user-id]');

    return {
      type: 'favoriters',
      shopName,
      admirersCount,
      visibleBuyers: buyerAvatars.length,
      velocityRating: admirersCount > 1000 ? '🔥 High Brand Affinity' : '🌱 Growing Community'
    };
  }

  function auditRedundantTags(title, tags) {
    if (!tags) return [];
    const titleWords = new Set(
      (title || '').toLowerCase()
        .replace(/[^a-z0-9\s]/g, ' ')
        .split(/\s+/)
        .filter(w => w.length > 2)
    );

    const tagList = Array.isArray(tags) ? tags : Array.from(tags);
    return tagList.map(tag => {
      const tagName = typeof tag === 'string' ? tag : (tag && tag.name ? tag.name : String(tag || ''));
      const tagWords = tagName.toLowerCase().split(/\s+/).filter(w => w.length > 2);
      const isRedundant = tagWords.length > 0 && tagWords.every(w => titleWords.has(w));
      return {
        name: tagName,
        length: tagName.length,
        isTooLong: tagName.length > 20,
        isRedundant: isRedundant
      };
    });
  }

  function analyzeListing() {
    const pathname = window.location.pathname;
    const listingIdMatch = pathname.match(/\/listing\/(\d+)/);
    const listingId = listingIdMatch ? listingIdMatch[1] : 'Unknown';

    // 1. Title & Character Count (140-char max SEO audit)
    const titleEl = document.querySelector('h1[data-buy-box-listing-title]') ||
                    document.querySelector('h1.wt-text-body-01') ||
                    document.querySelector('h1.wt-text-title-01') ||
                    document.querySelector('h1');
    const rawTitle = titleEl ? titleEl.innerText.trim() : document.title.replace(/\|.*$/, '').trim();
    const title = rawTitle.replace(/\s+/g, ' ');
    const titleLength = title.length;
    const titleMobilePreview = title.slice(0, 40);

    // 2. Price, Original Price, Discount
    let price = 0;
    let originalPrice = 0;
    let discountPercent = 0;

    const priceEl = document.querySelector('[data-buy-box-region="price"] .wt-text-title-larger') ||
                    document.querySelector('.wt-text-title-larger') ||
                    document.querySelector('.lc-price');
    if (priceEl) {
      const match = priceEl.innerText.replace(/,/g, '').match(/[\$£€]?\s*([\d.]+)/);
      if (match) price = parseFloat(match[1]) || 0;
    }

    const origPriceEl = document.querySelector('.wt-text-strikethrough');
    if (origPriceEl) {
      const match = origPriceEl.innerText.replace(/,/g, '').match(/[\$£€]?\s*([\d.]+)/);
      if (match) originalPrice = parseFloat(match[1]) || 0;
    }

    if (originalPrice > price && price > 0) {
      discountPercent = Math.round(((originalPrice - price) / originalPrice) * 100);
    }

    // 3. Live Buyer Urgency Signals (DOM Mining - US & International)
    const pageText = document.body ? document.body.innerText : '';
    let sold24h = 0;
    const sold24hMatch = pageText.match(/(\d+)\s+(?:people\s+)?bought\s+this\s+in\s+the\s+last\s+24\s+hours/i) ||
                         pageText.match(/(\d+)\s+(?:sold\s+in|bought\s+in)\s+(?:the\s+last\s+)?24\s*(?:h|hours)/i) ||
                         pageText.match(/popular\s+now!\s*(\d+)\s+bought/i);
    if (sold24hMatch) sold24h = parseInt(sold24hMatch[1], 10);

    let inCart = 0;
    const inCartMatch = pageText.match(/in\s*(\d+)\s*(?:people['’]?s\s*)?(?:carts?|baskets?)/i) ||
                        pageText.match(/(\d+)\s*(?:people\s*)?(?:have\s*this|in\s*their\s*(?:cart|basket)|in\s*(?:cart|basket))/i) ||
                        pageText.match(/(\d+)\s*in\s*(?:cart|basket)/i);
    if (inCartMatch) inCart = parseInt(inCartMatch[1], 10);

    let views24h = 0;
    const viewsMatch = pageText.match(/(\d+)\s*(?:people\s*)?viewed\s*this\s*in\s*the\s*last\s*24/i) ||
                       pageText.match(/(\d+)\s*views?\s*in\s*the\s*last\s*24/i);
    if (viewsMatch) views24h = parseInt(viewsMatch[1], 10);

    let stockRemaining = null;
    const stockMatch = pageText.match(/only\s*(\d+)\s*left/i);
    if (stockMatch) stockRemaining = parseInt(stockMatch[1], 10);

    const isBestseller = /bestseller/i.test(document.querySelector('[data-buy-box-region="badges"]')?.innerText || '') ||
                         document.querySelector('.wt-badge--bestseller') !== null ||
                         /bestseller/i.test(document.querySelector('.wt-badge')?.innerText || '');

    const isStarSeller = /star seller/i.test(document.querySelector('[data-buy-box-region="shop-header"]')?.innerText || '') ||
                         /star seller/i.test(pageText.slice(0, 3000));

    // 4. Listing Age & Days Active (from Script Epoch, JSON-LD, or Sequential ID)
    let publishedDate = null;
    let daysActive = 0;
    let dateStr = 'Active';
    let ageLabel = 'Active';

    // Step A: Inspect inline script tags for precise creation timestamps
    const scriptTags = document.querySelectorAll('script:not([src])');
    for (const s of scriptTags) {
      const txt = s.innerText;
      if (txt.includes('creation_ts') || txt.includes('original_creation') || txt.includes('listing_creation')) {
        const epochMatch = txt.match(/"(?:original_creation_tsz|creation_tsz|original_creation_timestamp|listing_creation_tsz)"\s*:\s*(\d{10})/i);
        if (epochMatch && epochMatch[1]) {
          const epoch = parseInt(epochMatch[1], 10);
          if (epoch > 1200000000 && epoch < 2500000000) {
            publishedDate = new Date(epoch * 1000);
            break;
          }
        }
        const isoMatch = txt.match(/"(?:original_creation_date|creation_date|date_created)"\s*:\s*"([^"]+)"/i);
        if (isoMatch && isoMatch[1]) {
          const d = new Date(isoMatch[1]);
          if (!isNaN(d.getTime())) {
            publishedDate = d;
            break;
          }
        }
      }
    }

    // Step B: JSON-LD Product dates
    const jsonLdScripts = document.querySelectorAll('script[type="application/ld+json"]');
    if (!publishedDate) {
      for (const script of jsonLdScripts) {
        try {
          const parsed = JSON.parse(script.innerText);
          const items = Array.isArray(parsed) ? parsed : (parsed['@graph'] ? parsed['@graph'] : [parsed]);
          for (const item of items) {
            const candidateDate = item.datePublished || item.releaseDate || item.dateCreated;
            if (candidateDate) {
              const d = new Date(candidateDate);
              if (!isNaN(d.getTime())) {
                publishedDate = d;
                break;
              }
            }
          }
          if (publishedDate) break;
        } catch (e) {}
      }
    }

    // Step C: Meta tags
    if (!publishedDate) {
      const metaDate = document.querySelector('meta[property="article:published_time"]')?.content ||
                       document.querySelector('meta[name="date"]')?.content ||
                       document.querySelector('meta[property="og:updated_time"]')?.content;
      if (metaDate) {
        const d = new Date(metaDate);
        if (!isNaN(d.getTime())) publishedDate = d;
      }
    }

    // Step D: DOM "Listed on [Date]"
    if (!publishedDate && pageText) {
      const listedMatch = pageText.match(/listed\s+on\s+([A-Za-z]{3,9}\s+\d{1,2},\s+\d{4})/i);
      if (listedMatch) {
        const d = new Date(listedMatch[1]);
        if (!isNaN(d.getTime())) publishedDate = d;
      }
    }

    // Step E: Reviews earliest date lower bound
    if (!publishedDate) {
      const dateEls = document.querySelectorAll('.wt-review-card .wt-text-caption, [data-review-date], .reviews__date');
      let earliestReviewDate = null;
      for (const el of dateEls) {
        const t = el.innerText.trim();
        const dm = t.match(/(\d{1,2}\s+[A-Za-z]{3,9},?\s+\d{4})/);
        if (dm) {
          const rd = new Date(dm[1]);
          if (!isNaN(rd.getTime()) && (!earliestReviewDate || rd < earliestReviewDate)) {
            earliestReviewDate = rd;
          }
        }
      }
      if (earliestReviewDate) publishedDate = earliestReviewDate;
    }

    // Formulate verified Age and Label
    if (publishedDate && !isNaN(publishedDate.getTime())) {
      daysActive = Math.max(1, Math.floor((Date.now() - publishedDate.getTime()) / (1000 * 60 * 60 * 24)));
      if (daysActive <= 30) {
        ageLabel = `${daysActive}d (New Listing)`;
      } else if (daysActive < 365) {
        ageLabel = `${daysActive} days`;
      } else {
        const years = (daysActive / 365).toFixed(1);
        ageLabel = `${daysActive}d (~${years}y)`;
      }
      dateStr = `${daysActive}d active (${publishedDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })})`;
    } else {
      // Intelligent sequential ID estimation - NEVER falsely say "New Listing" when ID is old!
      const numId = parseInt(listingId, 10);
      if (!isNaN(numId) && numId > 0) {
        if (numId > 1950000000) {
          ageLabel = 'New (2026)';
          dateStr = 'Active (2026)';
          daysActive = 30;
        } else if (numId > 1700000000) {
          ageLabel = '~1-2y (2024-2025)';
          dateStr = 'Est. 2024-2025';
          daysActive = 400;
        } else if (numId > 1300000000) {
          ageLabel = '~3-4y (2022-2023)';
          dateStr = 'Est. 2022-2023';
          daysActive = 900;
        } else if (numId > 900000000) {
          ageLabel = '~4-5y (2020-2021)';
          dateStr = 'Est. 2020-2021';
          daysActive = 1500;
        } else {
          ageLabel = '5y+ (Legacy)';
          dateStr = 'Established legacy';
          daysActive = 2000;
        }
      } else {
        ageLabel = 'Active';
        dateStr = 'Active listing';
        daysActive = 0;
      }
    }

    // 5. Extract ALL 13 Backend Tags (Strictly Capped at 13)
    const tagsFound = new Set();
    const tagSelectors = [
      'div[data-component="listing-page-tags"] a',
      '#wt-listing-tags a',
      'div[data-tags] a',
      'ul.wt-action-group a',
      'div[data-palette-listing-tags] a'
    ];

    tagSelectors.forEach(sel => {
      document.querySelectorAll(sel).forEach(el => {
        const text = el.innerText.trim();
        if (text && text.length > 1 && !text.toLowerCase().includes('explore related') && !text.toLowerCase().includes('see more')) {
          tagsFound.add(text);
        }
      });
    });

    if (tagsFound.size === 0) {
      const bottomLinks = document.querySelectorAll('a[href*="/market/"], a[href*="/search?q="]');
      bottomLinks.forEach(el => {
        if (el.closest('footer') || el.closest('[data-component="listing-page-tags"]') || el.closest('#wt-listing-tags') || el.closest('.wt-flex-wrap')) {
          const text = el.innerText.trim();
          if (text && text.length > 1 && text.length <= 40) {
            tagsFound.add(text);
          }
        }
      });
    }

    if (tagsFound.size < 13) {
      for (const s of scriptTags) {
        const content = s.innerText;
        if (content.includes('"tags":') || content.includes('listing_tags')) {
          const m = content.match(/"tags"\s*:\s*\[([^\]]+)\]/) || content.match(/"listing_tags"\s*:\s*\[([^\]]+)\]/);
          if (m && m[1]) {
            const rawTags = m[1].split(',');
            rawTags.forEach(t => {
              const clean = t.replace(/["'\\]/g, '').trim();
              if (clean && clean.length > 1 && clean.length < 50) tagsFound.add(clean);
            });
          }
        }
      }
    }

    const tagsList = auditRedundantTags(title, Array.from(tagsFound).slice(0, 13));

    // 6. Listing Type & Digital Delivery Detection
    const isDigital = /digital download|instant download|instant digital download/i.test(pageText.slice(0, 5000));
    const formatsDetected = [];
    ['PDF', 'ZIP', 'XLSX', 'Excel', 'Google Sheets', 'Canva', 'PNG', 'SVG', 'CSV'].forEach(fmt => {
      const re = new RegExp(`\\b${fmt}\\b`, 'i');
      if (re.test(pageText.slice(0, 5000)) || re.test(title)) {
        formatsDetected.push(fmt);
      }
    });

    // 7. Item-Specific Reviews (Multi-Tier 2026 Engine)
    let listingReviews = 0;

    // Tier 1: JSON-LD Product aggregateRating (authoritative Schema.org data)
    for (const script of jsonLdScripts) {
      try {
        const parsed = JSON.parse(script.innerText);
        const items = Array.isArray(parsed) ? parsed : (parsed['@graph'] ? parsed['@graph'] : [parsed]);
        for (const item of items) {
          if (item && (item['@type'] === 'Product' || item.aggregateRating)) {
            const agg = item.aggregateRating;
            if (agg) {
              const count = parseReviewCountString(agg.reviewCount || agg.ratingCount);
              if (count > 0) {
                listingReviews = count;
                break;
              }
            }
          }
        }
        if (listingReviews > 0) break;
      } catch (e) {}
    }

    // Tier 2: Specific 2026 DOM Patterns on Etsy
    if (listingReviews === 0) {
      // 2A: Direct "Item average (13 reviews)" pattern (2026 Etsy layout)
      const itemAvgMatch = pageText.match(/Item\s+average\s*\(\s*([\d.,]+\s*[kKmM]?)\s*reviews?\s*\)/i) ||
                           pageText.match(/\(\s*([\d.,]+\s*[kKmM]?)\s*reviews?\s*\)\s*Item\s+average/i);
      if (itemAvgMatch && itemAvgMatch[1]) {
        listingReviews = parseReviewCountString(itemAvgMatch[1]);
      }
    }

    if (listingReviews === 0) {
      // 2B: "Reviews for this item" section heading with nearby count
      const reviewsHeadingBlock = pageText.match(/Reviews\s+for\s+this\s+item[\s\S]{0,600}?\(\s*([\d.,]+\s*[kKmM]?)\s*reviews?\s*\)/i) ||
                                  pageText.match(/Reviews\s+for\s+this\s+item[\s\S]{0,600}?([\d.,]+\s*[kKmM]?)\s*reviews?/i);
      if (reviewsHeadingBlock && reviewsHeadingBlock[1]) {
        listingReviews = parseReviewCountString(reviewsHeadingBlock[1]);
      }
    }

    if (listingReviews === 0) {
      // 2C: Targeted DOM selectors for review counters
      const countSelectors = [
        '[data-reviews-count]',
        '[data-item-review-count]',
        '.reviews__item-count',
        '#item-reviews-count',
        '#reviews-tab-item span',
        'button[aria-label*="reviews"]',
        'a[aria-label*="reviews"]'
      ];
      for (const sel of countSelectors) {
        const el = document.querySelector(sel);
        if (el) {
          const text = el.innerText || el.getAttribute('aria-label') || '';
          const m = text.match(/([\d.,]+\s*[kKmM]?)\s*reviews?/i) || text.match(/\(\s*([\d.,]+\s*[kKmM]?)\s*\)/);
          if (m && m[1]) {
            const count = parseReviewCountString(m[1]);
            if (count > 0) {
              listingReviews = count;
              break;
            }
          }
        }
      }
    }

    if (listingReviews === 0) {
      // 2D: Global page text fallback matching
      const reviewTabMatch = pageText.match(/reviews\s+for\s+this\s+item\s*\(\s*([\d.,]+\s*[kKmM]?)\s*\)/i) ||
                             pageText.match(/\(\s*([\d.,]+\s*[kKmM]?)\s*\)\s*reviews\s+for\s+this\s+item/i) ||
                             pageText.match(/\(\s*([\d.,]+\s*[kKmM]?)\s*item\s+reviews?\s*\)/i) ||
                             pageText.match(/based\s+on\s+([\d.,]+\s*[kKmM]?)\s*(?:item\s+)?reviews?/i);
      if (reviewTabMatch && reviewTabMatch[1]) {
        listingReviews = parseReviewCountString(reviewTabMatch[1]);
      }
    }

    // Tier 3: Review Filter Pills Maximum (e.g. Appearance (9), Quality (6) in reviews section)
    if (listingReviews === 0) {
      const reviewsContainer = document.querySelector('#reviews, [data-reviews-container], div[data-component="listing-reviews"]');
      if (reviewsContainer) {
        let maxPill = 0;
        const pills = reviewsContainer.querySelectorAll('button, span, div');
        pills.forEach(p => {
          const t = p.innerText.trim();
          const pm = t.match(/\(\s*([\d,]+)\s*\)/);
          if (pm && pm[1]) {
            const num = parseInt(pm[1].replace(/,/g, ''), 10);
            if (num > maxPill && num < 100000) maxPill = num;
          }
        });
        if (maxPill > 0) listingReviews = maxPill;
      }
    }

    // Tier 4: Safety Floor - Physical rendered review cards
    const reviewCards = document.querySelectorAll('.wt-review-card, div[data-reviews-container] p, [data-review-text], [data-review-card]');
    if (listingReviews === 0 && reviewCards.length > 0) {
      const distinctCards = document.querySelectorAll('.wt-review-card, [data-review-card]');
      listingReviews = distinctCards.length > 0 ? distinctCards.length : 1;
    }

    // 8. 4-Quadrant Competitor Review Friction Miner (Reddit & BHW Top Feature)
    const frictionLexicon = {
      technical: ['broken', 'error', 'formula', 'corrupted', 'not working', 'glitch', 'bug', 'crash'],
      compatibility: ['mac', 'ipad', 'excel', 'google sheets', 'canva', 'mobile', 'version', 'font missing'],
      usability: ['confusing', 'hard to use', 'complicated', 'unclear', 'no instructions', 'tiny', 'small', 'hard'],
      value: ['disappointed', 'refund', 'blurry', 'misleading', 'not as pictured', 'waste', 'poor']
    };
    const minedFriction = [];
    const categorizedFriction = { technical: [], compatibility: [], usability: [], value: [] };

    reviewCards.forEach(c => {
      const t = c.innerText.toLowerCase();
      Object.keys(frictionLexicon).forEach(category => {
        frictionLexicon[category].forEach(k => {
          if (t.includes(k)) {
            if (!minedFriction.includes(k)) minedFriction.push(k);
            if (!categorizedFriction[category].includes(k)) categorizedFriction[category].push(k);
          }
        });
      });
    });

    // 9. Fee Breakdown & Net Take-Home Calculation (via userSettings)
    const econ = calculateEconomics(price, userSettings);

    // 10. Algorithmic Expected Sales & Revenue Estimates
    const salesEst = computeListingSalesEstimates({
      price,
      inCart,
      sold24h,
      reviewCount: listingReviews,
      isBestseller,
      isDigital,
      listingId
    });

    // 11. Breakout Velocity Index & Verdict
    let velocityScore = 50;
    if (sold24h >= 5) velocityScore += 35;
    else if (sold24h > 0) velocityScore += 20;

    if (inCart >= 10) velocityScore += 25;
    else if (inCart >= 3) velocityScore += 15;

    if (views24h >= 20) velocityScore += 15;
    if (daysActive > 0 && daysActive <= 90 && listingReviews >= 5) velocityScore += 25;
    if (isBestseller) velocityScore += 10;
    velocityScore = Math.min(Math.max(velocityScore, 20), 99);

    let status = 'MODERATE VELOCITY';
    let statusClass = 'status-yellow';
    if (sold24h >= 5 || inCart >= 10 || (daysActive > 0 && daysActive <= 90 && listingReviews >= 5)) {
      status = 'VIRAL BREAKOUT LISTING';
      statusClass = 'status-green';
    } else if (sold24h > 0 || inCart >= 4 || views24h >= 15) {
      status = 'HIGH BUYER DEMAND';
      statusClass = 'status-green';
    } else if (daysActive > 730 && inCart === 0 && sold24h === 0) {
      status = 'DORMANT INCUMBENT';
      statusClass = 'status-red';
    }

    return {
      type: 'listing',
      currency: detectPageCurrency(),
      listingId,
      title,
      titleLength,
      titleMobilePreview,
      price: price.toFixed(2),
      originalPrice: originalPrice > 0 ? originalPrice.toFixed(2) : null,
      discountPercent,
      sold24h,
      inCart,
      views24h,
      stockRemaining,
      isBestseller,
      isStarSeller,
      isDigital,
      formatsDetected,
      listingReviews,
      estMonthlySales: salesEst.estMonthlySales,
      estMonthlyRevenue: salesEst.estMonthlyRevenue,
      monthlyReviewVelocity: salesEst.monthlyReviewVelocity,
      dateStr,
      ageLabel,
      daysActive,
      tags: tagsList,
      minedFriction,
      categorizedFriction,
      netTakeHome: econ.netTakeHome.toFixed(2),
      profitMargin: econ.marginPct,
      totalEtsyFees: econ.totalFees.toFixed(2),
      velocityScore,
      status,
      statusClass
    };
  }

  function copyAgentReachPrompt(data) {
    if (!data) return;
    const tagsString = (data.tags || []).map(t => t.name).join(', ');
    const prompt = `/agent-reach Search Reddit (r/EtsySellers, r/etsy) and Exa for buyer complaints, unmet feature demands, and trending search spikes for Etsy listing: "${data.title}" (Tags: ${tagsString}). Extract the top 3 product friction points and competitor design weaknesses.`;
    copyTextToClipboard(prompt);
  }

  function exportCsv(data) {
    if (!data || !data.listings || data.listings.length === 0) return;
    const headers = ['#', 'Listing ID', 'Title', 'Shop Name', 'Retail Price', 'Net Take-Home', 'Margin %', 'Est Monthly Sales', 'Est Monthly Revenue', '24h Sold', 'In Cart', 'Bestseller', 'Star Seller', 'Digital', 'Review Count', 'Listing Age', 'URL'];
    const rows = data.listings.map((l, i) => {
      const econ = calculateEconomics(l.price, userSettings);
      return [
        i + 1,
        `"${l.listingId || ''}"`,
        `"${(l.title || '').replace(/"/g, '""')}"`,
        `"${(l.shopName || '').replace(/"/g, '""')}"`,
        (l.price || 0).toFixed(2),
        econ.netTakeHome.toFixed(2),
        `${econ.marginPct}%`,
        l.estMonthlySales || 0,
        l.estMonthlyRevenue || 0,
        l.sold24h || 0,
        l.inCart || 0,
        l.isBestseller ? 'YES' : 'NO',
        l.isStarSeller ? 'YES' : 'NO',
        l.isDigital ? 'YES' : 'NO',
        l.reviewCount || 0,
        `"${l.cardAge || ''}"`,
        `"${l.url || ''}"`
      ];
    });
    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `Etsy_ScoutPro_${(data.query || 'niche').replace(/[^a-zA-Z0-9]/g, '_')}_${Date.now()}.csv`;
    link.click();
  }

  function copyTextToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
      const dot = document.querySelector('.ens-dot');
      if (dot) {
        dot.style.background = '#34d399';
        setTimeout(() => { dot.style.background = '#d9f99d'; }, 1000);
      }
      recordSuccessActionAndCheckReviewPrompt();
    });
  }

  function recordSuccessActionAndCheckReviewPrompt() {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get(['cws_action_count', 'cws_review_dismissed'], (res) => {
        if (res && res.cws_review_dismissed) return;
        const currentCount = ((res && res.cws_action_count) || 0) + 1;
        chrome.storage.local.set({ cws_action_count: currentCount });
        if (currentCount >= 5) {
          showCwsReviewToast();
        }
      });
    }
  }

  function showCwsReviewToast() {
    if (document.getElementById('ens-cws-review-toast')) return;
    const toast = document.createElement('div');
    toast.id = 'ens-cws-review-toast';
    toast.innerHTML = `
      <div class="ens-cws-toast-inner">
        <div class="ens-cws-toast-text">
          <strong>Enjoying Niche Scout Pro?</strong>
          <span>A 5-star review helps us keep core research 100% free!</span>
        </div>
        <div class="ens-cws-toast-actions">
          <a href="https://chromewebstore.google.com/detail/niche-scout-pro-etsy-product-research" target="_blank" rel="noopener noreferrer" id="ens-cws-review-yes" class="ens-cws-toast-btn primary">⭐ Rate 5 Stars</a>
          <button id="ens-cws-review-dismiss" class="ens-cws-toast-btn secondary">Maybe Later</button>
        </div>
      </div>
    `;
    document.body.appendChild(toast);

    document.getElementById('ens-cws-review-yes')?.addEventListener('click', () => {
      chrome.storage.local.set({ cws_review_dismissed: true });
      toast.remove();
    });

    document.getElementById('ens-cws-review-dismiss')?.addEventListener('click', () => {
      chrome.storage.local.set({ cws_review_dismissed: true });
      toast.remove();
    });
  }

  // ==========================================
  // SETTINGS DRAWER MODAL COMPONENT
  // ==========================================

  function renderSettingsDrawer() {
    let drawer = document.getElementById('ens-settings-drawer');
    if (!drawer) {
      drawer = document.createElement('div');
      drawer.id = 'ens-settings-drawer';
      drawer.className = 'ens-drawer-overlay';
      document.body.appendChild(drawer);
    }

    const cur = detectPageCurrency();
    const simEcon = calculateEconomics(15.00, userSettings);

    drawer.innerHTML = `
      <div class="ens-drawer-panel">
        <div class="ens-drawer-header">
          <div class="ens-drawer-title">
            ${renderSvg('sliders', 16)}
            <strong>Scout Settings & Economics</strong>
          </div>
          <button class="ens-icon-btn" id="ens-close-drawer-btn" title="Close Settings">
            ${renderSvg('close', 14)}
          </button>
        </div>

        <div class="ens-drawer-body">
          <!-- Fee Sliders -->
          <div class="ens-settings-section">
            <div class="ens-settings-title">Profit & Fee Simulation</div>
            
            <div class="ens-setting-row">
              <label>Transaction Fee: <strong id="val-tx-fee">${userSettings.txFeePct}%</strong></label>
              <input type="range" class="ens-range-slider" id="slider-tx-fee" min="0" max="15" step="0.5" value="${userSettings.txFeePct}">
            </div>

            <div class="ens-setting-row">
              <label>Payment Processing: <strong id="val-proc-fee">${userSettings.paymentProcessingFeePct}% + $${userSettings.paymentProcessingFixed.toFixed(2)}</strong></label>
              <input type="range" class="ens-range-slider" id="slider-proc-fee" min="0" max="10" step="0.2" value="${userSettings.paymentProcessingFeePct}">
            </div>

            <div class="ens-setting-row">
              <label>Offsite Ads Fee:</label>
              <select class="ens-select" id="select-offsite-ads">
                <option value="0.0" ${userSettings.offsiteAdsPct === 0 ? 'selected' : ''}>0% (Standard Organic)</option>
                <option value="12.0" ${userSettings.offsiteAdsPct === 12 ? 'selected' : ''}>12% (High-Volume Seller)</option>
                <option value="15.0" ${userSettings.offsiteAdsPct === 15 ? 'selected' : ''}>15% (Under $10k Threshold)</option>
              </select>
            </div>

            <div class="ens-sim-box">
              <div class="ens-sim-header">Live Simulation for ${cur}15.00 Item</div>
              <div class="ens-sim-val">Net Take-Home: <strong class="text-green">${cur}${simEcon.netTakeHome.toFixed(2)}</strong> (${simEcon.marginPct}% Margin)</div>
              <div class="ens-sim-sub">Total Etsy cut: ${cur}${simEcon.totalFees.toFixed(2)}</div>
            </div>
          </div>

          <!-- In-Grid Controls -->
          <div class="ens-settings-section">
            <div class="ens-settings-title">In-Grid Badges & Display</div>

            <div class="ens-setting-row">
              <label>Badge Display Style (Alura & EverBee Parity):</label>
              <select class="ens-select" id="select-badge-style">
                <option value="compact" ${userSettings.badgeStyle === 'compact' ? 'selected' : ''}>Compact (Sleek 1-Line 5-Pillar Ribbon)</option>
                <option value="expanded" ${userSettings.badgeStyle === 'expanded' ? 'selected' : ''}>Expanded (Alura & EverBee 2x3 Box)</option>
              </select>
            </div>

            <div class="ens-switch-row">
              <span>Show In-Grid Product Badges</span>
              <label class="ens-switch">
                <input type="checkbox" id="switch-grid-badges" ${userSettings.showGridBadges ? 'checked' : ''}>
                <span class="ens-slider round"></span>
              </label>
            </div>

            <div class="ens-setting-row">
              <label>Badge In-Card Placement:</label>
              <select class="ens-select" id="select-badge-pos">
                <option value="bottom" ${userSettings.badgePosition === 'bottom' ? 'selected' : ''}>Bottom (Below Card Body)</option>
                <option value="top" ${userSettings.badgePosition === 'top' ? 'selected' : ''}>Top (Above Image)</option>
              </select>
            </div>

            <div class="ens-setting-row">
              <label>Min In-Cart Highlight Threshold: <strong id="val-min-cart">${userSettings.minCartThreshold} carts</strong></label>
              <input type="range" class="ens-range-slider" id="slider-min-cart" min="0" max="10" step="1" value="${userSettings.minCartThreshold}">
            </div>
          </div>

          <!-- Currency Override -->
          <div class="ens-settings-section">
            <div class="ens-settings-title">Currency Configuration</div>
            <div class="ens-setting-row">
              <label>Currency Override:</label>
              <select class="ens-select" id="select-currency">
                <option value="auto" ${userSettings.currencyOverride === 'auto' ? 'selected' : ''}>Auto-Detect from Page</option>
                <option value="$" ${userSettings.currencyOverride === '$' ? 'selected' : ''}>USD ($)</option>
                <option value="£" ${userSettings.currencyOverride === '£' ? 'selected' : ''}>GBP (£)</option>
                <option value="€" ${userSettings.currencyOverride === '€' ? 'selected' : ''}>EUR (€)</option>
                <option value="CA$" ${userSettings.currencyOverride === 'CA$' ? 'selected' : ''}>CAD (CA$)</option>
                <option value="AU$" ${userSettings.currencyOverride === 'AU$' ? 'selected' : ''}>AUD (AU$)</option>
              </select>
            </div>
          </div>
        </div>

        <div class="ens-drawer-footer">
          <button class="ens-btn-secondary" id="ens-reset-settings-btn">Reset Defaults</button>
          <button class="ens-btn-primary" id="ens-save-settings-btn">${renderSvg('check', 13)} Save & Apply</button>
        </div>
      </div>
    `;

    // Sliders Live Feedback
    const sliderTx = document.getElementById('slider-tx-fee');
    const valTx = document.getElementById('val-tx-fee');
    sliderTx?.addEventListener('input', () => {
      valTx.innerText = `${sliderTx.value}%`;
      updateSimBox();
    });

    const sliderProc = document.getElementById('slider-proc-fee');
    const valProc = document.getElementById('val-proc-fee');
    sliderProc?.addEventListener('input', () => {
      valProc.innerText = `${sliderProc.value}% + $${userSettings.paymentProcessingFixed.toFixed(2)}`;
      updateSimBox();
    });

    const selectOffsite = document.getElementById('select-offsite-ads');
    selectOffsite?.addEventListener('change', updateSimBox);

    function updateSimBox() {
      const tempSettings = {
        txFeePct: parseFloat(sliderTx?.value || 6.5),
        listingFee: 0.20,
        paymentProcessingFeePct: parseFloat(sliderProc?.value || 3.0),
        paymentProcessingFixed: 0.25,
        offsiteAdsPct: parseFloat(selectOffsite?.value || 0.0)
      };
      const sim = calculateEconomics(15.00, tempSettings);
      const simBox = drawer.querySelector('.ens-sim-box');
      if (simBox) {
        simBox.innerHTML = `
          <div class="ens-sim-header">Live Simulation for ${cur}15.00 Item</div>
          <div class="ens-sim-val">Net Take-Home: <strong class="text-green">${cur}${sim.netTakeHome.toFixed(2)}</strong> (${sim.marginPct}% Margin)</div>
          <div class="ens-sim-sub">Total Etsy cut: ${cur}${sim.totalFees.toFixed(2)}</div>
        `;
      }
    }

    const sliderCart = document.getElementById('slider-min-cart');
    const valCart = document.getElementById('val-min-cart');
    sliderCart?.addEventListener('input', () => {
      valCart.innerText = `${sliderCart.value} carts`;
    });

    document.getElementById('ens-close-drawer-btn')?.addEventListener('click', () => toggleSettingsDrawer(false));
    drawer.addEventListener('click', (e) => {
      if (e.target === drawer) toggleSettingsDrawer(false);
    });

    document.getElementById('ens-reset-settings-btn')?.addEventListener('click', () => {
      saveSettings(DEFAULT_SETTINGS, () => {
        renderSettingsDrawer();
        runAudit();
      });
    });

    document.getElementById('ens-save-settings-btn')?.addEventListener('click', () => {
      const updated = {
        badgeStyle: document.getElementById('select-badge-style')?.value || 'compact',
        showGridBadges: document.getElementById('switch-grid-badges')?.checked ?? true,
        badgePosition: document.getElementById('select-badge-pos')?.value || 'bottom',
        txFeePct: parseFloat(sliderTx?.value || 6.5),
        paymentProcessingFeePct: parseFloat(sliderProc?.value || 3.0),
        offsiteAdsPct: parseFloat(selectOffsite?.value || 0.0),
        minCartThreshold: parseInt(sliderCart?.value || 0, 10),
        currencyOverride: document.getElementById('select-currency')?.value || 'auto'
      };

      saveSettings(updated, () => {
        toggleSettingsDrawer(false);
        runAudit();
      });
    });
  }

  function toggleSettingsDrawer(open) {
    let drawer = document.getElementById('ens-settings-drawer');
    if (!drawer) {
      renderSettingsDrawer();
      drawer = document.getElementById('ens-settings-drawer');
    }
    if (open) {
      renderSettingsDrawer();
      drawer.classList.add('open');
    } else {
      drawer.classList.remove('open');
    }
  }

  // ==========================================
  // DATA HORIZON COMPARISON MATRIX MODAL
  // ==========================================

  let matrixFilterMode = 'all'; // 'all' | 'digital' | 'cart' | 'newshop' | 'bestseller'
  let matrixSearchQuery = '';
  let matrixSortKey = 'estMonthlyRevenue'; // Default: sort winners by highest revenue
  let matrixSortAsc = false;
  let matrixViewMode = 'table'; // 'table' (EverBee) | 'list' (Alura) | 'grid' (Gallery)

  function renderMatrixModal() {
    let modal = document.getElementById('ens-matrix-modal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'ens-matrix-modal';
      modal.className = 'ens-matrix-overlay';
      document.body.appendChild(modal);
    }

    if (!currentAnalysis || !currentAnalysis.listings) {
      modal.innerHTML = `
        <div class="ens-matrix-container">
          <div class="ens-matrix-header">
            <strong>Data Horizon Comparison Matrix</strong>
            <button class="ens-icon-btn" id="ens-close-matrix-btn">${renderSvg('close', 14)}</button>
          </div>
          <div style="padding: 40px; text-align: center; color: var(--ens-text-muted);">
            No search listings captured yet. Navigate to an Etsy search page to populate the comparison matrix.
          </div>
        </div>
      `;
      document.getElementById('ens-close-matrix-btn')?.addEventListener('click', () => toggleMatrixModal(false));
      return;
    }

    const cur = currentAnalysis.currency || detectPageCurrency();
    let rows = currentAnalysis.listings.slice();

    // 1. Text filter
    if (matrixSearchQuery.trim()) {
      const q = matrixSearchQuery.toLowerCase();
      rows = rows.filter(r => (r.title || '').toLowerCase().includes(q) || (r.shopName || '').toLowerCase().includes(q));
    }

    // 2. Chip filter
    if (matrixFilterMode === 'digital') {
      rows = rows.filter(r => r.isDigital);
    } else if (matrixFilterMode === 'sold24h') {
      rows = rows.filter(r => (r.sold24h || 0) > 0);
    } else if (matrixFilterMode === 'cart') {
      rows = rows.filter(r => (r.inCart || 0) >= 3);
    } else if (matrixFilterMode === 'newshop') {
      rows = rows.filter(r => (r.reviewCount || 0) < 50);
    } else if (matrixFilterMode === 'bestseller') {
      rows = rows.filter(r => r.isBestseller);
    }

    // 3. Sorting
    rows.sort((a, b) => {
      let valA = a[matrixSortKey];
      let valB = b[matrixSortKey];
      if (typeof valA === 'string') valA = valA.toLowerCase();
      if (typeof valB === 'string') valB = valB.toLowerCase();
      if (valA === undefined || valA === null) valA = 0;
      if (valB === undefined || valB === null) valB = 0;
      if (valA < valB) return matrixSortAsc ? -1 : 1;
      if (valA > valB) return matrixSortAsc ? 1 : -1;
      return 0;
    });

    const totalEstRevenue = rows.reduce((sum, r) => sum + (r.estMonthlyRevenue || 0), 0);
    const avgPrice = rows.length ? (rows.reduce((sum, r) => sum + (r.price || 0), 0) / rows.length) : 0;
    const avgMonthlySales = rows.length ? Math.round(rows.reduce((sum, r) => sum + (r.estMonthlySales || 0), 0) / rows.length) : 0;
    const digitalCount = rows.filter(r => r.isDigital).length;
    const digitalRatio = rows.length ? Math.round((digitalCount / rows.length) * 100) : 0;
    const hotDemandCount = rows.filter(r => (r.inCart || 0) >= 3).length;
    const sold24hCount = rows.filter(r => (r.sold24h || 0) > 0).length;

    let contentBodyHtml = '';

    if (matrixViewMode === 'list') {
      // Alura-style List View (Screenshot 1)
      contentBodyHtml = `
        <div class="ens-matrix-list-wrap" style="flex: 1; overflow-y: auto; padding: 12px 20px; display: flex; flex-direction: column; gap: 8px;">
          ${rows.map((item, idx) => {
            const econ = calculateEconomics(item.price, userSettings);
            return `
              <div class="ens-list-item" style="display: flex; align-items: center; justify-content: space-between; padding: 10px 14px; background: #ffffff; border: 1px solid var(--ens-border); border-radius: 10px; gap: 12px; transition: border-color 0.15s;">
                <div style="display: flex; align-items: center; gap: 10px; min-width: 0; flex: 1;">
                  <span class="text-muted font-mono" style="font-size: 11px; width: 22px;">#${idx + 1}</span>
                  ${item.imageUrl ? `<img src="${item.imageUrl}" style="width: 44px; height: 44px; border-radius: 8px; object-fit: cover; flex-shrink: 0;" alt="thumb" />` : ''}
                  <div style="min-width: 0; flex: 1;">
                    <a href="${item.url}" target="_blank" class="ens-table-title" style="font-size: 12px; font-weight: 600; color: #0f172a;" title="${item.title}">${item.title}</a>
                    <div style="font-size: 11px; color: #64748b; margin-top: 2px;">
                      ${item.isDigital ? '<span style="color: #6366f1; font-weight: 600;">⚡ Digital</span>' : '<span>📦 Physical</span>'} · 
                      ${(item.sold24h && item.sold24h > 0) ? `<span style="color: #dc2626; font-weight: 700;">🔥 ${item.sold24h} sold/24h</span> · ` : ''}
                      <span>📅 ${item.cardAge || 'Active'}</span> · 
                      <strong class="font-mono" style="color: #0f172a;">${cur}${item.price.toFixed(2)}</strong> · 
                      <span style="color: #f59e0b;">⭐ ${item.starRating || '5.0'} (${item.reviewCount || 0})</span>
                      ${item.shopName ? ` · <span style="font-weight: 600; color: #475569;">${item.shopName}</span>` : ''}
                    </div>
                  </div>
                </div>
                <div style="display: flex; align-items: center; gap: 16px; flex-shrink: 0;">
                  <div style="text-align: right;">
                    <span style="font-size: 10px; color: #64748b; display: block;">Sales</span>
                    <strong style="font-size: 12px; color: #ea580c;">~${(item.estMonthlySales || 0).toLocaleString()}<small style="font-weight: 400; font-size: 10px; color: #64748b;">/mo</small></strong>
                  </div>
                  <div style="text-align: right;">
                    <span style="font-size: 10px; color: #64748b; display: block;">Est. Revenue</span>
                    <strong class="text-green" style="font-size: 12px;">${cur}${(item.estMonthlyRevenue || 0).toLocaleString()}<small style="font-weight: 400; font-size: 10px; color: #64748b;">/mo</small></strong>
                  </div>
                  <div style="text-align: right;">
                    <span style="font-size: 10px; color: #64748b; display: block;">Net Cash</span>
                    <strong class="text-green" style="font-size: 12px;">${cur}${econ.netTakeHome.toFixed(2)}</strong>
                    <span style="font-size: 9px; color: #64748b; display: block;">(${econ.marginPct}%)</span>
                  </div>
                  <button class="ens-btn-mini ens-row-copy-tags" data-title="${encodeURIComponent(item.title)}" title="Format and copy 13 tags">🏷️ Tags</button>
                  <a href="${item.url}" target="_blank" class="ens-icon-btn" title="Open listing on Etsy">${renderSvg('expand', 12)}</a>
                </div>
              </div>
            `;
          }).join('')}
        </div>
      `;
    } else if (matrixViewMode === 'grid') {
      // Visual Grid Gallery View
      contentBodyHtml = `
        <div class="ens-matrix-grid-wrap" style="flex: 1; overflow-y: auto; padding: 14px 20px; display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 12px;">
          ${rows.map((item, idx) => {
            const econ = calculateEconomics(item.price, userSettings);
            return `
              <div class="ens-grid-card" style="background: #ffffff; border: 1px solid var(--ens-border); border-radius: 12px; padding: 10px; display: flex; flex-direction: column; gap: 8px;">
                <div style="position: relative; aspect-ratio: 4/3; border-radius: 8px; overflow: hidden; background: #f1f5f9;">
                  ${item.imageUrl ? `<img src="${item.imageUrl}" style="width: 100%; height: 100%; object-fit: cover;" alt="thumb" />` : ''}
                  <span style="position: absolute; top: 6px; left: 6px; background: rgba(0,0,0,0.7); color: white; padding: 2px 6px; border-radius: 4px; font-size: 10px; font-weight: 700;">#${idx + 1}</span>
                  ${item.inCart >= 3 ? `<span style="position: absolute; top: 6px; right: 6px; background: #ea580c; color: white; padding: 2px 6px; border-radius: 4px; font-size: 10px; font-weight: 700;">🔥 ${item.inCart} in cart</span>` : ''}
                  ${(item.sold24h && item.sold24h > 0) ? `<span style="position: absolute; bottom: 6px; left: 6px; background: rgba(220,38,38,0.9); color: white; padding: 2px 6px; border-radius: 4px; font-size: 10px; font-weight: 700;">🔥 ${item.sold24h} sold 24h</span>` : ''}
                </div>
                <a href="${item.url}" target="_blank" class="ens-table-title" style="font-size: 12px; font-weight: 600; color: #0f172a; line-height: 1.3;" title="${item.title}">${item.title}</a>
                <div style="display: flex; justify-content: space-between; font-size: 11px;">
                  <span>Price: <strong class="font-mono">${cur}${item.price.toFixed(2)}</strong></span>
                  <span class="text-green font-bold">Net: ${cur}${econ.netTakeHome.toFixed(2)} (${econ.marginPct}%)</span>
                </div>
                <div style="display: flex; justify-content: space-between; font-size: 11px; padding: 6px 8px; background: #f8fafc; border-radius: 6px;">
                  <span>⚡ ~${(item.estMonthlySales || 0).toLocaleString()}/mo</span>
                  <strong class="text-green">${cur}${(item.estMonthlyRevenue || 0).toLocaleString()}/mo</strong>
                </div>
                <div style="display: flex; gap: 6px; margin-top: auto;">
                  <button class="ens-btn-mini ens-row-copy-tags" style="flex: 1;" data-title="${encodeURIComponent(item.title)}">🏷️ Copy 13 Tags</button>
                  <a href="${item.url}" target="_blank" class="ens-icon-btn" title="Open listing on Etsy">${renderSvg('expand', 12)}</a>
                </div>
              </div>
            `;
          }).join('')}
        </div>
      `;
    } else {
      // Table View (EverBee style)
      contentBodyHtml = `
        <div class="ens-matrix-table-wrap">
          <table class="ens-table">
            <thead>
              <tr>
                <th style="width: 36px;">#</th>
                <th style="min-width: 220px;">Product & Shop</th>
                <th class="text-center">Format</th>
                <th class="text-right sortable" data-sort="price">Retail / Net ${matrixSortKey === 'price' ? (matrixSortAsc ? '▲' : '▼') : ''}</th>
                <th class="text-center sortable" data-sort="estMonthlySales">Est. Sales ${matrixSortKey === 'estMonthlySales' ? (matrixSortAsc ? '▲' : '▼') : ''}</th>
                <th class="text-right sortable" data-sort="estMonthlyRevenue">Est. Revenue ${matrixSortKey === 'estMonthlyRevenue' ? (matrixSortAsc ? '▲' : '▼') : ''}</th>
                <th class="text-center sortable" data-sort="sold24h">24h Sold ${matrixSortKey === 'sold24h' ? (matrixSortAsc ? '▲' : '▼') : ''}</th>
                <th class="text-center sortable" data-sort="inCart">In Cart ${matrixSortKey === 'inCart' ? (matrixSortAsc ? '▲' : '▼') : ''}</th>
                <th class="text-center sortable" data-sort="reviewCount">Reviews ${matrixSortKey === 'reviewCount' ? (matrixSortAsc ? '▲' : '▼') : ''}</th>
                <th class="text-center sortable" data-sort="cardAge">Age ${matrixSortKey === 'cardAge' ? (matrixSortAsc ? '▲' : '▼') : ''}</th>
                <th style="width: 90px; text-align: center;">Actions</th>
              </tr>
            </thead>
            <tbody>
              ${rows.map((item, idx) => {
                const econ = calculateEconomics(item.price, userSettings);
                return `
                  <tr>
                    <td class="text-muted font-mono" style="font-size: 10px;">${idx + 1}</td>
                    <td class="ens-cell-product">
                      <div style="display: flex; align-items: center; gap: 8px;">
                        ${item.imageUrl ? `<img src="${item.imageUrl}" style="width: 28px; height: 28px; border-radius: 4px; object-fit: cover; flex-shrink: 0;" alt="thumb" />` : ''}
                        <div style="min-width: 0; flex: 1;">
                          <a href="${item.url}" target="_blank" class="ens-table-title" title="${item.title}">${item.title}</a>
                          <div style="font-size: 10px; color: #64748b;">
                            ${item.shopName ? `<span style="font-weight: 600; color: #334155;">${item.shopName}</span> · ` : ''}
                            <span>${item.listingId ? 'ID ' + item.listingId : ''}</span>
                          </div>
                        </div>
                      </div>
                    </td>
                    <td class="text-center">
                      <span class="ens-pill-mini ${item.isDigital ? 'digital' : 'physical'}">
                        ${item.isDigital ? '⚡ Digital' : '📦 Physical'}
                      </span>
                    </td>
                    <td class="text-right font-mono">
                      <div>${cur}${item.price.toFixed(2)}</div>
                      <div class="text-green" style="font-size: 10px; font-weight: 700;">${cur}${econ.netTakeHome.toFixed(2)} (${econ.marginPct}%)</div>
                    </td>
                    <td class="text-center font-mono">
                      <strong style="color: #ea580c;">~${(item.estMonthlySales || 0).toLocaleString()}</strong><span style="font-size: 9px; color: #64748b;">/mo</span>
                    </td>
                    <td class="text-right font-mono">
                      <strong class="text-green">${cur}${(item.estMonthlyRevenue || 0).toLocaleString()}</strong><span style="font-size: 9px; color: #64748b;">/mo</span>
                    </td>
                    <td class="text-center font-mono">
                      ${(item.sold24h && item.sold24h > 0) ? `
                        <span class="ens-chip-inline hot" style="background: rgba(239, 68, 68, 0.12); color: #dc2626; border: 1px solid rgba(239, 68, 68, 0.25); font-weight: 700;">
                          🔥 ${item.sold24h}
                        </span>
                      ` : '<span class="text-muted">-</span>'}
                    </td>
                    <td class="text-center">
                      ${item.inCart > 0 ? `
                        <span class="ens-chip-inline ${item.inCart >= 5 ? 'hot' : 'warm'}">
                          ${renderSvg('flame', 11)} ${item.inCart}
                        </span>
                      ` : '<span class="text-muted">0</span>'}
                    </td>
                    <td class="text-center font-mono">
                      <div>${item.reviewCount < 50 ? `<span class="text-green font-bold">${item.reviewCount}</span>` : item.reviewCount}</div>
                      ${item.starRating ? `<div style="font-size: 9px; color: #f59e0b;">⭐ ${item.starRating}</div>` : ''}
                    </td>
                    <td class="text-center">
                      <span style="font-size: 10px; padding: 2px 6px; border-radius: 4px; background: #f1f5f9; color: #475569;">${item.cardAge || 'Active'}</span>
                    </td>
                    <td style="text-align: center;">
                      <div style="display: flex; gap: 4px; justify-content: center; align-items: center;">
                        <button class="ens-btn-mini ens-row-copy-tags" data-title="${encodeURIComponent(item.title)}" title="Format and copy 13 compliant tags">🏷️ Tags</button>
                        <a href="${item.url}" target="_blank" class="ens-icon-btn" title="Open listing on Etsy">${renderSvg('expand', 12)}</a>
                      </div>
                    </td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>
        </div>
      `;
    }

    modal.innerHTML = `
      <div class="ens-matrix-container">
        <div class="ens-matrix-header">
          <div class="ens-matrix-title-group">
            ${renderSvg('table', 18)}
            <div>
              <strong>Product Analytics & Competitor Matrix</strong>
              <div class="ens-matrix-sub">Search: "${currentAnalysis.query}" · Showing ${rows.length} of ${currentAnalysis.listings.length} listings audited</div>
            </div>
          </div>
          <div class="ens-matrix-actions">
            <!-- 3-View Mode Switcher (Alura Parity) -->
            <div class="ens-view-switcher" style="display: flex; background: #e2e8f0; border-radius: 8px; padding: 2px; gap: 2px; margin-right: 8px;">
              <button class="ens-view-btn ${matrixViewMode === 'table' ? 'active' : ''}" data-view="table" title="Table View (EverBee)">▦ Table</button>
              <button class="ens-view-btn ${matrixViewMode === 'list' ? 'active' : ''}" data-view="list" title="List View (Alura)">☰ List</button>
              <button class="ens-view-btn ${matrixViewMode === 'grid' ? 'active' : ''}" data-view="grid" title="Visual Grid Gallery">☷ Grid</button>
            </div>
            <button class="ens-btn-primary" id="ens-matrix-export-btn">
              ${renderSvg('download', 13)} Export CSV
            </button>
            <button class="ens-icon-btn" id="ens-close-matrix-btn" title="Close Matrix (Esc)">
              ${renderSvg('close', 14)}
            </button>
          </div>
        </div>

        <!-- Top Horizon KPI Strip -->
        <div class="ens-matrix-kpi-bar" style="display: flex; gap: 12px; padding: 10px 20px; background: #f8fafc; border-bottom: 1px solid var(--ens-border); font-size: 11px;">
          <div style="flex: 1;">
            <span style="color: #64748b; font-size: 10px; display: block;">Audited Listings</span>
            <strong>${rows.length} <small style="color: #94a3b8;">/ ${currentAnalysis.listings.length}</small></strong>
          </div>
          <div style="flex: 1.2;">
            <span style="color: #64748b; font-size: 10px; display: block;">Est. Page Run-Rate</span>
            <strong class="text-green">${cur}${totalEstRevenue.toLocaleString()}<small style="font-weight: 400; color: #64748b;">/mo</small></strong>
          </div>
          <div style="flex: 1;">
            <span style="color: #64748b; font-size: 10px; display: block;">Avg Item Price</span>
            <strong>${cur}${avgPrice.toFixed(2)}</strong>
          </div>
          <div style="flex: 1.2;">
            <span style="color: #64748b; font-size: 10px; display: block;">Avg Monthly Sales</span>
            <strong style="color: #ea580c;">~${avgMonthlySales} <small style="font-weight: 400; color: #64748b;">units/mo</small></strong>
          </div>
          <div style="flex: 1;">
            <span style="color: #64748b; font-size: 10px; display: block;">24h Velocity</span>
            <strong style="color: #dc2626;">${sold24hCount} items</strong>
          </div>
          <div style="flex: 1;">
            <span style="color: #64748b; font-size: 10px; display: block;">Digital Share</span>
            <strong>${digitalRatio}%</strong>
          </div>
          <div style="flex: 1;">
            <span style="color: #64748b; font-size: 10px; display: block;">High Demand (3+ Cart)</span>
            <strong style="color: #f59e0b;">${hotDemandCount} items</strong>
          </div>
        </div>

        <!-- Filter Bar -->
        <div class="ens-matrix-toolbar">
          <div class="ens-search-input-wrap">
            <input type="text" id="ens-matrix-search" class="ens-input" placeholder="Filter by title or shop..." value="${matrixSearchQuery}">
          </div>
          <div class="ens-chip-group">
            <button class="ens-chip ${matrixFilterMode === 'all' ? 'active' : ''}" data-filter="all">All (${currentAnalysis.listings.length})</button>
            <button class="ens-chip ${matrixFilterMode === 'sold24h' ? 'active' : ''}" data-filter="sold24h">🔥 24h Sold (${currentAnalysis.listings.filter(l => (l.sold24h || 0) > 0).length})</button>
            <button class="ens-chip ${matrixFilterMode === 'digital' ? 'active' : ''}" data-filter="digital">⚡ Digital Only</button>
            <button class="ens-chip ${matrixFilterMode === 'cart' ? 'active' : ''}" data-filter="cart">🔥 3+ In Cart</button>
            <button class="ens-chip ${matrixFilterMode === 'newshop' ? 'active' : ''}" data-filter="newshop">🚀 Breakout (&lt;50 Rev)</button>
            <button class="ens-chip ${matrixFilterMode === 'bestseller' ? 'active' : ''}" data-filter="bestseller">⭐ Bestsellers</button>
          </div>
        </div>

        ${contentBodyHtml}
      </div>
    `;

    // Event Listeners for Matrix
    document.getElementById('ens-close-matrix-btn')?.addEventListener('click', () => toggleMatrixModal(false));
    modal.addEventListener('click', (e) => {
      if (e.target === modal) toggleMatrixModal(false);
    });

    const searchInput = document.getElementById('ens-matrix-search');
    searchInput?.addEventListener('input', (e) => {
      matrixSearchQuery = e.target.value;
      renderMatrixModal();
      const el = document.getElementById('ens-matrix-search');
      if (el) {
        el.focus();
        el.setSelectionRange(el.value.length, el.value.length);
      }
    });

    modal.querySelectorAll('.ens-chip').forEach(btn => {
      btn.addEventListener('click', () => {
        matrixFilterMode = btn.getAttribute('data-filter');
        renderMatrixModal();
      });
    });

    modal.querySelectorAll('.ens-view-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        matrixViewMode = btn.getAttribute('data-view') || 'table';
        renderMatrixModal();
      });
    });

    modal.querySelectorAll('th.sortable').forEach(th => {
      th.addEventListener('click', () => {
        const sortKey = th.getAttribute('data-sort');
        if (matrixSortKey === sortKey) {
          matrixSortAsc = !matrixSortAsc;
        } else {
          matrixSortKey = sortKey;
          matrixSortAsc = false;
        }
        renderMatrixModal();
      });
    });

    modal.querySelectorAll('.ens-row-copy-tags').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        const rawTitle = decodeURIComponent(btn.getAttribute('data-title') || '');
        const formatted = formatEtsy13Tags(rawTitle.split(/\s+/));
        navigator.clipboard.writeText(formatted.clipboardString || rawTitle.slice(0, 30)).then(() => {
          const orig = btn.innerText;
          btn.innerText = '✓ Copied!';
          btn.style.background = '#10b981';
          btn.style.color = '#ffffff';
          setTimeout(() => {
            btn.innerText = orig;
            btn.style.background = '';
            btn.style.color = '';
          }, 1200);
        });
      });
    });

    document.getElementById('ens-matrix-export-btn')?.addEventListener('click', () => exportCsv(currentAnalysis));
  }

  function toggleMatrixModal(open) {
    let modal = document.getElementById('ens-matrix-modal');
    if (!modal) {
      renderMatrixModal();
      modal = document.getElementById('ens-matrix-modal');
    }
    if (open) {
      renderMatrixModal();
      modal.classList.add('open');
      modal.classList.add('active');
    } else {
      modal.classList.remove('open');
      modal.classList.remove('active');
    }
  }

  // ==========================================
  // FLOATING ANALYZE TRIGGER PILL (1-CLICK DISCOVERY)
  // ==========================================

  function renderFloatingAnalyzeTrigger(count) {
    if (pageMode !== 'search') {
      const existing = document.getElementById('ens-floating-analyze-pill');
      if (existing) existing.remove();
      return;
    }

    let pill = document.getElementById('ens-floating-analyze-pill');
    if (!pill) {
      pill = document.createElement('button');
      pill.id = 'ens-floating-analyze-pill';
      pill.className = 'ens-floating-analyze-pill';
      document.body.appendChild(pill);
      pill.addEventListener('click', () => toggleMatrixModal(true));
    }

    const n = count || (currentAnalysis && currentAnalysis.listings ? currentAnalysis.listings.length : 48);
    pill.innerHTML = `
      ${renderSvg('table', 14)}
      <span>Analyze Niche (${n})</span>
    `;
    pill.style.display = 'inline-flex';
  }

  // ==========================================
  // FLOATING HUD RENDERING (5-STATE RESILIENT)
  // ==========================================

  function renderFloatingHud(data) {
    let hud = document.getElementById('etsy-niche-scout-hud');
    if (!hud) {
      hud = document.createElement('div');
      hud.id = 'etsy-niche-scout-hud';
      document.body.appendChild(hud);
    }

    if (!isHudVisible) {
      hud.style.display = 'none';
      return;
    }
    hud.style.display = 'block';

    if (isHudMinimized && data) {
      hud.classList.add('minimized');
      const cur = data.currency || detectPageCurrency();
      hud.innerHTML = `
        <div class="ens-dock-pill" id="ens-restore-pill" title="Click to expand full analytics">
          <span class="ens-dot" style="background: ${data.statusClass === 'status-green' ? '#34d399' : '#fbbf24'}"></span>
          <strong>${data.score || 85}/100</strong>
          <span style="color:#71717a;">·</span>
          <span>${data.totalListings ? data.totalListings.toLocaleString() + ' items' : (data.shopName || 'Forensics')}</span>
          ${data.avgPrice ? `<span style="color:#71717a;">·</span><span style="color:var(--ens-accent-lime);">${cur}${data.avgPrice} avg</span>` : ''}
          <button id="ens-restore-btn" class="ens-dock-expand" title="Expand HUD">${renderSvg('expand', 12)}</button>
        </div>
      `;
      document.getElementById('ens-restore-pill')?.addEventListener('click', () => {
        isHudMinimized = false;
        renderFloatingHud(currentAnalysis);
      });
      makeDraggable(hud, hud);
      return;
    }

    hud.classList.remove('minimized');

    if (!data) {
      // Empty State
      hud.innerHTML = `
        <div class="ens-header">
          <div class="ens-title">
            <span class="ens-dot" style="background: #a1a1aa"></span>
            <strong>Etsy Niche Scout Pro</strong>
            <span class="ens-shortcut">Alt+S</span>
          </div>
          <div class="ens-controls">
            <button class="ens-icon-btn" id="ens-settings-btn" title="Settings">${renderSvg('sliders', 13)}</button>
            <button class="ens-icon-btn" id="ens-close-btn" title="Close">${renderSvg('close', 13)}</button>
          </div>
        </div>
        <div class="ens-body">
          <div class="ens-empty-state">
            <div class="ens-empty-icon">${renderSvg('radar', 28)}</div>
            <div class="ens-empty-text">No active search or shop detected.</div>
            <div class="ens-card-sub">Navigate to any Etsy search or shop page to activate live forensics.</div>
          </div>
        </div>
      `;
      document.getElementById('ens-settings-btn')?.addEventListener('click', () => toggleSettingsDrawer(true));
      document.getElementById('ens-close-btn')?.addEventListener('click', () => { isHudVisible = false; renderFloatingHud(null); });
      makeDraggable(hud, hud.querySelector('.ens-header'));
      return;
    }

    if (data.type === 'listing') {
      // Listing Forensics Pro
      const seoPct = Math.min(100, Math.round((data.titleLength / 140) * 100));
      const seoColor = data.titleLength <= 140 ? 'var(--ens-accent-lime)' : 'var(--ens-status-rose)';
      const allTagsComma = data.tags.map(t => t.name).join(', ');

      hud.innerHTML = `
        <div class="ens-header">
          <div class="ens-title">
            <span class="ens-dot" style="background: ${data.statusClass === 'status-green' ? '#34d399' : '#fbbf24'}"></span>
            <strong>Listing Forensics Pro</strong>
            <span class="ens-shortcut">Alt+S</span>
          </div>
          <div class="ens-controls">
            <button class="ens-icon-btn" id="ens-settings-btn" title="Settings">${renderSvg('sliders', 13)}</button>
            <button class="ens-icon-btn" id="ens-min-btn" title="Minimize">${renderSvg('minus', 13)}</button>
            <button class="ens-icon-btn" id="ens-close-btn" title="Close">${renderSvg('close', 13)}</button>
          </div>
        </div>
        <div class="ens-body" id="ens-body-content">
          <!-- 5-Pillar Executive Summary Ribbon (Zero Cognitive Load) -->
          <div class="ens-5pillar-summary-box">
            <div class="ens-5pillar-summary-header">
              <span>5-PILLAR EXECUTIVE AUDIT</span>
              <span class="ens-5pillar-sales-pill">💰 ~${(data.estMonthlySales || Math.max(15, (data.inCart || 0) * 12 + Math.round((data.listingReviews || 0) * 1.5))).toLocaleString()}/mo · ${data.currency || '$'}${data.netTakeHome} Net</span>
            </div>
            <div class="ens-5pillar-summary-grid">
              <div class="ens-5pillar-cell">
                <span class="pillar-label">🔑 Focus Keyword</span>
                <span class="pillar-val" title="${data.tags[0]?.name || data.titleMobilePreview}">${data.tags[0]?.name || data.titleMobilePreview.slice(0, 16)}</span>
              </div>
              <div class="ens-5pillar-cell">
                <span class="pillar-label">📅 Listing Age</span>
                <span class="pillar-val">${data.ageLabel || 'Active (2026)'}</span>
              </div>
              <div class="ens-5pillar-cell">
                <span class="pillar-label">⭐ Total Reviews</span>
                <span class="pillar-val">${data.listingReviews} (${data.isStarSeller ? 'Star Seller' : 'Verified'})</span>
              </div>
              <div class="ens-5pillar-cell">
                <span class="pillar-label">🏆 Top Listing</span>
                <span class="pillar-val ${data.isBestseller ? 'highlight-gold' : 'highlight-green'}">
                  ${data.isBestseller ? '🏆 Niche Bestseller' : (data.sold24h >= 3 ? '🔥 ' + data.sold24h + ' Sold/24h' : (data.inCart >= 5 ? '🔥 Viral In-Cart' : '⚡ Active Listing'))}
                </span>
              </div>
            </div>
          </div>

          <!-- Live 24h Sales Urgency Banner -->
          ${data.sold24h > 0 ? `
            <div class="ens-sold24h-banner" style="background: rgba(239, 68, 68, 0.12); border: 1px solid rgba(239, 68, 68, 0.35); border-radius: 8px; padding: 7px 12px; margin-bottom: 8px; display: flex; align-items: center; justify-content: space-between;">
              <div style="display: flex; align-items: center; gap: 6px; font-weight: 700; color: #ef4444; font-size: 11px;">
                ${renderSvg('flame', 13)} 🔥 ${data.sold24h} sold in the last 24 hours
              </div>
              <span style="font-size: 10px; color: #94a3b8; font-weight: 600;">Est. ~${data.sold24h * 28}+ sales/mo floor</span>
            </div>
          ` : ''}

          <!-- Listing Title & Mobile SEO Meter -->
          <div class="ens-seo-box">
            <div class="ens-seo-header">
              <span>Title SEO Density</span>
              <span style="color: ${seoColor};">${data.titleLength} / 140 chars</span>
            </div>
            <div class="ens-seo-bar-track">
              <div class="ens-seo-bar-fill" style="width: ${seoPct}%; background: ${seoColor};"></div>
            </div>
            <div class="ens-seo-preview">
              📱 Mobile Fold (First 40c): <strong>${data.titleMobilePreview}...</strong>
            </div>
          </div>

          <!-- Digital Badge & Formats -->
          ${data.isDigital ? `
            <div style="display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 8px;">
              <span class="ens-badge-pill">⚡ Instant Digital Download</span>
              ${data.formatsDetected.map(fmt => `<span class="ens-badge-pill" style="background: rgba(37,99,235,0.15); color: #93c5fd; border-color: rgba(37,99,235,0.3);">${fmt}</span>`).join('')}
            </div>
          ` : ''}

          <div class="ens-verdict ${data.statusClass}">${data.status}</div>

          <!-- Forensic Metrics Grid -->
          <div class="ens-grid">
            <div class="ens-card">
              <div class="ens-card-label">24h Sales & Urgency</div>
              <div class="ens-card-val ${data.sold24h > 0 ? 'text-green' : (data.inCart >= 5 ? 'text-green' : (data.inCart > 0 ? 'text-yellow' : ''))}">
                ${renderSvg('flame', 12)} ${data.sold24h > 0 ? data.sold24h + ' sold/24h' : (data.inCart > 0 ? data.inCart + ' in carts' : '0 sold')}
              </div>
              <div class="ens-card-sub">${data.sold24h > 0 ? 'Verified 24h Buyer Proof' : (data.inCart >= 10 ? 'High Intent Cart Signal' : 'Standard Demand')}</div>
            </div>

            <div class="ens-card">
              <div class="ens-card-label">Est. Monthly Sales</div>
              <div class="ens-card-val text-green">~${(data.estMonthlySales || 0).toLocaleString()} <span style="font-size: 10px; font-weight: normal; color: #64748b;">/mo</span></div>
              <div class="ens-card-sub">~${data.currency || '$'}${(data.estMonthlyRevenue || 0).toLocaleString()} est. GMV</div>
            </div>

            <div class="ens-card">
              <div class="ens-card-label">Velocity Score</div>
              <div class="ens-card-val text-accent">
                ${renderSvg('rocket', 12)} ${data.velocityScore}/100
              </div>
              <div class="ens-card-sub">${data.isBestseller ? 'Bestseller Badge' : (data.views24h > 0 ? data.views24h + ' views in 24h' : 'Organic Traffic')}</div>
            </div>

            <div class="ens-card">
              <div class="ens-card-label">Listing Age</div>
              <div class="ens-card-val ${data.daysActive > 0 && data.daysActive <= 90 ? 'text-green' : ''}">
                ${data.ageLabel || (data.daysActive > 0 ? data.daysActive + ' days' : 'Active')}
              </div>
              <div class="ens-card-sub">${data.dateStr}</div>
            </div>

            <div class="ens-card">
              <div class="ens-card-label">Retail Price</div>
              <div class="ens-card-val">${data.currency || '$'}${data.price}</div>
              <div class="ens-card-sub">${data.discountPercent > 0 ? data.discountPercent + '% OFF (was ' + (data.currency || '$') + data.originalPrice + ')' : 'Full Retail Price'}</div>
            </div>

            <div class="ens-card">
              <div class="ens-card-label">Net Take-Home</div>
              <div class="ens-card-val text-green">${renderSvg('shield', 12)} ${data.currency || '$'}${data.netTakeHome}</div>
              <div class="ens-card-sub">~${data.profitMargin}% Net (${data.currency || '$'}${data.totalEtsyFees} fees)</div>
            </div>
          </div>

          <!-- All 13 Backend Tags -->
          <div class="ens-tags-section">
            <div class="ens-tags-header">
              <span>All 13 Backend Tags (${data.tags.length}/13)</span>
              <span style="font-size: 10px; cursor: pointer; color: var(--ens-accent-lime);" id="ens-copy-all-tags">
                ${renderSvg('copy', 11)} Copy 13 Tags
              </span>
            </div>
            <div class="ens-tags-container">
              ${data.tags.map(t => `
                <span class="ens-tag-item ${t.isTooLong ? 'overflow' : ''} ${t.isRedundant ? 'redundant' : ''}" data-tag="${t.name}">
                  <span>${t.name}</span>
                  <span class="ens-tag-len">${t.length}c</span>
                  ${t.isRedundant ? '<span class="ens-tag-redundant" title="Redundant: Words already in title">⚠️ Dup</span>' : ''}
                </span>
              `).join('')}
            </div>
            ${data.tags.some(t => t.isTooLong || t.isRedundant) ? `
              <div class="ens-card-sub" style="color: var(--ens-status-rose); margin-top: 6px;">
                ${data.tags.some(t => t.isTooLong) ? '⚠️ Highlighted tags exceed Etsy\'s 20-character limit. ' : ''}
                ${data.tags.some(t => t.isRedundant) ? '⚠️ Duplicate tags repeat words from title (wasted slot).' : ''}
              </div>
            ` : ''}
          </div>

          <!-- Competitor Review Friction Miner -->
          ${data.minedFriction.length > 0 ? `
            <div class="ens-friction-box">
              <div class="ens-friction-title">⚠️ Competitor Vulnerability Gaps (Mined from Reviews)</div>
              <div class="ens-friction-pills">
                ${data.minedFriction.map(f => `<span class="ens-friction-pill">${f}</span>`).join('')}
              </div>
              <div class="ens-card-sub" style="margin-top: 4px;">Solve these friction points in your own product to capture competitor buyers.</div>
            </div>
          ` : ''}

          <!-- Agent-Reach AI Intelligence Bridge -->
          <button id="ens-agent-reach-btn" class="ens-btn-prompt" title="Generate Reddit and Exa investigation prompt">
            ${renderSvg('sparkles', 13)} Copy Agent-Reach Prompt (Reddit & Exa)
          </button>

          <!-- Shared Actions -->
          <div class="ens-actions">
            <button id="ens-copy-listing-btn" class="ens-btn-primary">
              ${renderSvg('copy', 13)} Copy Listing JSON
            </button>
            <button id="ens-rescan-btn" class="ens-btn-secondary">
              ${renderSvg('refresh', 13)} Re-scan
            </button>
          </div>
        </div>
      `;

      // Event listeners for listing mode
      document.getElementById('ens-copy-all-tags')?.addEventListener('click', () => {
        const rawTags = (data.tags || []).map(t => t.name);
        const formatted = formatEtsy13Tags(rawTags);
        const copyBtn = document.getElementById('ens-copy-all-tags');
        copyTextToClipboard(formatted.clipboardString || allTagsComma);
        if (copyBtn) {
          const orig = copyBtn.innerText;
          copyBtn.innerText = `✓ Copied ${formatted.tags.length} Tags!`;
          setTimeout(() => { copyBtn.innerText = orig; }, 1400);
        }
      });

      document.querySelectorAll('.ens-tag-item').forEach(pill => {
        pill.addEventListener('click', () => {
          copyTextToClipboard(pill.getAttribute('data-tag'));
        });
      });

      document.getElementById('ens-agent-reach-btn')?.addEventListener('click', () => {
        copyAgentReachPrompt(data);
      });

      document.getElementById('ens-copy-listing-btn')?.addEventListener('click', () => {
        copyTextToClipboard(JSON.stringify(data, null, 2));
      });
    } else if (data.type === 'shop') {
      // Storefront Forensics
      hud.innerHTML = `
        <div class="ens-header">
          <div class="ens-title">
            <span class="ens-dot" style="background: ${data.isBreakout ? '#34d399' : '#fbbf24'}"></span>
            <strong>Storefront Forensics Pro</strong>
            <span class="ens-shortcut">Alt+S</span>
          </div>
          <div class="ens-controls">
            <button class="ens-icon-btn" id="ens-settings-btn" title="Settings">${renderSvg('sliders', 13)}</button>
            <button class="ens-icon-btn" id="ens-min-btn" title="Minimize">${renderSvg('minus', 13)}</button>
            <button class="ens-icon-btn" id="ens-close-btn" title="Close">${renderSvg('close', 13)}</button>
          </div>
        </div>
        <div class="ens-body" id="ens-body-content">
          <div class="ens-query-row">
            <div class="ens-query">🏪 Shop: <span>${data.shopName}</span></div>
          </div>
          <div class="ens-verdict ${data.statusClass}">${data.verdict}</div>
          <div class="ens-grid">
            <div class="ens-card">
              <div class="ens-card-label">Lifetime Sales</div>
              <div class="ens-card-val ${data.sales >= 100 ? 'text-green' : 'text-red'}">${data.sales.toLocaleString()} sales</div>
              <div class="ens-card-sub">${data.salesVerified ? '100% Live DOM Proof' : 'Estimated'}</div>
            </div>
            <div class="ens-card">
              <div class="ens-card-label">Reviews & Rating</div>
              <div class="ens-card-val text-accent">${data.reviewCount} reviews</div>
              <div class="ens-card-sub">Buyer sentiment</div>
            </div>
            <div class="ens-card">
              <div class="ens-card-label">Store Age</div>
              <div class="ens-card-val">${data.shopAgeDesc}</div>
              <div class="ens-card-sub">${data.isYoung ? 'Launched <6 Months' : 'Established'}</div>
            </div>
            <div class="ens-card">
              <div class="ens-card-label">Catalog Size</div>
              <div class="ens-card-val text-green">${data.totalItems} items</div>
              <div class="ens-card-sub">Active inventory</div>
            </div>
          </div>

          ${data.topBestsellers && data.topBestsellers.length > 0 ? `
            <div class="ens-tags-section" style="margin-top: 10px; margin-bottom: 12px; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 10px; padding: 10px 12px;">
              <div class="ens-tags-header" style="color: #0f172a; font-weight: 700; margin-bottom: 8px; display: flex; justify-content: space-between; align-items: center;">
                <span>🔥 Top 5 Store SKUs (Revenue & 30-Day Velocity)</span>
                <span style="font-size: 10px; color: #64748b; font-weight: normal;">Est. 30d Velocity</span>
              </div>
              <div style="display: flex; flex-direction: column; gap: 6px;">
                ${data.topBestsellers.map((item, idx) => `
                  <div style="display: flex; justify-content: space-between; align-items: center; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 6px 8px; font-size: 11px;">
                    <div style="display: flex; align-items: center; gap: 6px; overflow: hidden; max-width: 65%;">
                      <span style="font-weight: 800; color: #ef641e; font-size: 10px;">#${idx + 1}</span>
                      <a href="${item.url}" target="_blank" style="color: #0f172a; text-decoration: none; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${item.title}">
                        ${item.title}
                      </a>
                    </div>
                    <div style="display: flex; align-items: center; gap: 6px; flex-shrink: 0;">
                      ${item.sold24h > 0 ? `<span style="font-size: 9px; color: #ef4444; font-weight: 700; background: rgba(239,68,68,0.1); padding: 1px 4px; border-radius: 4px;">🔥 ${item.sold24h} sold/24h</span>` : ''}
                      ${item.inCart > 0 ? `<span style="font-size: 9px; color: #ea580c; font-weight: 700; background: rgba(234,88,12,0.1); padding: 1px 4px; border-radius: 4px;">🛒 ${item.inCart}</span>` : ''}
                      ${item.reviews30d > 0 ? `<span style="font-size: 9px; color: #0284c7; font-weight: 700; background: rgba(2,132,199,0.1); padding: 1px 4px; border-radius: 4px;">⭐ ${item.reviews30d} (30d)</span>` : ''}
                      <span style="font-weight: 700; color: #059669; font-size: 11px;">~${item.estSales30d || 0}/mo</span>
                    </div>
                  </div>
                `).join('')}
              </div>
            </div>
          ` : ''}

          ${data.topReviewed30d && data.topReviewed30d.length > 0 ? `
            <div style="margin-bottom: 12px; background: rgba(2,132,199,0.06); border: 1px solid rgba(2,132,199,0.25); border-radius: 8px; padding: 8px 10px; font-size: 11px;">
              <div style="font-weight: 700; color: #0369a1; margin-bottom: 4px;">⭐ Top Reviewed Listings (Last 30 Days)</div>
              <div style="display: flex; flex-direction: column; gap: 4px;">
                ${data.topReviewed30d.slice(0, 3).map(item => `
                  <div style="display: flex; justify-content: space-between; align-items: center; font-size: 10px;">
                    <a href="${item.url}" target="_blank" style="color: #0f172a; text-decoration: none; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 75%;">${item.title}</a>
                    <span style="color: #0284c7; font-weight: 700;">+${item.reviews30d} reviews in 30d</span>
                  </div>
                `).join('')}
              </div>
            </div>
          ` : ''}

          <div class="ens-actions">
            <button id="ens-copy-shop-btn" class="ens-btn-primary">
              ${renderSvg('copy', 13)} Copy Store JSON
            </button>
            <button id="ens-rescan-btn" class="ens-btn-secondary">
              ${renderSvg('refresh', 13)} Re-scan
            </button>
          </div>
        </div>
      `;
      document.getElementById('ens-copy-shop-btn')?.addEventListener('click', () => copyTextToClipboard(JSON.stringify(data, null, 2)));
    } else if (data.type === 'sold') {
      // Sold Forensics Pro (100% Real Purchases)
      hud.innerHTML = `
        <div class="ens-header">
          <div class="ens-title">
            <span class="ens-dot" style="background: #10b981;"></span>
            <strong>ScoutPro Sold Forensics</strong>
            <span class="ens-shortcut">100% Real Sales</span>
          </div>
          <div class="ens-controls">
            <button class="ens-icon-btn" id="ens-close-btn" title="Close">${renderSvg('close', 13)}</button>
          </div>
        </div>
        <div class="ens-body" id="ens-body-content">
          <div class="ens-verdict status-green">PUBLIC SOLD RECORDS UNMASKED</div>
          <div class="ens-grid">
            <div class="ens-card">
              <div class="ens-card-label">Audited Purchases</div>
              <div class="ens-card-val text-green">${data.totalSoldAudited} items</div>
              <div class="ens-card-sub">Visible on Page</div>
            </div>
            <div class="ens-card">
              <div class="ens-card-label">Unique Products Sold</div>
              <div class="ens-card-val text-accent">${data.uniqueSoldProducts}</div>
              <div class="ens-card-sub">SKUs with Sales</div>
            </div>
          </div>
          ${data.leaderboard && data.leaderboard.length > 0 ? `
            <div class="ens-tags-section" style="margin-top: 10px; margin-bottom: 12px; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 10px; padding: 10px 12px;">
              <div class="ens-tags-header" style="color: #0f172a; font-weight: 700; margin-bottom: 8px;">
                <span>🏆 Verified Bestsellers (By Actual Purchases)</span>
              </div>
              <div style="display: flex; flex-direction: column; gap: 6px;">
                ${data.leaderboard.map((item, idx) => `
                  <div style="display: flex; justify-content: space-between; align-items: center; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 6px 8px; font-size: 11px;">
                    <div style="display: flex; align-items: center; gap: 6px; overflow: hidden; max-width: 75%;">
                      <span style="font-weight: 800; color: #10b981; font-size: 10px;">#${idx + 1}</span>
                      <span style="color: #0f172a; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${item.title}">
                        ${item.title}
                      </span>
                    </div>
                    <span style="font-weight: 700; color: #10b981; font-size: 11px;">${item.count} sold</span>
                  </div>
                `).join('')}
              </div>
            </div>
          ` : ''}
          <div class="ens-actions">
            <button id="ens-copy-sold-btn" class="ens-btn-primary">
              ${renderSvg('copy', 13)} Copy Sold Forensics JSON
            </button>
            <button id="ens-rescan-btn" class="ens-btn-secondary">
              ${renderSvg('refresh', 13)} Re-scan
            </button>
          </div>
        </div>
      `;
      document.getElementById('ens-copy-sold-btn')?.addEventListener('click', () => copyTextToClipboard(JSON.stringify(data, null, 2)));
    } else if (data.type === 'favoriters') {
      // Admirer Velocity Forensics
      hud.innerHTML = `
        <div class="ens-header">
          <div class="ens-title">
            <span class="ens-dot" style="background: #ec4899;"></span>
            <strong>Admirer Velocity Pro</strong>
            <span class="ens-shortcut">Wishlist Intent</span>
          </div>
          <div class="ens-controls">
            <button class="ens-icon-btn" id="ens-close-btn" title="Close">${renderSvg('close', 13)}</button>
          </div>
        </div>
        <div class="ens-body" id="ens-body-content">
          <div class="ens-verdict status-green">${data.velocityRating}</div>
          <div class="ens-grid">
            <div class="ens-card">
              <div class="ens-card-label">Total Admirers</div>
              <div class="ens-card-val text-accent">${data.admirersCount.toLocaleString()}</div>
              <div class="ens-card-sub">Wishlist Additions</div>
            </div>
            <div class="ens-card">
              <div class="ens-card-label">Visible Buyers</div>
              <div class="ens-card-val text-green">${data.visibleBuyers}</div>
              <div class="ens-card-sub">Recent Accounts</div>
            </div>
          </div>
          <div class="ens-actions">
            <button id="ens-copy-adm-btn" class="ens-btn-primary">
              ${renderSvg('copy', 13)} Copy Admirer Data
            </button>
          </div>
        </div>
      `;
      document.getElementById('ens-copy-adm-btn')?.addEventListener('click', () => copyTextToClipboard(JSON.stringify(data, null, 2)));
    } else {
      // Search Niche Scout
      hud.innerHTML = `
        <div class="ens-header">
          <div class="ens-title">
            <span class="ens-dot"></span>
            <strong>Etsy Niche Scout Pro</strong>
            <span class="ens-shortcut">Alt+S</span>
          </div>
          <div class="ens-controls">
            <button class="ens-icon-btn" id="ens-matrix-btn" title="Open Data Horizon Comparison Matrix">
              ${renderSvg('table', 14)}
            </button>
            <button class="ens-icon-btn" id="ens-settings-btn" title="Settings & Fees">
              ${renderSvg('sliders', 14)}
            </button>
            <button class="ens-icon-btn" id="ens-min-btn" title="Minimize">
              ${renderSvg('minus', 13)}
            </button>
            <button class="ens-icon-btn" id="ens-close-btn" title="Close">
              ${renderSvg('close', 13)}
            </button>
          </div>
        </div>
        <!-- Instant Feature Visibility Chips (1-Click Modular HUD UX) -->
        <div class="ens-visibility-bar">
          <span style="font-size: 9px; font-weight: 700; color: #64748b; text-transform: uppercase; align-self: center; margin-right: 4px;">Pills:</span>
          <button class="ens-chip-toggle ${userSettings.showFocusKeywords !== false ? 'active' : ''}" data-key="showFocusKeywords" title="Toggle Focus Keyword Chips">🏷️ Tags</button>
          <button class="ens-chip-toggle ${userSettings.showNetProfit !== false ? 'active' : ''}" data-key="showNetProfit" title="Toggle Net Profit Margin">💰 Profit</button>
          <button class="ens-chip-toggle ${userSettings.showInCartUrgency !== false ? 'active' : ''}" data-key="showInCartUrgency" title="Toggle In-Cart Urgency Badge">🔥 In-Cart</button>
          <button class="ens-chip-toggle ${userSettings.showOrganicAdRank !== false ? 'active' : ''}" data-key="showOrganicAdRank" title="Toggle Organic vs Ad Rank">⚡ Rank</button>
          <button class="ens-chip-toggle ${userSettings.showPriceSentiment !== false ? 'active' : ''}" data-key="showPriceSentiment" title="Toggle Price Sentiment Benchmark">🏷️ Price</button>
        </div>
        <div class="ens-body" id="ens-body-content">
          ${data.aiVerdict ? `
            <div class="ens-ai-verdict">
              ${renderSvg('sparkles', 13)}
              <span>${data.aiVerdict}</span>
            </div>
          ` : ''}
          <div class="ens-query-row">
            <div class="ens-query">🔍 <span>${data.query}</span></div>
            <div class="ens-filter-switch">
              <button id="ens-filter-all" class="ens-filter-btn ${!filterDigitalOnly ? 'active' : ''}">All Products</button>
              <button id="ens-filter-digital" class="ens-filter-btn ${filterDigitalOnly ? 'active' : ''}">⚡ Digital Only</button>
              <button id="ens-simulate-us-btn" class="ens-filter-btn" title="Simulate US Buyer SERP (US Region & USD Currency)">🇺🇸 US View</button>
            </div>
          </div>
          <div class="ens-verdict ${data.statusClass}">${data.status}</div>
          <div class="ens-grid">
            <div class="ens-card">
              <div class="ens-card-label">
                ${renderSvg('radar', 12)} Niche Saturation
              </div>
              <div class="ens-card-val ${data.totalListings <= 1500 ? 'text-green' : (data.totalListings <= 3000 ? 'text-yellow' : 'text-red')}">${data.totalListings.toLocaleString()}</div>
              <div class="ens-card-sub">${data.totalListings <= 1500 ? 'Under 1.5k ceiling' : 'High ceiling'}</div>
            </div>
            <div class="ens-card">
              <div class="ens-card-label">
                ${renderSvg('target', 12)} Opportunity Index
              </div>
              <div class="ens-card-val text-accent">${data.score}/100</div>
              <div class="ens-card-sub">Algorithmic Rank</div>
            </div>
            <div class="ens-card">
              <div class="ens-card-label">Avg Price (Page 1)</div>
              <div class="ens-card-val">${data.currency}${data.avgPrice}</div>
              <div class="ens-card-sub">Range: ${data.currency}${data.minPrice} - ${data.currency}${data.maxPrice}</div>
            </div>
            <div class="ens-card">
              <div class="ens-card-label">
                ${renderSvg('rocket', 12)} New Seller Inroad
              </div>
              <div class="ens-card-val ${data.newShopPenetration >= 20 ? 'text-green' : 'text-yellow'}">${data.newShopPenetration}% Page 1</div>
              <div class="ens-card-sub">&lt;50 review shops</div>
            </div>
            <div class="ens-card">
              <div class="ens-card-label">
                ${renderSvg('flame', 12)} Live Buyer Demand
              </div>
              <div class="ens-card-val text-green">${data.inCartListings} listings</div>
              <div class="ens-card-sub">${data.bestsellerCount} Bestsellers</div>
            </div>
            <div class="ens-card">
              <div class="ens-card-label">
                ${renderSvg('shield', 12)} Est. Monthly Search GMV
              </div>
              <div class="ens-card-val text-accent">~${data.currency}${data.estMonthlyRevenue.toLocaleString()}</div>
              <div class="ens-card-sub">Search run-rate</div>
            </div>
          </div>

          <!-- Bestseller Tag Cloud -->
          ${data.topTags.length > 0 ? `
            <div class="ens-tags-section">
              <div class="ens-tags-header">
                <span>High-Velocity Keywords</span>
                <span style="font-size: 10px; cursor: pointer; color: var(--ens-accent-lime);" id="ens-copy-tags">
                  ${renderSvg('copy', 11)} Copy All
                </span>
              </div>
              <div class="ens-tags-cloud">
                ${data.topTags.map(t => `<span class="ens-tag-pill" data-tag="${t}">${t}</span>`).join('')}
              </div>
            </div>
          ` : ''}

          <div class="ens-actions" style="display: flex; flex-wrap: wrap; gap: 6px;">
            <button id="ens-mine-keywords-btn" class="ens-btn-primary" style="background: #6366f1; border-color: #4f46e5; flex: 1 1 45%;" title="Mine live real-time buyer search suggestions directly from Etsy Autocomplete API">
              ${renderSvg('sparkles', 13)} Mine Live Buyer Keywords
            </button>
            <button id="ens-copy-13-tags-btn" class="ens-btn-primary" style="background: #10b981; border-color: #059669; flex: 1 1 45%;" title="Format and copy 13 tags ready to paste into Etsy">
              ${renderSvg('copy', 13)} Copy 13 Winning Tags
            </button>
            <button id="ens-export-btn" class="ens-btn-primary" style="flex: 1 1 60%;">
              ${renderSvg('download', 13)} Export CSV (${data.listingsAudited} items)
            </button>
            <button id="ens-rescan-btn" class="ens-btn-secondary" style="flex: 0 0 auto;">
              ${renderSvg('refresh', 13)} Re-scan
            </button>
          </div>
        </div>
      `;

      async function simulateUsRegion() {
        const nonce = document.querySelector('meta[name="csrf_nonce"]')?.content;
        if (!nonce) {
          alert('[Etsy Niche Scout] Could not locate Etsy CSRF token on this page.');
          return;
        }
        const btn = document.getElementById('ens-simulate-us-btn');
        if (btn) btn.innerText = 'Switching to US...';
        try {
          const res = await fetch('https://www.etsy.com/api/v3/ajax/member/locale-preferences', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'x-csrf-token': nonce
            },
            body: JSON.stringify({ currency: 'USD', language: 'en-US', region: 'US' }),
            credentials: 'include'
          });
          if (res.ok) {
            window.location.reload();
          } else {
            alert('[Etsy Niche Scout] Locale change returned HTTP ' + res.status);
          }
        } catch (e) {
          alert('[Etsy Niche Scout] Locale change failed: ' + e.message);
        }
      }

      async function mineBuyerKeywords(query) {
        const container = document.getElementById('ens-body-content');
        if (!container) return;

        let panel = document.getElementById('ens-mined-keywords-panel');
        if (panel) {
          panel.remove();
          return;
        }

        panel = document.createElement('div');
        panel.id = 'ens-mined-keywords-panel';
        panel.style.cssText = 'margin-top: 10px; padding: 10px; background: rgba(99, 102, 241, 0.08); border: 1px solid rgba(99, 102, 241, 0.25); border-radius: 8px; font-size: 11px;';
        panel.innerHTML = '<div style="color: #818cf8; font-weight: 600; margin-bottom: 6px;">⚡ Mining Real-Time Etsy Buyer Queries...</div>';
        container.appendChild(panel);

        const cleanQ = (query || '').trim();
        const variations = [cleanQ, `${cleanQ} for`, `${cleanQ} digital`, `${cleanQ} template`, `${cleanQ} 2026`];
        const allSuggestions = new Set();

        for (const v of variations) {
          try {
            const res = await fetch(`/api/v3/ajax/public/search/suggestions?query=${encodeURIComponent(v)}`, {
              headers: { 'Accept': 'application/json' },
              credentials: 'include'
            });
            if (res.ok) {
              const json = await res.json();
              const items = json.results || json.suggestions || (Array.isArray(json) ? json : []);
              items.forEach(it => {
                const text = typeof it === 'string' ? it : (it.query || it.suggestion || it.title || '');
                if (text) allSuggestions.add(text.toLowerCase());
              });
            }
          } catch (e) {}
        }

        if (allSuggestions.size === 0) {
          panel.innerHTML = '<div style="color: #ef4444;">No live suggestions returned for this query.</div>';
          return;
        }

        const list = Array.from(allSuggestions);
        panel.innerHTML = `
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
            <span style="font-weight: 700; color: #a5b4fc;">⚡ ${list.length} Real Buyer Queries (Etsy Autocomplete)</span>
            <button id="ens-copy-mined-btn" style="background: #4f46e5; border: none; color: white; padding: 3px 8px; border-radius: 4px; font-size: 10px; cursor: pointer;">Copy All</button>
          </div>
          <div style="display: flex; flex-wrap: wrap; gap: 4px; max-height: 120px; overflow-y: auto;">
            ${list.map(s => `<span class="ens-tag-pill" style="background: rgba(99, 102, 241, 0.2); border: 1px solid rgba(99, 102, 241, 0.4); color: #e0e7ff;" data-tag="${s}">${s}</span>`).join('')}
          </div>
        `;

        document.getElementById('ens-copy-mined-btn')?.addEventListener('click', () => {
          copyTextToClipboard(list.join(', '));
        });
        panel.querySelectorAll('.ens-tag-pill').forEach(pill => {
          pill.addEventListener('click', () => copyTextToClipboard(pill.getAttribute('data-tag')));
        });
      }

      // Instant Feature Visibility Chip listeners (1-Click Modular HUD UX)
      hud.querySelectorAll('.ens-chip-toggle').forEach(btn => {
        btn.addEventListener('click', () => {
          const key = btn.getAttribute('data-key');
          if (key) {
            userSettings[key] = !userSettings[key];
            btn.classList.toggle('active', !!userSettings[key]);
            saveUserSettings(userSettings, () => {
              injectInGridCardForensics();
            });
          }
        });
      });

      // Filter switch event listeners
      document.getElementById('ens-simulate-us-btn')?.addEventListener('click', simulateUsRegion);
      document.getElementById('ens-mine-keywords-btn')?.addEventListener('click', () => mineBuyerKeywords(data.query));
      document.getElementById('ens-filter-all')?.addEventListener('click', () => {
        filterDigitalOnly = false;
        runAudit();
      });
      document.getElementById('ens-filter-digital')?.addEventListener('click', () => {
        filterDigitalOnly = true;
        runAudit();
      });

      // 1-Click Copy 13 Formatted Winning Tags
      document.getElementById('ens-copy-13-tags-btn')?.addEventListener('click', () => {
        const formatted = formatEtsy13Tags(data.topTags);
        copyTextToClipboard(formatted.clipboardString || data.topTags.slice(0, 13).join(', '));
      });

      // Tag copy listeners
      document.getElementById('ens-copy-tags')?.addEventListener('click', () => {
        copyTextToClipboard(data.topTags.join(', '));
      });
      document.querySelectorAll('.ens-tag-pill').forEach(pill => {
        pill.addEventListener('click', () => {
          copyTextToClipboard(pill.getAttribute('data-tag'));
        });
      });

      document.getElementById('ens-matrix-btn')?.addEventListener('click', () => toggleMatrixModal(true));
    }

    // Shared listeners
    document.getElementById('ens-settings-btn')?.addEventListener('click', () => toggleSettingsDrawer(true));
    document.getElementById('ens-export-btn')?.addEventListener('click', () => exportCsv(data));
    document.getElementById('ens-rescan-btn')?.addEventListener('click', runAudit);
    document.getElementById('ens-close-btn')?.addEventListener('click', () => {
      isHudVisible = false;
      hud.style.display = 'none';
    });
    document.getElementById('ens-min-btn')?.addEventListener('click', () => {
      isHudMinimized = true;
      renderFloatingHud(currentAnalysis);
    });

    makeDraggable(hud, hud.querySelector('.ens-header'));
  }

  function runAudit() {
    if (isListingPage()) {
      pageMode = 'listing';
      currentAnalysis = analyzeListing();
    } else if (isSoldPage()) {
      pageMode = 'sold';
      currentAnalysis = analyzeSoldListings();
      scheduleGridInjection();
    } else if (isFavoritersPage()) {
      pageMode = 'favoriters';
      currentAnalysis = analyzeFavoriters();
    } else if (isShopPage()) {
      pageMode = 'shop';
      currentAnalysis = analyzeShop();
      scheduleGridInjection();
    } else if (isSearchPage()) {
      pageMode = 'search';
      currentAnalysis = analyzeNiche();
      scheduleGridInjection();
    } else {
      currentAnalysis = null;
    }
    renderFloatingHud(currentAnalysis);
    renderFloatingAnalyzeTrigger(currentAnalysis?.listings?.length);
    updateAgentBridge(currentAnalysis);
  }

  // ==========================================
  // AI AGENT & AUTOMATION DATA BRIDGE
  // ==========================================

  function updateAgentBridge(data) {
    if (typeof document === 'undefined') return;
    let bridgeEl = document.getElementById('ens-agent-bridge');
    if (!bridgeEl) {
      bridgeEl = document.createElement('div');
      bridgeEl.id = 'ens-agent-bridge';
      bridgeEl.style.display = 'none';
      if (document.body) document.body.appendChild(bridgeEl);
    }
    bridgeEl.setAttribute('data-status', data ? 'ready' : 'empty');
    bridgeEl.setAttribute('data-mode', pageMode);
    bridgeEl.setAttribute('data-updated-at', Date.now().toString());
    bridgeEl.setAttribute('data-payload', JSON.stringify(data || {}));

    // Dispatch event for any attached browser automation/CDP listeners
    if (typeof window !== 'undefined' && typeof CustomEvent !== 'undefined') {
      window.dispatchEvent(new CustomEvent('ENS_DATA_UPDATE', { detail: data }));
    }
  }

  // Global window handle for remote debugging and script evaluation
  if (typeof window !== 'undefined') {
    window.__ens_bridge = {
      getAnalysis: () => currentAnalysis,
      getPageMode: () => pageMode,
      getSettings: () => userSettings,
      rescan: () => runAudit(),
      openMatrix: () => toggleMatrixModal(true),
      closeMatrix: () => toggleMatrixModal(false),
      openSettings: () => toggleSettingsDrawer(true)
    };
  }

  if (typeof window !== 'undefined' && typeof document !== 'undefined') {
    // Listen for popup trigger message
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
      chrome.runtime.onMessage.addListener((msg) => {
        if (msg && msg.action === 'rescan') {
          isHudVisible = true;
          runAudit();
        } else if (msg && msg.action === 'openMatrix') {
          toggleMatrixModal(true);
        } else if (msg && msg.action === 'openSettings') {
          toggleSettingsDrawer(true);
        } else if (msg && msg.action === 'updateSettings') {
          userSettings = Object.assign({}, userSettings, msg.settings || {});
          filterDigitalOnly = !!userSettings.filterDigitalOnly;
          isHudVisible = userSettings.showFloatingHud !== false;
          // Cleanly re-render in-grid card badges and HUD
          document.querySelectorAll('.ens-card-strip').forEach(el => el.remove());
          runAudit();
        }
      });
    }

    // Global Keyboard Shortcuts:
    // Alt + S = toggle HUD
    // Alt + M = toggle Matrix Comparison Modal
    // Esc = close modals
    window.addEventListener('keydown', (e) => {
      if (e.altKey && (e.key === 's' || e.key === 'S')) {
        isHudVisible = !isHudVisible;
        renderFloatingHud(currentAnalysis);
      } else if (e.altKey && (e.key === 'm' || e.key === 'M')) {
        const modal = document.getElementById('ens-matrix-modal');
        toggleMatrixModal(!modal || !modal.classList.contains('open'));
      } else if (e.key === 'Escape') {
        const modal = document.getElementById('ens-matrix-modal');
        if (modal && modal.classList.contains('open')) toggleMatrixModal(false);
        const drawer = document.getElementById('ens-settings-drawer');
        if (drawer && drawer.classList.contains('open')) toggleSettingsDrawer(false);
      }
    });

    // Initial load: settings first, then audit
    loadSettings(() => {
      setTimeout(runAudit, 1200);
    });

    // Re-run on navigation without full reload (History API / SPA) or scroll lazy-loading
    if (typeof location !== 'undefined' && typeof MutationObserver !== 'undefined') {
      let lastUrl = location.href;
      const observer = new MutationObserver((mutations) => {
        // Zero-reflow optimization: early-exit if mutations originated inside our extension
        let isInternal = true;
        for (const m of mutations) {
          const target = m.target;
          if (target && target.nodeType === 1) {
            if (!target.closest('#etsy-niche-scout-hud, #ens-settings-drawer, #ens-matrix-modal, .ens-card-strip')) {
              isInternal = false;
              break;
            }
          } else {
            isInternal = false;
            break;
          }
        }
        if (isInternal) return;

        const url = location.href;
        if (url !== lastUrl) {
          lastUrl = url;
          setTimeout(runAudit, 1500);
        } else if (pageMode === 'search' || pageMode === 'shop') {
          scheduleGridInjection();
        }
      });

      if (document.body || document.documentElement) {
        observer.observe(document.body || document.documentElement, { subtree: true, childList: true });
      }
    }

    // Passive scroll listener for fast infinite-scroll injection
    let scrollTimeout = null;
    window.addEventListener('scroll', () => {
      if (pageMode === 'search' || pageMode === 'shop') {
        clearTimeout(scrollTimeout);
        scrollTimeout = setTimeout(scheduleGridInjection, 200);
      }
    }, { passive: true });
  }

  const exportedHelpers = {
    formatEtsy13Tags,
    calculateEconomics,
    computeListingSalesEstimates,
    extractCardReviewCount,
    parseReviewCountString,
    formulateAiVerdict,
    extractUrlForensics,
    computeMedianPrice,
    auditRedundantTags,
    getListingAgeString,
    isWithinLast30Days,
    analyzeListing,
    analyzeShop
  };

  if (typeof window !== 'undefined') {
    window.__etsyNicheScout = exportedHelpers;
  }

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = exportedHelpers;
  }

})();
