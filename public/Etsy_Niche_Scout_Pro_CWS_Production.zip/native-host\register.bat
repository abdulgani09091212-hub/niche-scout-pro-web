@echo off
setlocal
echo ===================================================================
echo  Registering Niche Scout Pro Native Messaging Host (Windows)
echo ===================================================================
echo.

set "MANIFEST_PATH=%~dp0com.etsy.niche_scout_pro.json"

echo Manifest: "%MANIFEST_PATH%"
echo.

:: 1. Google Chrome
reg add "HKCU\Software\Google\Chrome\NativeMessagingHosts\com.etsy.niche_scout_pro" /ve /t REG_SZ /d "%MANIFEST_PATH%" /f
if %ERRORLEVEL% equ 0 (
    echo [OK] Registered for Google Chrome
) else (
    echo [FAIL] Could not register for Google Chrome
)

:: 2. Microsoft Edge
reg add "HKCU\Software\Microsoft\Edge\NativeMessagingHosts\com.etsy.niche_scout_pro" /ve /t REG_SZ /d "%MANIFEST_PATH%" /f
if %ERRORLEVEL% equ 0 (
    echo [OK] Registered for Microsoft Edge
) else (
    echo [FAIL] Could not register for Microsoft Edge
)

:: 3. Brave Browser
reg add "HKCU\Software\BraveSoftware\Brave-Browser\NativeMessagingHosts\com.etsy.niche_scout_pro" /ve /t REG_SZ /d "%MANIFEST_PATH%" /f
if %ERRORLEVEL% equ 0 (
    echo [OK] Registered for Brave Browser
) else (
    echo [FAIL] Could not register for Brave Browser
)

echo.
echo ===================================================================
echo  Registration Complete! Any Chromium browser will auto-connect.
echo ===================================================================
pause
