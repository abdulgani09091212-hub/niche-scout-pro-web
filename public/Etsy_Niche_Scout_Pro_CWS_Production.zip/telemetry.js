/**
 * Niche Scout Pro — Telemetry & Crash Diagnostic Engine
 * Connected to Firebase Project: smartpdf-studio-legal
 */

(function () {
  const FIREBASE_CONFIG = {
    projectId: "smartpdf-studio-legal",
    appId: "1:310156760547:web:f0b742b162558e86a63cd6",
    apiKey: "AIzaSyCOgiOh4VzFZU-eUJE8q8PAVEqBic3nD74",
    telemetryEndpoint: "https://scoutpro.app/api/telemetry"
  };

  function sendTelemetry(type, data) {
    const payload = {
      ...data,
      url: window.location ? window.location.href : "unknown",
      timestamp: Date.now(),
      version: "1.0.0"
    };

    // 1. Persist locally to storage buffer for instant diagnostics in popup
    try {
      if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
        chrome.storage.local.get(["scout_telemetry_logs"], (res) => {
          const logs = res.scout_telemetry_logs || [];
          logs.unshift({ type, payload, recordedAt: new Date().toISOString() });
          if (logs.length > 50) logs.pop();
          chrome.storage.local.set({ scout_telemetry_logs: logs });
        });
      }
    } catch (e) {
      // Ignore local storage error
    }

    // 2. Dispatch to background service worker for network transmission
    try {
      if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({
          type: "FIREBASE_TELEMETRY",
          telemetryType: type,
          config: FIREBASE_CONFIG,
          payload
        }, () => {
          if (chrome.runtime.lastError) {
            // Background worker sleeping or inactive, silent failover
          }
        });
      }
    } catch (e) {
      // Ignore background dispatch error
    }
  }

  // Global Crash & Error Listeners
  window.addEventListener("error", function (event) {
    // Only capture errors related to scout extension scripts
    const filename = event.filename || "";
    if (filename.includes("content.js") || filename.includes("popup.js") || filename.includes("styles.css")) {
      sendTelemetry("crash_report", {
        message: event.message || "Unknown Runtime Error",
        filename: event.filename,
        lineno: event.lineno,
        colno: event.colno,
        stack: event.error ? event.error.stack : null,
        errorType: "script_error"
      });
    }
  });

  window.addEventListener("unhandledrejection", function (event) {
    sendTelemetry("crash_report", {
      message: event.reason ? (event.reason.message || String(event.reason)) : "Unhandled Promise Rejection",
      stack: event.reason ? event.reason.stack : null,
      errorType: "unhandled_rejection"
    });
  });

  // Export to global scope
  window.__NicheScoutTelemetry = {
    logCrash: function (error, context) {
      sendTelemetry("manual_crash", {
        message: error ? (error.message || String(error)) : "Manual Exception",
        stack: error ? error.stack : null,
        context: context || {}
      });
    },
    logEvent: function (eventName, eventData) {
      sendTelemetry("custom_event", {
        event: eventName,
        data: eventData || {}
      });
    }
  };
})();
