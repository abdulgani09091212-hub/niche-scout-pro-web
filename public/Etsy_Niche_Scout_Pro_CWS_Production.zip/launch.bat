@echo off
setlocal
echo ========================================================
echo  Launching Chrome with Etsy Niche Scout Pro + CDP (9222)
echo ========================================================
set "EXT_DIR=%~dp0"
if "%EXT_DIR:~-1%"=="\" set "EXT_DIR=%EXT_DIR:~0,-1%"

if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" (
    start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" --load-extension="%EXT_DIR%" --remote-debugging-port=9222 --no-first-run "https://www.etsy.com/search?q=funeral+program+canva+template"
) else if exist "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" (
    start "" "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" --load-extension="%EXT_DIR%" --remote-debugging-port=9222 --no-first-run "https://www.etsy.com/search?q=funeral+program+canva+template"
) else if exist "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" (
    start "" "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" --load-extension="%EXT_DIR%" --remote-debugging-port=9222 --no-first-run "https://www.etsy.com/search?q=funeral+program+canva+template"
) else (
    echo Chrome was not found in standard paths.
    echo Please open chrome://extensions in your browser and click 'Load unpacked'.
    pause
)
