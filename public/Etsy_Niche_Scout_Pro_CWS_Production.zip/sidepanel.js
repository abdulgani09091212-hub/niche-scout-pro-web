// Niche Scout Pro — Chrome Side Panel Controller
// Manages real-time sync with active Etsy page and Agent Bridge

document.addEventListener('DOMContentLoaded', () => {
  const copyBtn = document.getElementById('copy-tags-btn');
  const copyStatus = document.getElementById('tag-copy-status');
  const scanBtn = document.getElementById('scan-now-btn');
  const exportBtn = document.getElementById('export-csv-btn');

  // 1. Copy 13 Tags Handler
  if (copyBtn) {
    copyBtn.addEventListener('click', () => {
      const tags = Array.from(document.querySelectorAll('.tag-chip'))
        .map(el => el.innerText.trim())
        .join(', ');
      navigator.clipboard.writeText(tags).then(() => {
        if (copyStatus) {
          copyStatus.style.display = 'inline';
          setTimeout(() => { copyStatus.style.display = 'none'; }, 2000);
        }
      });
    });
  }

  // 2. Trigger Scan Message to Active Tab
  if (scanBtn) {
    scanBtn.addEventListener('click', () => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs[0]) {
          chrome.tabs.sendMessage(tabs[0].id, { type: 'ENS_TRIGGER_RESCAN' }, (res) => {
            console.log('Rescan dispatched:', res);
          });
        }
      });
    });
  }

  // 3. Export CSV Message to Active Tab
  if (exportBtn) {
    exportBtn.addEventListener('click', () => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs[0]) {
          chrome.tabs.sendMessage(tabs[0].id, { type: 'ENS_TRIGGER_EXPORT_CSV' }, (res) => {
            console.log('Export CSV dispatched:', res);
          });
        }
      });
    });
  }

  // 4. Poll / Listen for Content Script updates
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === 'ENS_DATA_UPDATE' && msg.payload) {
      const p = msg.payload;
      if (p.oppScore) document.getElementById('kpi-opp').innerText = `${p.oppScore}/100`;
      if (p.satCount) document.getElementById('kpi-sat').innerText = p.satCount;
      if (p.avgPrice) document.getElementById('kpi-price').innerText = `$${p.avgPrice}`;
      if (p.gmv) document.getElementById('kpi-gmv').innerText = `~$${p.gmv}`;
    }
  });
});
