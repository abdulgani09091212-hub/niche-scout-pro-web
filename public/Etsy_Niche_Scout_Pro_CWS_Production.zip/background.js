/**
 * Niche Scout Pro — Background Service Worker
 * Handles Firebase crash telemetry dispatches & diagnostic persistence
 */

const FIREBASE_LOG_ENDPOINT = "https://scoutpro.app/api/telemetry";

chrome.runtime.onInstalled.addListener(() => {
  // Initialize default telemetry storage
  chrome.storage.local.get(["scout_telemetry_logs"], (res) => {
    if (!res.scout_telemetry_logs) {
      chrome.storage.local.set({
        scout_telemetry_logs: [
          {
            type: "system_init",
            payload: { message: "Extension installed and telemetry initialized." },
            recordedAt: new Date().toISOString()
          }
        ]
      });
    }
  });
});

// Listener for content script and popup telemetry
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.type === "FIREBASE_TELEMETRY") {
    const { telemetryType, payload, config } = message;

    // Send asynchronously to backend / Firebase endpoint
    fetch(FIREBASE_LOG_ENDPOINT, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        projectId: config ? config.projectId : "smartpdf-studio-legal",
        appId: config ? config.appId : "1:310156760547:web:f0b742b162558e86a63cd6",
        telemetryType,
        payload,
        senderTab: sender ? sender.tab : null,
        timestamp: Date.now()
      })
    })
      .then((res) => res.json())
      .then((data) => {
        sendResponse({ success: true, data });
      })
      .catch((err) => {
        // Fallback: log failure locally
        sendResponse({ success: false, error: err.message });
      });

    return true; // Keep message channel open for async response
  }
});
