/**
 * Niche Scout Pro — Background Service Worker & AI Agent Bridge
 * Handles Firebase telemetry, Side Panel lifecycle, Native Messaging Host, and Claude Tab Grouping
 */

const FIREBASE_LOG_ENDPOINT = "https://scoutpro.app/api/telemetry";
const NATIVE_HOST_NAME = "com.etsy.niche_scout_pro";
let nativePort = null;

// Initialize default telemetry storage
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["scout_telemetry_logs"], (res) => {
    if (!res.scout_telemetry_logs) {
      chrome.storage.local.set({
        scout_telemetry_logs: [
          {
            type: "system_init",
            payload: { message: "Extension installed and telemetry initialized." },
            recordedAt: new Date().toISOString()
          }
        ]
      });
    }
  });
});

// Configure Side Panel behavior
if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }).catch(() => {});
}

// ---------------------------------------------------------------------------
// Claude (MCP) Visual Tab Group Management
// ---------------------------------------------------------------------------
async function openInClaudeGroup(url) {
  try {
    let groupId = null;
    if (chrome.tabGroups) {
      const existing = await chrome.tabGroups.query({ title: "Claude (MCP)" });
      if (existing && existing.length > 0) {
        groupId = existing[0].id;
      }
    }

    const tab = await chrome.tabs.create({ url, active: true });

    if (chrome.tabs.group) {
      if (groupId) {
        try {
          await chrome.tabs.group({ tabIds: [tab.id], groupId });
        } catch {
          groupId = null;
        }
      }

      if (!groupId) {
        groupId = await chrome.tabs.group({ tabIds: [tab.id] });
        if (chrome.tabGroups && chrome.tabGroups.update) {
          await chrome.tabGroups.update(groupId, {
            title: "Claude (MCP)",
            color: "yellow",
            collapsed: false
          });
        }
      }
    }

    return tab;
  } catch (err) {
    console.error("[ENS Background] Tab Grouping error:", err);
    return await chrome.tabs.create({ url, active: true });
  }
}

// ---------------------------------------------------------------------------
// Autonomous Agent Action Dispatcher
// ---------------------------------------------------------------------------
async function handleAgentAction(msg) {
  const { action, query, url, tabId } = msg;

  if (action === "search" && query) {
    const targetUrl = `https://www.etsy.com/search?q=${encodeURIComponent(query)}`;
    const tab = await openInClaudeGroup(targetUrl);
    return { success: true, action: "search", tabId: tab.id, url: targetUrl };
  }

  if (action === "visit" && url) {
    const tab = await openInClaudeGroup(url);
    return { success: true, action: "visit", tabId: tab.id, url };
  }

  if (action === "extract") {
    let targetTabId = tabId;
    if (!targetTabId) {
      const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
      targetTabId = activeTab ? activeTab.id : null;
    }

    if (!targetTabId) return { success: false, error: "No active tab found" };

    return new Promise((resolve) => {
      chrome.tabs.sendMessage(targetTabId, { type: "ENS_AGENT_EXTRACT" }, (res) => {
        if (chrome.runtime.lastError) {
          resolve({ success: false, error: chrome.runtime.lastError.message });
        } else {
          resolve({ success: true, data: res });
        }
      });
    });
  }

  if (action === "export_csv") {
    const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (activeTab && activeTab.id) {
      chrome.tabs.sendMessage(activeTab.id, { type: "ENS_TRIGGER_EXPORT_CSV" });
      return { success: true, action: "export_csv", tabId: activeTab.id };
    }
    return { success: false, error: "No active Etsy tab to export from" };
  }

  return { success: false, error: `Unknown action: ${action}` };
}

// ---------------------------------------------------------------------------
// Native Messaging Host Bridge (com.etsy.niche_scout_pro)
// ---------------------------------------------------------------------------
function connectNativeHost() {
  if (!chrome.runtime.connectNative) return;
  try {
    nativePort = chrome.runtime.connectNative(NATIVE_HOST_NAME);
    nativePort.onMessage.addListener(async (msg) => {
      const result = await handleAgentAction(msg);
      if (nativePort) {
        nativePort.postMessage({ id: msg.id, result });
      }
    });

    nativePort.onDisconnect.addListener(() => {
      nativePort = null;
      // Graceful backoff reconnection
      setTimeout(connectNativeHost, 15000);
    });
  } catch (err) {
    nativePort = null;
  }
}

connectNativeHost();

// ---------------------------------------------------------------------------
// Standard Runtime Message Listeners (Content Script / Popup / External)
// ---------------------------------------------------------------------------
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.type === "ENS_AGENT_COMMAND") {
    handleAgentAction(message.payload).then(sendResponse);
    return true;
  }

  if (message && message.type === "FIREBASE_TELEMETRY") {
    const { telemetryType, payload, config } = message;
    fetch(FIREBASE_LOG_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        projectId: config ? config.projectId : "smartpdf-studio-legal",
        appId: config ? config.appId : "1:310156760547:web:f0b742b162558e86a63cd6",
        telemetryType,
        payload,
        senderTab: sender ? sender.tab : null,
        timestamp: Date.now()
      })
    })
      .then((res) => res.json())
      .then((data) => sendResponse({ success: true, data }))
      .catch((err) => sendResponse({ success: false, error: err.message }));

    return true;
  }
});
